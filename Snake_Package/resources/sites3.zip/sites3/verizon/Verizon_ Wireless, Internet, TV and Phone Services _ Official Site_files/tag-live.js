(function(networkId) {
var automaticIntegrations = {"googleAnalytics":{"paramName":"g_cid"}};

var cacheLifetimeDays = 30;

var customDataWaitForConfig = [
  { on: function() { return Invoca.Client.parseCustomDataField("calling_page", "Last", "JavascriptDataLayer", "location.hostname + location.pathname"); }, paramName: "calling_page", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("campaign_id", "Last", "JavascriptDataLayer", "window.getCmpUrlEleven"); }, paramName: "campaign_id", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("campaign_language", "Last", "JavascriptDataLayer", "window.getCmpUrlFour"); }, paramName: "campaign_language", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("campaign_type", "Last", "JavascriptDataLayer", "window.getCmpUrlFive"); }, paramName: "campaign_type", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("cmp", "Last", "URLParam", ""); }, paramName: "cmp", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("customer_id", "Last", "URLParam", ""); }, paramName: "customer_id", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("engine", "Last", "JavascriptDataLayer", "window.getCmpUrlTen"); }, paramName: "engine", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("gclid", "Last", "URLParam", ""); }, paramName: "gclid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("invoca_number_description", "Last", "URLParam", ""); }, paramName: "invoca_number_description", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("keyword", "Last", "URLParam", ""); }, paramName: "keyword", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("kpid", "Last", "URLParam", ""); }, paramName: "kpid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("landing_page", "First", "JavascriptDataLayer", "location.href"); }, paramName: "landing_page", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("lob", "Last", "JavascriptDataLayer", "window.getCmpUrlTwo"); }, paramName: "lob", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("mcid", "Last", "JavascriptDataLayer", "window.visitorECID"); }, paramName: "mcid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("msclkid", "Last", "URLParam", ""); }, paramName: "msclkid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("promo_nonpromo", "Last", "JavascriptDataLayer", "window.getCmpUrlThree"); }, paramName: "promo_nonpromo", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("sku", "Last", "URLParam", ""); }, paramName: "sku", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("tactic", "Last", "JavascriptDataLayer", "window.getCmpUrlZero"); }, paramName: "tactic", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_campaign", "Last", "URLParam", ""); }, paramName: "utm_campaign", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_content", "Last", "URLParam", ""); }, paramName: "utm_content", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_medium", "Last", "URLParam", ""); }, paramName: "utm_medium", fallbackValue: function() { return Invoca.PNAPI.currentPageSettings.poolParams.utm_medium || null; } },
  { on: function() { return Invoca.Client.parseCustomDataField("utm_source", "Last", "URLParam", ""); }, paramName: "utm_source", fallbackValue: function() { return Invoca.PNAPI.currentPageSettings.poolParams.utm_source || null; } },
  { on: function() { return Invoca.Client.parseCustomDataField("wbraid", "Last", "URLParam", ""); }, paramName: "wbraid", fallbackValue: null }
];

var customDataWaitForConfigAnonymousFunctions = [
  { on: function() { return Invoca.Client.parseCustomDataField("calling_page", "Last", "JavascriptDataLayer", function() { return (location.hostname + location.pathname); }) }, paramName: "calling_page", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("campaign_id", "Last", "JavascriptDataLayer", function() { return (window.getCmpUrlEleven); }) }, paramName: "campaign_id", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("campaign_language", "Last", "JavascriptDataLayer", function() { return (window.getCmpUrlFour); }) }, paramName: "campaign_language", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("campaign_type", "Last", "JavascriptDataLayer", function() { return (window.getCmpUrlFive); }) }, paramName: "campaign_type", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("engine", "Last", "JavascriptDataLayer", function() { return (window.getCmpUrlTen); }) }, paramName: "engine", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("landing_page", "First", "JavascriptDataLayer", function() { return (location.href); }) }, paramName: "landing_page", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("lob", "Last", "JavascriptDataLayer", function() { return (window.getCmpUrlTwo); }) }, paramName: "lob", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("mcid", "Last", "JavascriptDataLayer", function() { return (window.visitorECID); }) }, paramName: "mcid", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("promo_nonpromo", "Last", "JavascriptDataLayer", function() { return (window.getCmpUrlThree); }) }, paramName: "promo_nonpromo", fallbackValue: null },
  { on: function() { return Invoca.Client.parseCustomDataField("tactic", "Last", "JavascriptDataLayer", function() { return (window.getCmpUrlZero); }) }, paramName: "tactic", fallbackValue: null }
];

var defaultCampaignId = "9525568";

var destinationSettings = {
  paramName: "invoca_detected_destination",
  matchLocalNumbers: false,
  matchTollFreeNumbers: false
};

var numbersToReplace = {
  "+18007113400": "9525568",
  "1-833-VERIZON": "9525568",
  "+18005476000": "9525568"
};

var organicSources = true;

var reRunAfter = 3000;

var requiredParams = null;

var resetCacheOn = ['gclid', 'utm_source', 'utm_medium', 'cmp'];

var waitFor = 0;

var customCodeIsSet = (function() {
  Invoca.Client.customCode = function(options) {
    try {
    //Any changes to allowedClientSideParams must be mirrored between the Verizon (1862) and Verizon Consumer (2676) tags
    Invoca.Tools.allowedClientSideParams(["cmp", "gclid", "wbraid", "gbraid", "utm_medium", "utm_source"]);
} catch(error) {
    console.log(error);
};
 
Invoca.Client.getParamValue = function(param) {
    if (!param) {
        return "";
    }
    return Invoca.Tools.readUrl(param) || Invoca.Tools.readInvocaData(param);
}; 

Invoca.Client.parseCmpUrlParam = function() {
    var cmpParamValue = Invoca.Client.getParamValue('cmp');
    return cmpParamValue ? cmpParamValue.split('-') : "";
};

window.getCmpUrlFour = Invoca.Client.parseCmpUrlParam()[4];
window.getCmpUrlFive = Invoca.Client.parseCmpUrlParam()[5];
window.getCmpUrlTen = Invoca.Client.parseCmpUrlParam()[10];
window.getCmpUrlTwo = Invoca.Client.parseCmpUrlParam()[2];
window.getCmpUrlThree = Invoca.Client.parseCmpUrlParam()[3];
window.getCmpUrlZero = Invoca.Client.parseCmpUrlParam()[0];
window.getCmpUrlEleven = Invoca.Client.parseCmpUrlParam()[11];

Invoca.Client.campaignToSwap = function (cmpValue) {
  var campaignArray = ['mobility'];
  return campaignArray.some(function (el) {
    return cmpValue.toLowerCase().includes(el);
  });
};

Invoca.Client.campaignNotToSwap = function (cmpValue) {
  var campaignArray = ['bpur', 'cse'];
  return campaignArray.some(function (el) {
    return cmpValue.toLowerCase().includes(el);
  });
};

Invoca.Client.checkCampaignNames = function () {
  var campaignValue = Invoca.Client.getParamValue('cmp');
  if(!campaignValue || Invoca.Client.campaignNotToSwap(campaignValue)){
    return false;
  }
  return Invoca.Client.campaignToSwap(campaignValue);
};

Invoca.Client.isParamPresent = function () {
    var params = ['gclid', 'gbraid', 'wbraid'];
    return params.some(function (param) { 
        return Invoca.Client.getParamValue(param); 
    });
};

Invoca.Client.shouldRun=function() {
    if (Invoca.Client.checkCampaignNames() && Invoca.Client.isParamPresent()){
        return true;
    };
    return false;
};


options.integrations = {
  googleAnalytics: true,
  //Adobe ID pulled from Data layer found to be more reliable
  //adobeAnalytics: 
    //{username: "777B575E55828EBB7F000101@AdobeOrg",
    //},
};


options.autoRun = Invoca.Client.shouldRun();
return options;
  };

  return true;
})();

var generatedOptions = {
  active:              true,
  autoSwap:            false,
  cookieDays:          cacheLifetimeDays,
  country:             "US",
  dataSilo:            "us",
  defaultCampaignId:   defaultCampaignId,
  destinationSettings: destinationSettings,
  disableUrlParams:    [],
  doNotSwap:           [],
  integrations:        automaticIntegrations,
  maxWaitFor:          waitFor,
  networkId:           networkId || null,
  numberToReplace:     numbersToReplace,
  organicSources:      organicSources,
  poolParams:          {},
  reRunAfter:          reRunAfter,
  requiredParams:      requiredParams,
  resetCacheOn:        resetCacheOn,
  waitForData:         customDataWaitForConfig,
  waitForDataAnonymousFunctions:  customDataWaitForConfigAnonymousFunctions
};

Invoca.Client.startFromWizard(generatedOptions);

})(2676);
