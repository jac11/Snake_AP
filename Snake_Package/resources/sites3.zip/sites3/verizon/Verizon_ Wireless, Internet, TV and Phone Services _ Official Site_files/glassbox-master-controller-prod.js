// This rule runs on execVendorTags, which gaurentees vzdl (data layer) and vztag to exist
//var isDev = /securepp|sso-np.ebiz|qa|community-stage|localhost|securesit|www98|wwwnte|wwwnssit/i.test(location.host);

// if (isDev) {

var VERSION = "20250110";
// var PATH = location.href;
var PATH = location.href.split(/[?]/)[0];
var DETECTOR;
var ENVIRONMENT = "prod";
var GLASSBOX_MASTER_VERSION = "?" + ENVIRONMENT + "-master-v" + VERSION

// Helpers
function matchesPath(list,app) {
console.log("matchesPath:" + app)
  for (var i = 0; i < list.length; i++) {
    if (PATH.indexOf(list[i]) > -1) {
      console.log(app + " PATH:" + PATH + " matchesPath:list[i]:" + list[i] + " list:" + list + " i:" + i)
      return true + ":" + list[i];
    }
  }
  return false;
}

// common data-points
var spanish = /espanol/i.test(location.host);
var channel = window.vzdl && window.vzdl.page && window.vzdl.page.channel;
var intent = window.vzdl && window.vzdl.target && window.vzdl.target.engagement && window.vzdl.target.engagement.intent;
var accountType = window.vzdl && window.vzdl.user && window.vzdl.user.accountType;
var flow = window.vzdl && window.vzdl.page && window.vzdl.page.flow;
var page = window.vzdl && window.vzdl.page && window.vzdl.page.name;
var throttle = window.vzdl && window.vzdl.page && window.vzdl.page.throttle;
var businessUnit = window.vzdl && window.vzdl.env && window.vzdl.env.businessUnit;
var adobeProperty = window._satellite && window._satellite.property && window._satellite.property.name

// ############################
// Accessories - VCM
// ############################
if (matchesPath([
  "/home/accessories"
],"Accessories - VCM")) {

  DETECTOR = "https://gateway.verizonwireless.com/accessories-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Billing - VCM
  // ############################
  else if (matchesPath([
  "/foryourhome/billview",
  "/foryourhome/equickpay",
  "/foryourhome/ebillpay",
  "/expresspay",
  "/paymentmethods",
  "/autopay",
  "/mybill",
  "/billhistory",
  "/billdetails",
  "/comparebill",
  "/billhome",
  "/payment"
],"Billing - VCM")  || (/Payment Arrangement/i.test(channel) && /Payment Arrangement/i.test(flow) || /Payment Arrangement/i.test(flow) || /Payment Arrangement/i.test(channel) || /My Verizon/i.test(intent) || /Payment/i.test(flow) || /payment/i.test(flow) || /Pay Bill/i.test(channel) && /My Verizon/i.test(intent) || /Payment History/i.test(channel) || /mva3.0/i.test(channel) || /my verizon/i.test(intent) && matchesPath(["/payment/"],"Billing - VCM")
  )) {

  DETECTOR = "https://gateway.verizonwireless.com/billing-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Support - VCM
  // ############################
  else if (matchesPath([
  "/support/residential",
  "/support/consumer",
  "/foryourhome/vzrepair",
  "/foryourhome/VZRepair"
],"Support - VCM")) {

  DETECTOR = "https://gateway.verizonwireless.com/vcm-support-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Consumer  - MyVerizon - VCM
  // ############################
  else if (matchesPath([
  "/home/myverizon",
  "/consumer/myverizon",
  "/foryourhome/myaccount"
],"Consumer  - MyVerizon - VCM")) {

  DETECTOR = "https://gateway.verizonwireless.com/myverizon-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Consumer Learn - VCM
  // ############################
  else if (matchesPath([
  "/home",
  "/home/fiostv",
  "/home/fios-fastest-internet",
  "/home/bundles/fios",
  "/home/moving-nc",
  "/home/fios-forward",
  "/local",
  "/info",
  "/speedtest"
  // ,"/(\?.*)?$"
],"Consumer Learn - VCM")) {

  DETECTOR = "https://gateway.verizonwireless.com/learn-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Customer Ordering -VCM
  // ############################
  else if (matchesPath([
  "/foryourhome/ordering",
  "/personal",
  "/inhome",
  "/inhome/qualification",
  "/inhome/resumecart",
  "/inhome/checkout",
  "/rnb/promotions",
  "/rnb/plans",
  "/rnb/why-fios"
],"Customer Ordering -VCM")) {

  DETECTOR = "https://gateway.verizonwireless.com/ordering-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // SSO - VCM
  // ############################
  else if (matchesPath([
  "/vzauth",
  "/sso"
],"SSO - VCM")) {

  DETECTOR = "https://gateway.verizonwireless.com/vcm-sso-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)
}


  // ############################
  // Access Manager [(SSO) -VZW
  // ############################
  if (!spanish && /sso|authentication/i.test(channel)) {

  DETECTOR = "https://gateway.verizonwireless.com/vzw-sso-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  else if (matchesPath([
  "/signin",
  "/sdsecure",
  "/digital/nsa/nos/ui/identitymngt/imageVerification"
],"SSO - VZW")|| (/notifications/i.test(intent) && /account overview/i.test(flow) && /account management/i.test(channel) || /account settings/i.test(channel) || /account management/i.test(channel)) || /resumen de la cuenta/i.test(flow)) {

  DETECTOR = "https://gateway.verizonwireless.com/vzw-sso-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)
}
  // ############################
  // Postpay - Ebill; ManagePaymentMehod - OTP flow
  // ############################
  else if (/ebill/i.test(channel) || /Bill/i.test(channel) || /sso/i.test(channel) || /sso/i.test(intent)) {

  DETECTOR = "https://gateway.verizonwireless.com/myvpostpay-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Postpay
  // ############################
  else if (/Individual unv id|account management/i.test(intent)
  && /postpa/i.test(accountType)
  && matchesPath([
    "/ui",
    "/ui/acct/secure/productApps/landing-categorization",
    "/vzw/secure/orderhistory",
    "/digital/cpc",
    "/vzw/accountholder/payment/paymentHistoryOverview",
    "/digital/nsa/secure/ui/cpc",
    "/ui/acct/secure/numshare",
    "/myv/productsapps",
    "/myv/limitedavailability",
    "/vzw/accountholder/services/resetVPass.action",
    "/vzw/accountholder/alerts/home.action",
    "cws/viewLogin.action",
    "/vzw/secure/services/CallForward.action",
    "/aol",
    "/tys",
    "/as",
    "/digital/nsa/secure/ui",
    "/ui/hub/secure/overview",
    "/digital/nsa/secure/ui/acct/unifiedprofile/overview",
    "/account/reg/upf/user",
    "/digital/nsa/nos/ui/orders/trackmyorder",
    "/digital/nsa/secure/ui/orders"
  ],"Postpay") || (/My Devices/i.test(channel) && /mvo/i.test(flow) || /support/i.test(intent) || /Account Management/i.test(intent) && /account overview/i.test(channel) || /Account Management/i.test(intent)  && !/prepa/i.test(accountType) || /account overview/i.test(channel))) {

  DETECTOR = "https://gateway.verizonwireless.com/myvpostpay-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Postpay - TYS
  // ############################
  else if (/Individual unv id|tys/i.test(intent)
  && /postpa|unauthenticated/i.test(accountType)
  && matchesPath([
    "/tys/"],"Postpay - TYS")
) {

  DETECTOR = "https://gateway.verizonwireless.com/myvpostpay-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Postpay Individual unv id
  // ############################
  else if (/Individual unv id/i.test(intent)
  && matchesPath([
    "/digital/nsa/secure/ui/identitymngt/guest",],"Postpay Individual unv id")
) {

  DETECTOR = "https://gateway.verizonwireless.com/myvpostpay-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Postpay - Plus Play
  // ############################
  else if (/plus play/i.test(channel) && /plus play/i.test(flow)) {

  DETECTOR = "https://gateway.verizonwireless.com/myvpostpay-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Prepay
  // ############################

  else if (/account management/i.test(intent) && /prepa/i.test(accountType)) {

  DETECTOR = "https://gateway.verizonwireless.com/myvprepay-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Returns
  // ############################
  else if (matchesPath([
  "/digital/refund-exchange",
  "/sales/digital/refundexchange"],"Returns")
) {

  DETECTOR = "https://gateway.verizonwireless.com/digitalreturn-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Search
  // ############################
  else if (/search/i.test(intent) && /search/i.test(flow) || /search results/i.test(flow) || /Search/i.test(intent)) {

  DETECTOR = "https://gateway.verizonwireless.com/search-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Support -VZW
  // ############################
  else if (/support/i.test(flow)) {

  DETECTOR = "https://gateway.verizonwireless.com/vzw-support-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)

}
  // ############################
  // Shop
  // ############################
  else if (matchesPath([
    "/discounts/verizon-forward",
    "/sales/nextgen/expresscheckout/editshippingaddress.html",
    "/sales/nextgen/mdnselection.html",
    "/digital/nsa/nos/ui/acct/portintent/tracking",
    "/sales/next/expresscheckout.html"
],"Shop - VZW")
  ||/wireless/i.test(businessUnit) && /learn|store|order|sl/i.test(intent)
  || !DETECTOR && /internal server error|page no longer exist|home/i.test(page)
  || /\/(ryl|pp)\/|error\.html/i.test(PATH)
  || /nsa/i.test(throttle)
) {

  // These tests happened earlier in "if" logic, so no need to check against this
  // not isFiosPage
  // not /sales/digital/refundexchange/
  // not /digital/refund-exchange/
  // not channel = plus play
  // not flow = plus play

  DETECTOR = "https://gateway.verizonwireless.com/shop-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)
};

// ############################
// Privacy Policy
// ############################
if (/PrivacyPolicy/i.test(adobeProperty)) {
  DETECTOR = "https://gateway.verizonwireless.com/vzw-support-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)
}

// ############################
// Unknown
// ############################
// No rules match, load Unknown Detector
if (!DETECTOR) {
  DETECTOR = "https://gateway.verizonwireless.com/vzw-unknown-detector-" + ENVIRONMENT + ".js";
  console.log('SET DETECTOR', DETECTOR)
}

console.log('LOAD DETECTOR', DETECTOR)

// ############################
// Load it
// ############################
if (DETECTOR && typeof vztag !== "undefined" && vztag.utils && vztag.utils.Common && vztag.utils.Common.loadScript) {
  // NOTE vztag script loader handles nonce automatically !
  vztag.utils.Common.loadScript({
    url: DETECTOR + GLASSBOX_MASTER_VERSION, // cache-bust
    atts: {
      async: true,
      id: "_vzGB_Loader_vztag"
    }
  })
}

// NOTE vztag.utils.Common.loadScript function is not defined
else if (DETECTOR) {
  (function (url, id) {
    var script = document.createElement("script")
    script.type = "text/javascript";
    script.async = true;
    script.id = id || "";
    script.src = url;
    document.head.appendChild(script);
  })(DETECTOR + GLASSBOX_MASTER_VERSION, "_vzGB_Loader");
};
