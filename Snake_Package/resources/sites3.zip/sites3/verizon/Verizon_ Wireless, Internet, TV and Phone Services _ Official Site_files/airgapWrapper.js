/* WHAT THIS FILE DOES
 - configures and loads airgap.js on the page
 - reads consent value from local storage and sets to the window
 - updates local storage and DB if a logged in user is opted in and GPC signal is encountered
 - updates local storage and reports an non-logged in user as opted out if they are opted in and a GPC signal is encountered
 - controls the display of the privacy banner
*/

if (window.UDNS_ONLY) {
  console.log("=====AIRGAP TWICE");
} else {
  var userPreferenceNotified = false;
  document.addEventListener("airgapReady", () => {
    console.log("airgapReady event fired");
    if (userPreferenceNotified === false) {
      document.dispatchEvent(new CustomEvent("userPreference"));
      userPreferenceNotified = true;
    }
  });
  setTimeout(() => {
    document.dispatchEvent(new CustomEvent("airgapReady"));
  }, 6000);

  (async function () {
    window.UDNS_ONLY = 1;

    var isLowerEnv =
      /wwwnssit|securepp|community-stage|localhost|wwwnssit|ebiz.verizon|securesit|vzwqa|qa.billpay|plusplay-sit|esus-uat|stream-sit|sso-np|www98.verizon/i.test(
        location.host
      );

    const spanishPage =
      location.href.includes("espanol.verizon.com") ||
      location.href.includes("esus.verizon.com");
    location.href.includes("esus-uat.verizon.com") ||
      location.href.includes("es-vzwqa");

    cLog = function (txt, strc = 0) {
      if (window.UDNS_LOG > 0 || strc > 9 || isLowerEnv) {
        const e = new Error();
        if (!e.stack) {
          try {
            throw e;
          } catch (e) {
            if (!e.stack) {
            }
          }
        }
        const cLine = e.stack.toString().split(/\r\n|\n/);
        const nLine = cLine[2].trim().split(/\:/);

        console.log(`line ${nLine[2]}: ${txt}`);
      }
    };

    function setLclCk(cName, cVal, cExp = "") {
      cLog(`setting cookie: ${cName}: ${cVal}`);
      document.cookie =
        cName +
        "=" +
        cVal +
        "; domain=." +
        window.location.hostname.match(
          /^(?:.*?\.)?([a-zA-Z0-9\-_]{3,}\.(?:\w{2,8}|\w{2,4}\.\w{2,4}))$/
        )[1] +
        "; path=/; expires=" +
        cExp;
    }

    function getCk(cName) {
      var name = cName + "=";
      var ca = document.cookie.split(";");
      for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == " ") {
          c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
          cLog(`getting cookie: ${name}${c.substring(name.length, c.length)}`);
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }

    function activeGPC() {
      return (
        navigator.globalPrivacyControl === true ||
        navigator.globalPrivacyControl === "true" ||
        navigator.globalPrivacyControl === 1 ||
        navigator.globalPrivacyControl === "1" ||
        window.UDNS_PARMS.get("UDNS_GPC") === "true"
      );
    }

    window.getAEI = function () {
      var workAEI = {};
      workAEI.attestedExtraIdentifiers = window.UDNS_AEI;
      return JSON.stringify(workAEI);
    };

    function gatherAEIData() {
      cLog(`setting attested extra identifiers to window.UDNS_AEI`);
      function getKVal(val) {
        try {
          if (val.startsWith("ck!")) {
            return getCk(val.substr(3));
          } else {
            return eval(val);
          }
        } catch (e) {
          return "";
        }
      }

      var kTJ = {
        UniqDNSUserID: "window.UDNS_ID",
        UDNS_THROTTLE: "window.UDNS_THROTTLE",
        _gid: "ck!_gid",
        "User-Agent": "navigator.userAgent",
      };

      var newAEIjson = {};
      newAEIjson.email = [
        {
          value: getKVal(
            "window.UDNS_RES.body.data.privacyChoiceOptOutResponse.emailId"
          ),
        },
      ];
      newAEIjson.phone = [{ value: "" }];
      newAEIjson.custom = [{}];
      var custWork = {};
      var custom = [];
      for (var x in kTJ) {
        custWork = { name: x, value: getKVal(kTJ[x]) };
        custom.push(custWork);
      }
      newAEIjson.custom = custom;
      window.UDNS_AEI = newAEIjson;
    }

    function setNewPref(newPref) {
      cLog(`setting new preference on the window to: ${newPref}`);
      window.UDNS_PREV = window.UDNS_PR;
      window.UDNS_PR = newPref;

      var prDtChg = new Date();
      prDtChg.setTime(prDtChg.getTime());
    }

    window.handleConsentChange = function (consent) {
      cLog(
        `handling consent change - this function may not be used but need to verify on YPC pages that it is not being called on the window`
      );
      window.UDNS_PREV = window.UDNS_PR;
      window.UDNS_PR =
        consent.purposes.SaleOfInfo === false ||
        consent.purposes.SaleOfInfo === "false"
          ? "O"
          : "I";
      setLclCk("UDNS_PR", window.UDNS_PR, window.expireDateStr);
      window.UDNS_TS = consent.timestamp;
      setLclCk("UDNS_TS", window.UDNS_TS, window.expireDateStr);
    };

    function extractPath(currentLocation) {
      cLog(
        `extractPath called - might be able to remove and only used to set DNS_RETRIEVE_TRIGGERED_FROM cookie which is never referenced`
      );
      const fullUrl = new URL(currentLocation);
      // Extract pathname and remove leading or trailing slashes
      let path =
        fullUrl && fullUrl.pathname
          ? fullUrl.pathname.replace(/^\/|\/$/g, "")
          : "";
      // remove .html
      const hasHtml = path && path.includes(".html");
      if (hasHtml && path && path !== "") {
        path = path.replace(".html", "");
      }
      // get host www. and domain extension
      const host =
        fullUrl && fullUrl.host
          ? fullUrl.host.replace(/^www\./, "").split(".")[0]
          : "";
      return `${host}/${path}`;
    }

    async function setDefaultConsent() {
      await airgap
        .sync()
        .then(() =>
          airgap.setConsent(
            window.airgapScriptLoadEvent,
            { SaleOfInfo: false },
            { metadata: { ...(airgap.getConsent().metadata || {}) } }
          )
        )
        .then(() =>
          cLog(
            "setDefaultConsent() - not able to retrieve user preference from DB and setting airgap SaleOfInfo to false"
          )
        );
    }

    async function setProfile() {
      cLog("setting profile for logged in user");
      //set logged in status
      const loggedInWireline = getCk("islogin")?.includes("vzt");
      const loggedInWireless = getCk("loggedIn") === "true";
      let wirelineOnlyAccount = false;
      let unifiedLogin = false;
      if (loggedInWireline && !loggedInWireless) {
        wirelineOnlyAccount = true;
      }
      if (loggedInWireless && loggedInWireline) {
        unifiedLogin = true;
      }
      cLog(
        `setProfile() - logged in status - wireline: ${loggedInWireline}, wireless: ${loggedInWireless}`
      );
      const currentLocation =
        window && window.location && window.location.href
          ? window.location.href
          : " ";

      setLclCk(
        "DNS_RETRIEVE_TRIGGERED_FROM",
        extractPath(currentLocation),
        window.expireDateStr
      );

      cLog("setProfile() - getting preference from DB");
      fetch(
        "https://" +
          APIDomainName +
          "/soe/digital/auth/dns/customerprofile/retrieve-global-optout-prefs",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          referrerPolicy: "strict-origin-when-cross-origin",
          mode: "cors",
          credentials: "include",
        }
      )
        .then((response) => {
          if (!response.ok) {
            setDefaultConsent();
            throw Error(
              "Get HTTP error: " +
                response.status +
                " text: " +
                response.statusText
            );
          }
          return response.json();
        })
        .then((fetchResponse) => {
          cLog(
            `setProfile() - profile retrieved from DB: ${JSON.stringify(fetchResponse)}`
          );
          window.UDNS_RES = fetchResponse;
          var newPrefVal = "";
          try {
            newPrefVal =
              fetchResponse.data.globalOptOutPrefs[0].optOutFlags[0].value ===
              "N"
                ? "I"
                : "O";
            cLog("setProfile() - user preference value from DB:" + newPrefVal);
          } catch (e) {
            throw Error(
              "setProfile() error - user preference value not found in DB response: " +
                e.message
            );
          }
          return newPrefVal;
        })
        .then(async (preferenceFromDb) => {
          cLog(
            "setProfile() - preference value returned from DB:" +
              preferenceFromDb
          );
          if (preferenceFromDb === "I" && activeGPC()) {
            cLog(
              "setProfile() - GPC signal while opted in and user is opted in"
            );
            gatherAEIData();
            let dbResponse = {};
            try {
              dbResponse = window.UDNS_RES.data.globalOptOutPrefs[0];
            } catch (e) {
              throw Error(
                "setProfile() - no preference value is response from DB " +
                  e.message
              );
            }
            const priorPrefValue = dbResponse.optOutFlags[0].value;
            const newPrefValue = "Y";
            const postJson = {
              visitorSessionId: wirelineOnlyAccount ? "" : window.UDNS_ID,
              requestType: "GPC",
              unifiedLogin,
              emailId: "",
              firstName: "",
              lastName: "",
              mtn: "",
              optOutFlags: [{ newValue: newPrefValue }],
              globalOptOutPrefs: [
                {
                  accountId: wirelineOnlyAccount
                    ? window.UDNS_ID // CHECK AND SEE IF THIS IS NEEDED - WORKS THE SAME WITHOUT IT
                    : dbResponse.accountId,
                  serviceType: wirelineOnlyAccount
                    ? "vzt"
                    : dbResponse.serviceType,
                  role: wirelineOnlyAccount ? "vzt" : "",
                  optOutFlags: [
                    {
                      type: dbResponse.optOutFlags[0].type,
                      prevValue: priorPrefValue,
                      newValue: newPrefValue,
                    },
                  ],
                },
              ],
              transcendJson: window.UDNS_AEI,
            };

            await airgap
              .sync()
              .then(() =>
                airgap.setConsent(
                  window.airgapScriptLoadEvent,
                  { SaleOfInfo: false },
                  { metadata: { ...(airgap.getConsent().metadata || {}) } }
                )
              )
              .then(() =>
                cLog("setProfile() - airgap SaleOfInfo set to false")
              );

            cLog(
              `setProfile() - Updating Preference in DB with ${newPrefValue}`
            );
            fetch(
              "https://" +
                APIDomainName +
                "/soe/digital/auth/dns/ccpa-core/updateGlobalOptOut",
              {
                method: "POST",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                },
                referrerPolicy: "no-referrer-when-downgrade",
                mode: "no-cors",
                credentials: "include",
                body: JSON.stringify(postJson),
              }
            )
              .then((response) => {
                if (!response.ok) {
                  throw Error(
                    "HTTP not ok error code: " +
                      response.status +
                      " text: " +
                      response.statusText
                  );
                }
                if (response.status != 200) {
                  throw Error(
                    "HTTP error code: " +
                      response.status +
                      " text: " +
                      response.statusText
                  );
                }
                cLog(
                  `setProfile() - response after update call: ${JSON.stringify(response.json())}`
                );
                return response;
              })
              .catch((e) => {
                console.log(
                  `setProfile() - error updating user profile: ${e.message}`
                );
                return false;
              });
          } else {
            cLog(`setProfile() - no conflict between GPC and users preference`);
            setNewPref(preferenceFromDb);
            await airgap
              .sync()
              .then(() =>
                airgap.setConsent(
                  window.airgapScriptLoadEvent,
                  { SaleOfInfo: preferenceFromDb === "O" ? false : true },
                  { metadata: { ...(airgap.getConsent().metadata || {}) } }
                )
              )
              .then(() =>
                cLog(
                  `setProfile() - airgap SaleOfInfo set with: ${preferenceFromDb === "O" ? false : true}`
                )
              );
          }
          window.userPreference = "L";
          document.dispatchEvent(new CustomEvent("airgapReady"));
        })
        .catch(async (e) => {
          cLog(`setProfile() - error setting user profile: ${e.message}`);
          setDefaultConsent();
          return false;
        });
      return true;
    }

    async function setProfileGuest() {
      cLog("setGuestProfile()");
      var priorPrefValue = window.UDNS_PREV === "I" ? "N" : "Y";
      var newPrefValue = window.UDNS_PR === "I" ? "N" : "Y";
      var postJson = {
        visitorSessionId: window.UDNS_ID,
        requestType: "GPC",
        unifiedLogin: "false",
        emailId: "",
        firstName: "",
        lastName: "",
        mtn: "",
        globalOptOutPrefs: [
          {
            accountId: "",
            serviceType: "guest",
            role: "",
            optOutFlags: [
              {
                type: "DT",
                prevValue: priorPrefValue,
                newValue: newPrefValue,
              },
            ],
          },
        ],
        transcendJson: window.UDNS_AEI,
      };

      fetch(
        "https://" +
          APIDomainName +
          "/soe/digital/prospect/dns/ccpa-core/updateGlobalOptOut",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          referrerPolicy: "no-referrer-when-downgrade",
          mode: "no-cors",
          credentials: "include",
          body: JSON.stringify(postJson),
        }
      )
        .then((response) => {
          if (!response.ok) {
            throw Error(
              "setProfileGuest() - write to DB failing: " + response.status
            );
          }
          return response.json();
        })
        .then(async (responseFromDb) => {
          cLog(
            `setProfileGuest() - DB response after update call: ${JSON.stringify(responseFromDb)}`
          );
          window.UDNS_POST = responseFromDb;

          if (responseFromDb.statusCode != "200") {
            cLog(
              "setProfileGuest() - DB call error: " +
                responseFromDb.statusCode +
                " Text: " +
                responseFromDb.statusMessage
            );
          }
          await airgap
            .sync()
            .then(() =>
              airgap.setConsent(
                window.airgapScriptLoadEvent,
                { SaleOfInfo: false },
                { metadata: { ...(airgap.getConsent().metadata || {}) } }
              )
            )
            .then(() =>
              cLog(`setProfileGuest() - airgap saleOfInfo set to false`)
            );

          window.userPreference = "G";
          document.dispatchEvent(new CustomEvent("airgapReady"));
        });
      return true;
    }

    function clearAirgapConsent(partition) {
      const logPrefix = "clearAirgapConsent() - ";

      const consentString = localStorage.getItem("tcmMPConsent");
      if (consentString) {
        try {
          const parsed = JSON.parse(consentString);
          const consentWithPartition = parsed[partition];
          if (consentWithPartition) {
            delete parsed[partition];
            localStorage.setItem("tcmMPConsent", JSON.stringify(parsed));
            cLog(
              logPrefix + "Successfully cleared out partition key: " + partition
            );
          } else {
            cLog(
              logPrefix +
                "Skipping as no consent preferences found with partition key: " +
                partition
            );
          }
        } catch (err) {
          console.log(
            logPrefix + "tcmMPConsent was not valid JSON - " + err.message
          );
        }
      } else {
        cLog(
          logPrefix +
            "Skipping airgap partition clearing as no value was found in local storage" +
            partition
        );
      }
    }

    const ON_YPC = /\/privacy\/your-privacy-choices/i.test(
      window.location.href
    );

    // URL Parameters
    const URL_PARMS = (window.UDNS_PARMS = new URLSearchParams(
      window.location.search
    ));
    const GPC_URL_PARM = URL_PARMS.get("UDNS_GPC"); //set to 1 to simulate a GPC signal
    const LOG_URL_PARM = URL_PARMS.get("UDNS_LOG"); //set to 1 to see all cLogs
    const PR_URL_PARM = URL_PARMS.get("UDNS_PR"); //set to 0 to opt user in and 1 to opt out
    const USE_V_FILES_URL_PARM = URL_PARMS.get("USE_V_FILES"); //set to 1 to override throttle and force loading of Transcend files stored on Verizon servers
    const PRIVACY_BANNER_URL_PARM = URL_PARMS.get("PRIVACY_BANNER"); //set to 1 to display privacy banner for testing purposes
    if (LOG_URL_PARM > 0) {
      window.UDNS_LOG = LOG_URL_PARM;
    }

    clearAirgapConsent("verizonv1");

    // Pull the existing getConsent value from local storage
    const TCM_CONSENT_STRING = localStorage.getItem("tcmMPConsent");
    const TCM_CONSENT_OBJECT = TCM_CONSENT_STRING
      ? JSON.parse(TCM_CONSENT_STRING)
      : undefined;

    window.UDNS_GPC = GPC_URL_PARM === "true";
    if (window.UDNS_GPC) {
      try {
        Navigator.globalPrivacyControl = 1;
        navigator.globalPrivacyControl = 1;
      } catch (e) {
        cLog(`error trying to access navigator object ${e.message}`);
      }
    }

    const EXPIRE_DT = new Date();
    var nowInHours = Math.round(EXPIRE_DT.getTime() / (3600 * 1000));
    EXPIRE_DT.setTime(EXPIRE_DT.getTime() + 365 * 86400 * 1000);
    window.expireDateStr = EXPIRE_DT.toUTCString();
    window.SITE_LI =
      getCk("loggedIn") === "true" ||
      // getCk("isLogin") === "true" ||
      // getCk("islogin") === "true" ||
      getCk("islogin") === "vzt";

    setTimeout(() => {
      window.userPreference = window.userPreference || "T";
      document.dispatchEvent(new CustomEvent("airgapReady"));
    }, 12000);

    let APIDomainName = "www.verizon.com";
    let qaFileDomain = "stcache-ws.vzw.com";
    if (/vzwqa/i.test(location.host)) {
      if (/vzwqa1/i.test(location.host)) {
        APIDomainName = "vzwqa1.verizonwireless.com";
        qaFileDomain = "vzwqa1.verizonwireless.com";
      } else if (/vzwqa2/i.test(location.host)) {
        APIDomainName = "vzwqa2.verizonwireless.com";
        qaFileDomain = "vzwqa2.verizonwireless.com";
      } else if (/vzwqa3/i.test(location.host)) {
        APIDomainName = "vzwqa3.verizonwireless.com";
        qaFileDomain = "vzwqa3.verizonwireless.com";
      } else if (/vzwqa4/i.test(location.host)) {
        APIDomainName = "vzwqa4.verizonwireless.com";
        qaFileDomain = "stcache-ws.vzw.com";
      }
    } else if (/www98.verizon.com/i.test(location.host)) {
      APIDomainName = "vzwqa2.verizonwireless.com";
    }

    //code required by Transcend
    if (!self.airgap) {
      self.airgap = {
        readyQueue: [],
        ready(callback) {
          this.readyQueue.push(callback);
        },
        ...self.airgap,
      };
    }

    // Set the instance-specific Bundle ID Here
    const BUNDLE_ID = "bd0b8b9f-5923-43cc-8ad9-f32ea8522b5c";
    const airgapSandboxBundleId = "d8bc158b-2cc9-4cc9-ac66-e376e0ce2f77";
    const SYNC_GRP =
      "3e1db8d7e927e65ebdea683143ab1db4511e86f8dfad7916b7808217b30683af";

    function generateId() {
      cLog("generateId() - generating new UNDS_ID");
      let randomString = String(
        Math.random().toString(16) +
          Date.now().toString(16) +
          Math.random().toString(16)
      ).replace(/0*\./g, "");
      let id =
        randomString.substring(0, 8) +
        "-" +
        randomString.substring(8, 4) +
        "-4" +
        randomString.substring(12, 3) +
        "-" +
        randomString.substring(15, 4) +
        "-" +
        randomString.substring(19, 12);
      return id;
    }
    // UDNS_ID: Get the uniq visitor/browser ID or create one
    var localID = (window.UDNS_ID =
      TCM_CONSENT_OBJECT?.[SYNC_GRP]?.metadata?.UDNS_ID);
    if (!localID) {
      cLog(`no UNDS_ID found in airgap metadata`);
      window.UDNS_ID = generateId();
    }

    gatherAEIData();

    function findNonce() {
      var elem = document.querySelector(
        '[nonce], meta[http-equiv="Content-Security-Policy"][content*="nonce-"]'
      );
      var nonceVal = "";
      if (elem) {
        // bad:
        //var nonceVal = elem.nonce || elem.getAttribute('nonce') || (elem.getAttribute('content') || "").match(/nonce-([0-9a-zA-Z]+)/)[1] || '';
        // can only read nonce directly (yes, yuck)
        // See: https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/nonce
        if (document.querySelector("[nonce]")) {
          nonceVal = document.querySelector("[nonce]").nonce;
        }

        if (!nonceVal) {
          var elem = document.querySelector(
            'meta[http-equiv="Content-Security-Policy"][content*="nonce-"]'
          );
          if (elem) {
            var content = elem.getAttribute("content");
            if (content) {
              var arr = content.match(/nonce-([0-9a-zA-Z]+)/);
              // when match not found, no array is returned... e.g. when content="nonce-"
              if (arr && typeof arr == "object" && arr.length) {
                nonceVal = arr[1];
              }
            }
          }
        }
      }

      return nonceVal;
    }

    var nonceVal = "";
    if (document.querySelector("[nonce]")) {
      nonceVal = document.querySelector("[nonce]").nonce;
    } else {
      nonceVal = findNonce();
    }

    const isStoresPaymentOptionsPage =
      window.location.href.indexOf("stores/payment-options") > -1;

    const script = document.createElement("script");

    let ctaCssFilePath =
      "https://cdn.transcend.io/cm/75db5e78-0d69-4554-a3bd-84b72ca3b3d9/cm.css";
    let VERIZON_QA_PATH = "https://" + qaFileDomain + "/vendor/transcend/vcg";
    const VERIZON_PROD_PATH = "https://scache-ws.vzw.com/vendor/transcend/vcg";

    let filePath = VERIZON_PROD_PATH;
    if (isLowerEnv) {
      filePath = VERIZON_QA_PATH;
    }

    let SYNC_ENDPOINT = `${VERIZON_QA_PATH}/xdi.html`;
    //if statement accounts for prod or QA pages on sso-np.ebiz.verizon.com
    if (/verizon.com/i.test(location.host)) {
      SYNC_ENDPOINT = `https://secure.verizon.com/vendor/transcend/vcg/xdi.html`;
    }

    //alternate CSS file never needs to load from sandbox location
    ctaCssFilePath = filePath + "/cmCTA.css";

    if (getCk("useAirgapSandbox") === "true") {
      cLog("using airgap sandbox instance");
      filePath = `https://cdn.transcend.io/cm-test/${airgapSandboxBundleId}`;
      script.setAttribute("data-messages", `${filePath}/translations/`);
    } else if (spanishPage) {
      script.setAttribute(
        "data-messages",
        "https://espanol.scache-ws.vzw.com/vendor/transcend/vcg/"
      );
    } else {
      script.setAttribute("data-messages", filePath);
    }

    airJsFile = filePath + "/airgap.js";
    if (USE_V_FILES_URL_PARM === "0") {
      cLog("loading airgap and related files from Transcend QA servers");
      filePath = `https://cdn.transcend.io/cm-test/${BUNDLE_ID}`;
      airJsFile = `${filePath}/airgap.js?=v${nowInHours}`;
      script.setAttribute("data-messages", `${filePath}/translations/`);
    }

    script.setAttribute("data-css", filePath + "/cm.css");
    script.setAttribute("src", airJsFile);
    script.setAttribute("data-ui", filePath + "/ui.js");

    var avoidCTA =
      location.pathname.indexOf("/nextgendigital/sales/configurator") === 0 ||
      location.pathname.indexOf("/nextgendigital/sales/checkout") === 0 ||
      location.pathname.indexOf("/plans/unlimited") === 0 ||
      location.pathname.indexOf("/sales/nextgen") === 0;

    //if there are pages with calls to action at the bottom
    // reference the css file from a different airgap instance
    //that raises the privacy banner up from the bottom of the page
    if (avoidCTA) {
      script.setAttribute("data-css", ctaCssFilePath);
    }

    //disable tamper resistance because airgap loads with this very strict mode
    //that blocks other scripts from patching iterators causing issues like symbol.iterator errors
    script.setAttribute("data-tamper-resist", "off");
    //required by Transcend
    script.setAttribute("nonce", findNonce());
    //Enabling Shadowroot to add tags for acccessibility
    script.setAttribute("data-ui-shadow-root", "open");
    //disable non-context-realm auto-protection - airgap was throwing errors when encountering empty documents in ‘miniPdp’ iframe
    //adding this when moving to v9.13.0  - can be removed once a fix is in place for realm auto-protection features
    script.setAttribute("data-protect-realms", "self");
    //turns off telemetry for browsers that do not contain initiator information (Safari)
    script.setAttribute("data-require-tfpf", "on");
    //disable baseURI propagation which can help prevent CSP base-uri errors from occurring - specifically for verizon.com/inhome/buildproducts
    script.setAttribute("data-bup", "off");
    //allows cookie based syncing when local storage based syncing is not an option as in Safari
    script.setAttribute("data-local-sync", "allow-network-observable");

    if (isStoresPaymentOptionsPage) {
      script.setAttribute("data-telemetry", "off");
    }

    script.dataset.syncEndpoint = SYNC_ENDPOINT;

    // sets advanced logging which shows logs from airgap.js
    if (window.UDNS_LOG > 2) {
      script.dataset.log = "*";
    }

    script.onload = async function (event) {
      cLog("airgapScript tag onload event callback fired");
      window.airgapScriptLoadEvent = event;

      if (!getCk("localStorageConsentChecked")) {
        cLog("checking for consent value in local storage");
        const localStorageConsent = JSON.parse(
          localStorage.getItem("tcmMPConsent")
        );
        const fourHundredDaysFromNow = new Date(
          Date.now() + (1000 + 60 + 60 + 24) * 400
        ).toUTCString();

        if (localStorageConsent) {
          let { purposes, ...additionalConsentValues } =
            localStorageConsent[SYNC_GRP];

          airgap
            .sync()
            .then(() => {
              airgap.setConsent(airgapScriptLoadEvent, purposes, {
                ...additionalConsentValues,
              });
            })
            .then(() => {
              setLclCk("localStorageConsentChecked", 1, fourHundredDaysFromNow);
              cLog(`consent migrated from localStorage to tcm cookie`);
            });
          handleConsentChange(localStorageConsent[SYNC_GRP]);
        } else {
          setLclCk("localStorageConsentChecked", 1, fourHundredDaysFromNow);
          cLog(
            "no consent value found in local storge to migrate to tcm cookie"
          );
        }
      }

      if (!isLowerEnv && !localStorage.consentMigrated) {
        let fromEndpoint =
          "https://www.verizonwireless.com/vendor/transcend/vzw/xdi.html";

        if (/verizon.com/i.test(location.host)) {
          fromEndpoint = "https://www.verizon.com/vendor/transcend/vz/xdi.html";
        }

        try {
          cLog(`Migrating consent data from ${fromEndpoint}`);
          const currentConsent = self?.airgap?.getConsent?.();
          const channel = await self?.transcend?.xdi?.connect?.(
            fromEndpoint,
            6000
          );

          if (!channel) {
            throw new Error(
              `Unable to connect to sync endpoint during migration: ${fromEndpoint}`
            );
          }

          const {
            consent,
            metadata = {
              metadata: consent.metadata,
              timestamp: consent.metadataTimestamp,
            },
          } = await channel.run("ConsentManager:Sync", {
            consent: currentConsent,
            metadata: currentConsent?.metadata,
            sync: ["consent"],
          });

          await self?.airgap?.setConsent?.(
            window.airgapScriptLoadEvent,
            consent.purposes,
            {
              metadata: metadata.metadata,
              metadataTimestamp: metadata.timestamp,
              ...consent,
            }
          );
          localStorage.consentMigrated = 1;
          cLog(`Successfully migrated consent from ${fromEndpoint}`);
        } catch (error) {
          cLog(
            `Error in migrating consent from old sync endpoint to new: ${error.message}`
          );
        }
      } else {
        cLog("script.onload() - consent has already been migrated");
      }

      try {
        window.UDNS_PR =
          airgap.getConsent().purposes.SaleOfInfo === false ||
          purposes.SaleOfInfo === "false"
            ? "O"
            : "I";
        cLog(`setting consent from airgap: ${window.UDNS_PR}`);
      } catch (e) {
        console.log("not able to get consent from airgap: " + e.message);
      }

      if (PR_URL_PARM) {
        cLog("overriding consent with URL parameter");
        window.UDNS_PR = PR_URL_PARM;
        window.UDNS_PREV = window.UDNS_PREV;
        await airgap
          .sync()
          .then(() =>
            airgap.setConsent(
              window.airgapScriptLoadEvent,
              { SaleOfInfo: window.UDNS_PR === "O" ? false : true },
              { metadata: { ...(airgap.getConsent().metadata || {}) } }
            )
          )
          .then(() =>
            cLog(
              `saleOfInfo set in airgap: ${window.UDNS_PR === "O" ? false : true}`
            )
          );
      }
      await airgap.sync().then(() => {
        window.INITIAL_UDNS_ID = airgap.getConsent().metadata?.UDNS_ID;
        if (window.INITIAL_UDNS_ID) {
          if (window.UDNS_ID != window.INITIAL_UDNS_ID) {
            cLog(
              `window.UDNS_ID value does not match value found in airgap metadata and setting window to airgap value`
            );
            window.UDNS_ID = window.INITIAL_UDNS_ID;
          }
        } else {
          window.UDNS_ID = generateId();
        }
      });

      if (window.INITIAL_UDNS_ID != window.UDNS_ID) {
        cLog("window.UDNS_ID does not match value in airgap metadata");
        await airgap
          .sync()
          .then(() =>
            airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
              ...(airgap.getConsent().metadata || {}),
              UDNS_ID: window.UDNS_ID,
            })
          )
          .then(() => cLog("adding window.UDNS_ID value to airgap metadata"));
      }

      if (window.UDNS_LOG) {
        await airgap
          .sync()
          .then(() =>
            airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
              ...(airgap.getConsent().metadata || {}),
              UDNS_LOG: window.UDNS_LOG,
            })
          )
          .then(() =>
            cLog("Logging preference has been set to the airgap metadata")
          );
      }

      if (window.UDNS_PR === "O") {
        cLog(
          "UNDS_PR is O so replacing the last digits of the UDNS_ID with 00 to include them in the throttle"
        );
        window.UDNS_ID = window.UDNS_ID.slice(0, 34) + "00";
      }

      if (window.INITIAL_UDNS_ID != window.UDNS_ID) {
        cLog("window.UDNS_ID does not match value in airgap metadata");
        await airgap
          .sync()
          .then(() =>
            airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
              ...(airgap.getConsent().metadata || {}),
              UDNS_ID: window.UDNS_ID,
            })
          )
          .then(() => cLog("adding window.UDNS_ID value to airgap metadata"));
      }

      if (SITE_LI) {
        cLog("starting logged in user flow");
        window.VCG_RTRV = airgap.getConsent().metadata?.VCG_RTRV || 0;

        if (
          window.VCG_RTRV < nowInHours - 2 ||
          (activeGPC() && window.UDNS_PR != "O")
        ) {
          cLog(
            `it has been longer than 2 hours since a DB call has verified the users preference: ${window.VCG_RTRV < nowInHours - 2}`
          );
          cLog(
            `conflict between GPC and user preference: ${activeGPC() && window.UDNS_PR != "O"}`
          );
          await setProfile();
          window.VCG_RTRV = nowInHours;
          await airgap
            .sync()
            .then(() =>
              airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
                ...(airgap.getConsent().metadata || {}),
                VCG_RTRV: window.VCG_RTRV,
              })
            )
            .then(() =>
              cLog(`setting airgap metadata VCG_RTRV: ${window.RTRV}`)
            );
        } else {
          window.userPreference = "C";
          cLog("airgapReady event dispatched");
          document.dispatchEvent(new CustomEvent("airgapReady"));
        }
      } else {
        cLog("starting prospect user flow");
        if (activeGPC() && window.UDNS_PR != "O") {
          cLog("conflict with GPC and user preference");
          setNewPref("O");
          gatherAEIData();
          await setProfileGuest();
        } else {
          window.userPreference = "U";
          cLog("dispatching airgapReady event");
          document.dispatchEvent(new CustomEvent("airgapReady"));
        }
        await airgap
          .sync()
          .then(() =>
            airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
              ...(airgap.getConsent().metadata || {}),
              VCG_RTRV: 1,
            })
          )
          .then(() =>
            cLog("setting airgap metadata with VCG_RTRV with value of 1")
          );
      }

      try {
        if (getCk("geoC") === "1") {
          const userLocationData = JSON.parse(localStorage.getItem("objGeo"));
          cLog("user location in local storage: ", userLocationData);
          if (userLocationData.ctry === "us") {
            preparePrivacyBanner();
          } else {
            setUserLocation();
          }
        } else {
          setUserLocation();
        }
      } catch (error) {
        cLog("user location not found in local storage");
        setUserLocation();
      }
      if (PRIVACY_BANNER_URL_PARM === "1") {
        transcend.showConsentManager({ viewState: "PrivacyPolicyNotice" });
        cLog("forcing privacy banner display with URL parameter");
      }
    };

    self.airgap.ready((airgap) => {
      cLog("airgap loaded callback");

      airgap.addEventListener(
        "consent-change",
        async ({ detail: { consent, oldConsent, changes } }) => {
          cLog(
            `consent-change event fired with SaleOfInfo: ${consent.purposes.SaleOfInfo}`
          );
          window.UDNS_PREV = window.UDNS_PR;
          window.UDNS_PR =
            consent.purposes.SaleOfInfo === false ||
            consent.purposes.SaleOfInfo === "false"
              ? "O"
              : "I";
          window.UDNS_TS = consent.timestamp;

          setLclCk("UDNS_PR", window.UDNS_PR, window.expireDateStr);
          setLclCk("UDNS_TS", window.UDNS_TS, window.expireDateStr);
        }
      );
    });

    document.head.appendChild(script);

    /* ------------ Implement Privacy Banner Notification Begin ------------ */

    async function setUserLocation() {
      cLog("setUserLocation()");
      let apiUrl = "https://www.verizon.com/business/geoloc.json";
      if (isLowerEnv) apiUrl = "https://www98.verizon.com/business/geoloc.json";

      try {
        const response = await fetch(apiUrl, { referrerPolicy: "origin" });
        if (!response.ok) {
          throw new Error(`Response status: ${response.status}`);
        }
        const userLocationData = await response.json();
        cLog(
          "setUserLocation() - user location data from geoloc.json API: " +
            JSON.stringify(userLocationData)
        );
        localStorage.setItem("objGeo", JSON.stringify(userLocationData));
        setLclCk("geoC", 1);
        if (
          userLocationData.ctry === "us" ||
          userLocationData.ctry === undefined ||
          userLocationData.ctry === null ||
          userLocationData.ctry === ""
        )
          preparePrivacyBanner();
      } catch (error) {
        cLog(
          "setUserLocation() - error in getting user location geoloc API - " +
            error.message
        );
        preparePrivacyBanner();
      }
    }

    function handleBannerClose() {
      airgap
        .sync()
        .then(() =>
          airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
            ...(airgap.getConsent().metadata || {}),
            UDNS_NTCD: Date.now(),
            UDNS_NTCV: 0,
          })
        )
        .then(() =>
          cLog(
            `handleBannerClose - airgap metadata values set UNDS_NTCD to now and UNDS_NTCV to 0`
          )
        );

      try {
        document.getElementsByClassName(
          "gnav20-footer-level-two"
        )[0].style.paddingBottom = "";
        cLog("handleBannerClose() - removing additional padding from footer");
      } catch (error) {
        cLog(
          `handleBannerClose() - not able to select footer and remove padding`
        );
      }

      if (window.bannerClosedWithKeyboard) {
        try {
          document
            .getElementsByClassName("gnav20-header-accessibility")[0]
            .focus();
        } catch (error) {
          cLog(
            "banner was closed with keyboard but no Accessibility Resource Center available to set focus on"
          );
        }
      }

      window.coreData = window.coreData || [];
      window.coreData.push({
        task: "emit",
        event: "linkClick",
        params: {
          name: "privacy banner close",
          detail: "PRIVACY_BANNER_DISPLAY",
        },
      });
    }

    function preparePrivacyBanner() {
      window.displayNTC = function () {
        cLog("displayNTC");
        try {
          document.getElementsByClassName(
            "gnav20-footer-level-two"
          )[0].style.paddingBottom = "210px";
          cLog("setting padding on footer");
        } catch (error) {
          console.log("not able to select the footer to adjust padding");
        }

        // Log the display of the Privacy Banner - used by Adobe Analytics
        window.coreData = window.coreData || [];
        window.coreData.push({
          task: "emit",
          event: "openView",
          params: {
            selector: "#transcend-consent-manager",
            name: "PRIVACY_BANNER_DISPLAY",
            trackAs: "link",
          },
        });

        transcend.showConsentManager({ viewState: "PrivacyPolicyNotice" });
        cLog(
          `transcend.showConsentManager() - displaying the banner | setting window.UDNS_NTC_VISUAL to now`
        );
        window.UDNS_NTC_VISUAL = Date.now();
      };

      var inApp = /(MY_VZW_APP|MFA)/i.test(
        (navigator && navigator.userAgent) || ""
      );
      var inFiosTV = /(client_id=VerizonTVAgent)/i.test(
        window.location.href || ""
      );
      var inStreamTV = /(client_id=StreamTVAgent)/i.test(
        window.location.href || ""
      );
      if (
        getCk("UDNS_NTCBLK") != "TRUE" &&
        inApp != true &&
        inFiosTV != true &&
        inStreamTV != true
      ) {
        cLog(
          "privacy banner not being blocked by cookie and not in mobile app"
        );
        var NTCinit = 0;
        for (let i = 500; i < 5001; i += 250) {
          setTimeout(() => {
            if (NTCinit === 0) {
              if (
                typeof transcend === "object" &&
                typeof transcend.addEventListener === "function"
              ) {
                cLog("Transcend loaded and ready to display banner");
                NTCinit = i;
                BuildAndShowNTC();
              } else {
                //wait another 500ms for transcend to load
              }
            }
          }, i);
        }
      }

      function BuildAndShowNTC() {
        cLog("BuildAndShowNTC()");
        if (typeof transcend != "object") {
          cLog(
            "BuildAndShowNTC() - Transcend Not Yet Loaded - returning out of BuildAndShowNTC"
          );
          return 0;
        }

        transcend.addEventListener(
          "view-state-change",
          ({ detail: { viewState, previousViewState } }) => {
            cLog("view-state-change event fired");
            if (
              viewState === "Hidden" &&
              previousViewState === "PrivacyPolicyNotice"
            ) {
              cLog(
                "Transcend view-state-change event callback - banner has been closed"
              );
              handleBannerClose();
            } else {
              cLog(
                "Transcend view-state-change event callback - display of the banner has been tiggered"
              );

              function updateUi(privacyBanner) {
                cLog("updateUI()");
                try {
                  privacyBanner.querySelector(":first-child").style.outline =
                    "none";

                  let privacyLink = privacyBanner.querySelector("a");
                  privacyLink.setAttribute("tabindex", "0");
                  privacyLink.setAttribute(
                    "class",
                    "privacyPolicyBannerAnchor"
                  );
                  privacyLink.focus();

                  let closeBtn = privacyBanner.querySelector("button");
                  //cloning close button to remove Transcend event listener that was causing polfill issues and preventing the banner from closing on pages with Angular
                  const newBtn = closeBtn.cloneNode(true);
                  closeBtn.parentNode.replaceChild(newBtn, closeBtn);
                  newBtn.setAttribute("data-initialfocus", false);
                  newBtn.addEventListener("click", (event) => {
                    if (event.pointerType == "") {
                      window.bannerClosedWithKeyboard = true;
                    }
                    transcend.toggleConsentManager();
                    airgap.setConsent(
                      window.airgapScriptLoadEvent,
                      {},
                      { confirmed: true }
                    );
                  });
                } catch (error) {
                  cLog(
                    "not able to select elements in the privacy banner: " +
                      error.message
                  );
                }
              }

              let privacyBanner = null;
              const bannerCheck = setInterval(() => {
                privacyBanner = document
                  .querySelector("#transcend-consent-manager")
                  .shadowRoot.querySelector("#consentManagerMainDialog");
                if (privacyBanner) {
                  cLog("banner loaded on page");
                  updateUi(privacyBanner);
                  clearInterval(bannerCheck);
                }
              }, 250);
              setTimeout(() => clearInterval(bannerCheck), 5000);
            }
          }
        );

        const airgapMetadata = airgap.getConsent().metadata;
        window.UDNS_NTCD = airgapMetadata?.UDNS_NTCD
          ? Number(airgapMetadata.UDNS_NTCD)
          : 0;
        var bannerDismissalDate = airgapMetadata?.UDNS_NTCD
          ? Number(airgapMetadata.UDNS_NTCD)
          : 0;
        var sessionsWithBanner = airgapMetadata?.UDNS_NTCV
          ? Number(airgapMetadata.UDNS_NTCV)
          : 0;

        cLog(
          `BuildAndShowNTC() - setting window values regarding display of banner from airgap metadata\n
              airgapMetadata: ${JSON.stringify(airgapMetadata)}\n
              bannerDismissalDate: ${bannerDismissalDate}\n
              sessionsWithBanner: ${sessionsWithBanner}`
        );

        if (bannerDismissalDate < Date.now() - 7.776e9) {
          if (sessionsWithBanner < 2) {
            cLog(
              "BuildAndShowNTC() - banner showing for the first 2 sessions only"
            );
            var bannerViewsInFirstTwoSessions = Number(getCk("UDNS_NTCS"));

            if (bannerViewsInFirstTwoSessions === 0) {
              setLclCk("UDNS_NTCS", 1);
              sessionsWithBanner += 1;
              airgap
                .sync()
                .then(() =>
                  airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
                    ...(airgap.getConsent().metadata || {}),
                    UDNS_NTCV: sessionsWithBanner,
                  })
                )
                .then(() =>
                  cLog("BuildAndShowNTC() - first session with the banner")
                )
                .then(window.displayNTC());
            } else {
              /* Only show the banner to the first 3 pages in a session */
              if (bannerViewsInFirstTwoSessions < 3) {
                bannerViewsInFirstTwoSessions += 1;
                setLclCk("UDNS_NTCS", bannerViewsInFirstTwoSessions);
                cLog(
                  "BuildAndShowNTC() - user has seen the banner less than 3 times in the first 2 sessions"
                );
                window.displayNTC();
              }
            }
          } else {
            cLog(
              "BuildAndShowNTC() - this is the thrid session or greater on Verizon"
            );
            window.UDNS_NTCD = Date.now();
            airgap
              .sync()
              .then(() =>
                airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
                  ...(airgap.getConsent().metadata || {}),
                  UDNS_NTCD: window.UDNS_NTCD,
                  UDNS_NTCV: 0,
                })
              )
              .then(() =>
                cLog(
                  "BuildAndShowNTC() - setting banner dismissal date to now and number of session visits with banner to 0 on window and airgap metadata"
                )
              );
          }
        }
      }
      window.NTCpvc = function () {
        cLog("NTCpvc() - opening new tab with privacy policy explainer page");
        window.coreData = window.coreData || [];
        window.coreData.push({
          task: "emit",
          event: "linkClick",
          params: {
            name: "privacy banner policy link",
            detail: "PRIVACY_BANNER_DISPLAY",
          },
        });
        if (spanishPage && isLowerEnv) {
          window.open("https://esus-uat.verizon.com/about/privacy/", "_blank");
        } else if (spanishPage) {
          window.open("https://esus.verizon.com/about/privacy/", "_blank");
        } else {
          window.open("https://www.verizon.com/about/privacy", "_blank");
        }
      };

      window.resetNTCDisplay = function () {
        airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
          ...(airgap.getConsent().metadata || {}),
          UDNS_NTCD: Date.now() - 7.777e9,
          UDNS_NTCV: 0,
        });
        setLclCk("UDNS_NTCS", 0);
        return "privacy banner reset to display on next page load";
      };

      window.resetNTCVisits = function (visitCount = 0) {
        airgap.setConsentMetadata(window.airgapScriptLoadEvent, {
          ...(airgap.getConsent().metadata || {}),
          UDNS_NTCV: visitCount,
        });
        setLclCk("UDNS_NTCS", 0);
        return (
          "number of site visits with privacy banner reset to: " + visitCount
        );
      };
    }
    /* ------------ Implement Privacy Banner Notification End ------------ */

    //start DPCMP-3713
    window.useAirgapSandbox = (bool) => {
      if (bool === true) {
        setLclCk("useAirgapSandbox", "true");
        return "refresh page to use airgap sandbox instance";
      } else {
        setLclCk("useAirgapSandbox", "false");
        return "refresh page to use airgap VCG instance";
      }
    };

    window.showTheUpdate = function () {
      const airgapConsent = airgap.getConsent();
      const reportingOnly = airgap.loadOptions.reportOnly || "Off";
      const gpcSignal = navigator.globalPrivacyControl || "Off";
      const bundleId =
        getCk("useAirgapSandbox") === "true"
          ? airgapSandboxBundleId + " - SANDBOX"
          : BUNDLE_ID + " - VCG";
      try {
        window.alert(
          "Airgap Script Version: " +
            airgap.version +
            "\nCustom Script Version: ER25.03" +
            "\nReportingOnlyMode: " +
            reportingOnly +
            "\nSaleOfInfo: " +
            airgapConsent.purposes.SaleOfInfo +
            "\nGPC: " +
            gpcSignal +
            "\nPartition: " +
            airgap.loadOptions.partition +
            "\nSyncEndPt: " +
            airgap.loadOptions.syncEndpoint +
            "\nUniqId: " +
            airgapConsent.metadata?.UDNS_ID +
            "\nRequest_Policy: " +
            airgap.loadOptions.unknownRequestPolicy +
            "\nCookie_Policy: " +
            airgap.loadOptions.unknownCookiePolicy +
            "\nBundle: " +
            bundleId
        );
      } catch (e) {
        cLog("Not able to extract data from airgap: " + e.message);
      }
    };
    console.log("AIRGAP LOADED");
  })();
}
