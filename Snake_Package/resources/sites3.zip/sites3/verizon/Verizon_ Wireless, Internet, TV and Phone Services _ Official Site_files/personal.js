//******************************************* 
window.gnav20 = window.gnav20 || {};

if(/MY_VZW_APP/.test(navigator.userAgent)){
	// remove header and footer divs in app
	gnav20.navDivs = document.querySelectorAll("#vz-gh20, #vz-gf20");
	for(var i = 0; i < gnav20.navDivs.length; ++i) {
	  gnav20.navDivs[i].remove();
	}
	if(!/\/digital\/nsa\/secure\/ui\/vzup\//.test(location.href) && !/\/sales\/digital\//.test(location.href) && !/\/sales\/next\//.test(location.href)){// add title and back button in app
		var json4app = JSON.stringify(
			{
			  "actionType": "updateNavigation",
			  "navigationBar":{
			         "moleculeName":"navigationBar",
			         "title":document.title,
			         "alwaysShowBackButton": true 
			      }
			}
		)
	  if (window.webkit != undefined) {
	      if (window.webkit.messageHandlers.mfAppInterface != undefined) {
	          window.webkit.messageHandlers.mfAppInterface.postMessage(json4app)
	      }
	  }
	  if (window.mfAppInterface != undefined) {
	      window.mfAppInterface.postMessage(json4app)
	  }
	}
}

gnav20.getCookie = function (cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
};

gnav20.setCookie = function (name, value, days) {
    var secure = location.protocol === 'https:' ? ';secure' : '';
	var domArray = location.host.split(".");	
    var domain = /localhost/.test(location.host) ? "localhost" : domArray[domArray.length-2] + "." + domArray[domArray.length-1];	
	var cookie = name + "=" + value;
		
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        cookie += ";expires=" + date.toUTCString();
    }
    document.cookie = cookie + ";domain=" + domain + ";path=/" + secure;
};

gnav20.deleteCookie = function (name) {
    gnav20.setCookie(name, '', -1)
};


gnav20.getURLParams  = function (search) {
    var params = {};
    var query = search.substring(1);
    var vars = query.split('&');
	for (var i = 0; i < vars.length; i++) {
		var pair = vars[i].split('=');
		params[pair[0]] = decodeURIComponent(pair[1]);
	}
	return params;
};

gnav20.personalizeHidden = function () {
    var hideItem = [];
    if (window.gnavdl && window.gnavdl.options) {
        if (window.gnavdl.options["hide-item"]) {
            hideItem = window.gnavdl.options["hide-item"];
        }
    }
    if (hideItem) {
        hideItem.forEach(function (ele, index) {
            var nodes = document.querySelectorAll('[item-title=' + ele + ']');
            for (i = 0; i < nodes.length; i++) {
                nodes[i].style.display = 'none';
            }
            if(ele == 'promoRibbon' && document.querySelector('.gnav20 .gnav20-with-promo')) {
                document.querySelector('.gnav20 .gnav20-with-promo').classList.remove('gnav20-with-promo');
                if(document.querySelector(".gnav20-ribbontext")) {
                    document.querySelector(".gnav20-ribbontext").innerHTML = "";
                }
            }
        })
    }
};

gnav20.hideLink = function (element) {
    var returnVal = false;
    if (typeof gnav20.personalization != "undefined" && element.dataset.showFor) {
        var showForArr = element.dataset.showFor.split(',');
        for (i = 0; i < showForArr.length; i++) {
            if (showForArr[i]) {
                var showFor = showForArr[i].split(":");
                if (showFor.length == 2 && gnav20.personalization[showFor[0]] !== undefined) {
                    if (gnav20.personalization[showFor[0]].toLowerCase() == showFor[1].toLowerCase()) {
                        returnVal = false;
                        break;
                    }
                    else {
                        returnVal = true;
                    }
                } else {
                    returnVal = true;
                }
            }
        }
    } else if (element.dataset.showFor) {
        returnVal = true;
    }
    if (!returnVal && typeof gnav20.personalization != "undefined" && element.dataset.hideFor) {
        var hideForArr = element.dataset.hideFor.split(',');
        for (i = 0; i < hideForArr.length; i++) {
            if (hideForArr[i]) {
                var hideFor = hideForArr[i].split(":");
                if (hideFor.length == 2 && gnav20.personalization[hideFor[0]] !== undefined) {
                    if (gnav20.personalization[hideFor[0]].toLowerCase() == hideFor[1].toLowerCase()) {
                        returnVal = true;
                        break;
                    }
                }
            }
        }
    }
    return returnVal;
};

gnav20.disableLink = function (element) {
    //test
    var returnVal = false;
    if (typeof gnav20.personalization != "undefined" && element.dataset.disabledFor) {
        var disabledForArr = element.dataset.disabledFor.split(',');
        for (i = 0; i < disabledForArr.length; i++) {
            if (disabledForArr[i]) {
                var disabledFor = disabledForArr[i].split(":");
                if (disabledFor.length == 2 && gnav20.personalization[disabledFor[0]] !== undefined) {
                    if (gnav20.personalization[disabledFor[0]].toLowerCase() == disabledFor[1].toLowerCase()) {
                        returnVal = true;
                        break;
                    }
                }
            }
        }
    }
    return returnVal;
}

gnav20.initPersona = function () {
    var list = document.querySelectorAll("[data-show-for], [data-hide-for]");
    for (var i = 0; i < list.length; i++) {
		list[i].parentElement.classList.remove("gnav20-hide");
        if (gnav20.hideLink(list[i])) {
            list[i].parentElement.classList.add("gnav20-hide");
        }
    }

    var listDisabled = document.querySelectorAll("[data-disabled-for]");
    for (var i = 0; i < listDisabled.length; i++) {
		listDisabled[i].parentElement.classList.remove("gnav20-disabled");
        if (gnav20.disableLink(listDisabled[i])) {
            listDisabled[i].classList.add("gnav20-disabled")
        }
    }
	
	if(((gnav20.greetingName && gnav20.greetingName != "") || (gnav20.getCookie("greetingName") && /\w/.test(gnav20.getCookie("greetingName")))) && document.querySelector('.gnav20 .accountName')) {
		var accountName = document.querySelectorAll(".gnav20 .accountName");
		for(i = 0; i < accountName.length; i++){
			if(gnav20.greetingName)
				accountName[i].innerText = ", " + gnav20.greetingName;	
			else
				accountName[i].innerText = ", " + gnav20.getCookie("greetingName");	
		}
	}	
	if(typeof gnav20.personalization != "undefined" && gnav20.personalization && gnav20.personalization.zip) {
		var zipCode = document.querySelectorAll(".gnav20 .gnav20-location-icon .zip-text");
		for(i = 0; i < zipCode.length; i++){
			zipCode[i].innerHTML = gnav20.personalization.zip;
			if( zipCode[i].closest(".gnav20-location-icon") ) {
				zipCode[i].closest(".gnav20-location-icon").classList.add("active")
			}
		}							
	}
	if(typeof gnav20.personalization != "undefined" && gnav20.personalization && gnav20.personalization.activeAcc) {
		var activeAcc = document.querySelectorAll(".gnav20 .activeAcc");
		for(i = 0; i < activeAcc.length; i++){
			activeAcc[i].innerHTML = "#" + gnav20.personalization.activeAcc;								
		}
	}
};

//*******************************************

/********** START - Functionality for UNIFIED utilities DO NOT DELETE *******************************/

// Wireless cart and wishlist utilities

// Show cart count for cart icon and wishlist icon - WIP needs to be updatad
gnav20.showBubble = function () {
	var moreThan99 = '99+'; //VCGAF-249
    var wirelessAuth = gnav20.getCookie('loggedIn'),
            fwaCart = wirelessAuth ? gnav20.getCookie('fwaCartExists') : gnav20.getCookie('prospectFwaCartExists'),
    		acNextGen = !wirelessAuth && gnav20.getCookie('acNextGen'),
    		cartBubble = document.getElementsByClassName("showBubble"),
    		pnWishlist = gnav20.getCookie('pnWishlist'),
        wishListBubble = document.getElementsByClassName("gnav20-wish-list-bubble"),
        cartCountCookieName = gnav20.getCookie('isPrepayCartExist')
            ? "prepayCartCount"
            :  wirelessAuth // && gnav20.getCookie('gnCartCount') - DOPMO-153970
                ? "gnCartCount"
                : "prospectCartCount",
        cartCount = parseInt(gnav20.getCookie(cartCountCookieName)),
        wishListCount = wirelessAuth ? parseInt(gnav20.getCookie('wishListCount')) : parseInt(gnav20.getCookie('prospectWishListCount')),
        cartCountDisplay = (cartCount > 0 || fwaCart || acNextGen)? 'block' : 'none', //VCGAF-249
        wishListDisplay = ((wirelessAuth && wishListCount) || (!wirelessAuth && pnWishlist)) ? 'block' : 'none';
        
    if(cartCountCookieName === 'prospectCartCount' && !gnav20.getCookie('prospectCartActive') && !gnav20.getCookie('AccessoryOnlyCartAvailable') && !fwaCart && !acNextGen){
    	cartCountDisplay = 'none'
    	cartCount = 0
    }
		
		for (i = 0; i < cartBubble.length; i++) {
			cartBubble[i].style.display = cartCountDisplay;
			cartBubble[i].innerText = isNaN(cartCount) ? '' : cartCount;
		}
		
		/************************ New design unified cart ************************/
		//if(!cartCount && fwaCart){ for now, no indicator next to mobile for fwa, but destination will still be fwa
		//	cartCount = 1;
		//}
		var newCartBubble = document.querySelectorAll('.gnav20 .gnav20-gnav-new-design .gnav20-unifiedcart-bubble');
		for (i = 0; i < newCartBubble.length; i++) {
			newCartBubble[i].style.display = cartCountDisplay;
			//newCartBubble[i].style.right = (cartCount > 0 && cartCount <= 9) ? '6px' : (cartCount > 9 && cartCount <= 19) ? '4px' : (cartCount > 9 && cartCount <= 99) ? '1px' : (cartCount > 99) ? '-5px' : '';
			newCartBubble[i].innerText = (cartCount > 99) ? moreThan99 : cartCount;
			pluralTag = cartCount == 1 ? '' : 's';
			var ariaLabelForCart = isNaN(cartCount) ? 'Shopping Cart Menu' : 'Shopping Cart Menu ' + cartCount + ' item' + pluralTag + ' in the cart';
			newCartBubble[i].parentElement.setAttribute('aria-label',ariaLabelForCart);
		}
		
		/***************************VCGAF-249*************************************/
		var mobileCartCountElements = document.querySelectorAll('.gnav20 .gnav20-unified-cart .gnav20-content-list .gnav20-content-list-arrow.gnav20-mobile-cart-count')

		for (var i = 0; i < mobileCartCountElements.length; i++) {
            if(cartCount && cartCount > 0){
				if(mobileCartCountElements[i].innerText.indexOf('(') > 0){
					mobileCartCountElements[i].innerText = mobileCartCountElements[i].innerText.substr(0, mobileCartCountElements[i].innerText.indexOf("(")) + '(' + cartCount + ')';
				}
				else {
					mobileCartCountElements[i].innerText = mobileCartCountElements[i].innerText + ' (' + cartCount + ')';
				}

				pluralTag = cartCount == 1 ? '' : 's';
				var ariaLabelFormobileCart = isNaN(cartCount) ? 'Mobile solutions' : 'Mobile solutions ' + cartCount + ' item' + pluralTag + ' in the cart';
				mobileCartCountElements[i].setAttribute('aria-label',ariaLabelFormobileCart);
			}
			else{
				mobileCartCountElements[i].innerText = 'Mobile solutions';
			}
		}
		/***************************VCGAF-249*************************************/
		/***************************VCGAF-249 FOR HOME CART *************************************/			
		if(fwaCart){
			var homeCartCountElements = document.querySelectorAll('.gnav20 .gnav20-unified-cart .gnav20-content-list .gnav20-content-list-arrow.gnav20-home-cart-count'),
					domain = /billpay.verizonwireless/.test(location.host)
	    		? 'https://vzwqa'+ location.host.substr(2,1) +'.verizonwireless.com'
	    		: /verizonwireless/.test(location.host) 
	    		? '' 
	    		: /wwwnssit/.test(location.host) 
	    		? ''
	    		: 'https://www.verizon.com'

			for (var i = 0; i < homeCartCountElements.length; i++) {
				homeCartCountElements[i].href = domain + '/sales/home/expresscart.html?expresscart=true&resumecart=true'; // newer fwa page DCMP-9861
				if(fwaCart && homeCartCountElements[i].innerText.indexOf('(') < 0){
					homeCartCountElements[i].innerText = homeCartCountElements[i].innerText + ' (1)';
					homeCartCountElements[i].setAttribute('aria-label','Home solutions, with one item in the cart');					
				}
			}
			window.coreData = window.coreData || [];
						window.coreData.push({
						task : "emit",
						event : "notify",
						params : {
							name    : "cart item details",
							message : "Mobile solutions | Home solutions(1)"
						}
				});
		}
		/*************************** VCGAF-249 FOR HOME CART **************************************/
		
		/******************** Wishlist Link inside Account Tab ***********************/
		var wishListIndicator = document.querySelectorAll('.gnav20 .gnav20-featured-card .gnav20-submenu-column .gnav20-sub-nav-list.gnav20-wishlist-menu-indicator > a')

		for (var i = 0; i < wishListIndicator.length; i++) {
				if(wishListCount && wishListCount > 0){
				wishListIndicator[i].innerHTML = 'Wishlist' + ' (' + wishListCount + ')';
				plural = wishListCount == 1 ? '' : 's';
				var ariaLabelForWishlistLink = isNaN(wishListCount) ? 'Wishlist' : 'Wishlist with ' + wishListCount + ' item' + plural;
				wishListIndicator[i].setAttribute('aria-label',ariaLabelForWishlistLink);
			}
		}

		/******************** Wishlist Icon component ***********************/
		for (i = 0; i < wishListBubble.length; i++) {
			wishListBubble[i].style.display = wishListDisplay;
			wishListBubble[i].innerText = isNaN(wishListCount) ? '' : wishListCount;
			plural = wishListCount == 1 ? '' : 's';
			var ariaLabelForWishlist = isNaN(wishListCount) ? 'Wishlist' : 'Wishlist with ' + wishListCount + ' item' + plural;
			wishListBubble[i].parentElement.setAttribute('aria-label',ariaLabelForWishlist);
		}
};

// cart utility for lower envs, look into using unified cart JS page in lowers
gnav20.cartUtility = function (event) {
    event.preventDefault();

    var domain = /billpay.verizonwireless/.test(location.host)
    		? 'https://vzwqa'+ location.host.substr(2,1) +'.verizonwireless.com'
    		: /verizonwireless/.test(location.host) 
    		? '' 
    		: /wwwnssit/.test(location.host) 
    		? ''
    		: 'https://www.verizon.com',
    		prospectCartCount = gnav20.getCookie('prospectCartCount'),
    		

    prepayCart = gnav20.getCookie('isPrepayCartExist') || (gnav20.getCookie('role') == 'prepay'),
		accessoryOnlyCart = gnav20.getCookie('AccessoryOnlyCartAvailable'),
		nsaAccessoryOnlyCart = gnav20.getCookie('NSAAccessoryOnlyCartAvailable'),
		loggedInCart = gnav20.getCookie('loggedIn'),
		fwaCart = loggedInCart ? (gnav20.getCookie('fwaCartExists') == 'Y' && !parseInt(gnav20.getCookie('prospectCartCount'))  && !parseInt(gnav20.getCookie('gnCartCount')) && !accessoryOnlyCart && !nsaAccessoryOnlyCart) :
		(gnav20.getCookie('prospectFwaCartExists') == 'Y' && !parseInt(gnav20.getCookie('prospectCartCount'))  && !parseInt(gnav20.getCookie('gnCartCount')) && !accessoryOnlyCart && !nsaAccessoryOnlyCart),
  		nextCart = gnav20.getCookie('BAUNEXT_FLOW'),
		nextGenCart = gnav20.getCookie('NEXTGEN'),
		acNextGen = gnav20.getCookie('acNextGen'),
		nextGenDig = gnav20.getCookie('NGD'),
		
		href = prepayCart && loggedInCart ? domain + '/od/prepaid/cart/#/' // bau logged-in prepaid cart 
		: prepayCart
		? domain + '/sales/prepaid/expresscart.html' // new prepaid cart  
		: fwaCart
		? domain + '/sales/home/expresscart.html?expresscart=true&resumecart=true' // newer FWA URL DCMP-9861
		: (loggedInCart && !nextGenCart) || nextCart
        ? domain + '/sales/next/expresscheckout.html?pageName=cart' // accessory BAUNEXT_FLOW
		: accessoryOnlyCart
		? domain + '/od/cust/cart/getCartDetails' // accessory only cart
		: nsaAccessoryOnlyCart
		? domain + '/sales/digital/cart.html' // nsa accessory only cart
		: nextGenDig
		? domain + '/nextgendigital/sales/configurator/cart?isAbandonCart=true' // nextgen digital cart
		: domain + '/sales/nextgen/expresscart.html?pageName=cart' // nextgen cart default

		if(acNextGen && /nextgen\/expresscart/.test(href)) {
		    if(href.includes("?"))
		        href += '&isAbandonCart=true';
		    else
		        href += '?isAbandonCart=true';
		}
    
    location.href = href
};

// wireless gnav object to provide cart and wishlist update functionality to parent pages
window.vzwgnav = window.vzwgnav || {}
window.vzwgnav.setIconCounts = gnav20.showBubble
window.gnav20.setIconCounts = gnav20.showBubble

gnav20.initIconCounts = function () {
    if (!gnav20.getCookie('loggedIn')) {
        gnav20.deleteCookie('wishListCount')
    }
    gnav20.showBubble()
};

/********** END - Functionality for UNIFIED utilities DO NOT DELETE *******************************/

gnav20.smartlingTranslation = function () {
    var currentSubdomain = location.host.split('.')[0], newSubdomain;

    switch(currentSubdomain){
    	case 'www':
    		newSubdomain = 'esus';
    		break;
    	case 'www98':
    		newSubdomain = 'esus-uat';
    		break;
    	case 'esus':
    		newSubdomain = 'www';
    		break;
    	case 'esus-uat':
    		newSubdomain = 'www98';
    		break;
        case 'espanol':
    		newSubdomain = 'www';
    		break;
        case 'secure':
            newSubdomain = 'espanol.secure';
            break;
        case 'plusplay':
            newSubdomain = 'espanol.plusplay';
            break;
        case 'myvpostpay':
            newSubdomain = 'espanol.myvpostpay';
            break;
        case 'myvprepay':
            newSubdomain = 'espanol.myvprepay';
            break;
    }
    if(location.host.indexOf("www.yourdigitalrebatecenter") > -1){
        newSubdomain = "espanol";
        currentSubdomain = "www";
    } else if(location.host.indexOf("espanol.secure") > -1){
        newSubdomain = "secure";
        currentSubdomain = "espanol.secure";
    } else if(location.host.indexOf("espanol.plusplay") > -1){
        newSubdomain = "plusplay";
        currentSubdomain = "espanol.plusplay";
    } else if(location.host.indexOf("espanol.myvpostpay") > -1){
        newSubdomain = "myvpostpay";
        currentSubdomain = "espanol.myvpostpay";
    } else if(location.host.indexOf("espanol.myvprepay") > -1){
        newSubdomain = "myvprepay";
        currentSubdomain = "espanol.myvprepay";
    } else if(location.host.indexOf("es-vzwqa") > -1) {
        newSubdomain = "vzwqa";
        currentSubdomain = "es-vzwqa";
    } else if(location.host.indexOf("vzwqa") > -1) {
        newSubdomain = "es-vzwqa";
        currentSubdomain = "vzwqa";
    } else if(location.host.indexOf("es.securesit") > -1) {
        newSubdomain = "securesit";
        currentSubdomain = "es.securesit";
    } else if(location.host.indexOf("securesit") > -1) {
        newSubdomain = "es.securesit";
        currentSubdomain = "securesit";
    } else if(location.host.indexOf("es-qa") > -1) {
        newSubdomain = "qa";
        currentSubdomain = "es-qa";
    } else if(location.host.indexOf("qa") > -1 && location.host.indexOf("billpay.") > -1) {
        newSubdomain = "es-qa";
        currentSubdomain = "qa";
    } else if(location.host.indexOf("ecommstage") > -1) {
        newSubdomain = "espanolstage";
        currentSubdomain = "ecommstage";
    }else if(location.host.indexOf("espanolstage") > -1) {
        newSubdomain = "ecommstage";
        currentSubdomain = "espanolstage";
    }
    if ( newSubdomain !== undefined ) {
        location.href = location.href.replace(currentSubdomain, newSubdomain);
    }
};

// Version: '1.0.23' motionpoint start (needed for Spanish/English toggle)
var MP = {
    //<!-- mp_trans_disable_start -->
    Version: "1.0.23",
    Domains: /verizonwireless/.test(location.host) ? { "es": "espanol.verizon.com" } : { "es": "espanol.verizon.com" },
    SrcLang: "en",
    //<!-- mp_trans_disable_end -->
    UrlLang: "mp_js_current_lang",
    SrcUrl: decodeURIComponent("mp_js_orgin_url"),
    //<!-- mp_trans_disable_start -->
    init: function () {
        if (MP.UrlLang.indexOf("p_js_") == 1) {
            MP.SrcUrl = location.href;
            MP.UrlLang = MP.SrcLang;
        }
    },
    getCookie: function (name) {
        var start = document.cookie.indexOf(name + "=");
        if (start < 0) return null;
        start = start + name.length + 1;
        var end = document.cookie.indexOf(";", start);
        if (end < 0) end = document.cookie.length;
        while (document.cookie.charAt(start) == " ") { start++; }
        return decodeURIComponent(document.cookie.substring(start, end));
    },
    setCookie: function (name, value, path, domain) {
        var cookie = name + "=" + encodeURIComponent(value);
        if (path) cookie += "; path=" + path;
        if (domain) cookie += "; domain=" + domain;
        var now = new Date();
        now.setTime(now.getTime() + 1000 * 60 * 60 * 24 * 365);
        cookie += "; expires=" + now.toUTCString();
        document.cookie = cookie;
    },
    switchLanguage: function (lang) {
        if (lang != MP.SrcLang) {
            var script = document.createElement("SCRIPT");
            script.src = location.protocol + "//" + MP.Domains[lang] + "/" + MP.SrcLang + lang + "/?1023749632;" + encodeURIComponent(MP.SrcUrl);
            document.body.appendChild(script);
        } else if (lang == MP.SrcLang && MP.UrlLang != MP.SrcLang) {
            var script = document.createElement("SCRIPT");
            script.src = location.protocol + "//" + MP.Domains[MP.UrlLang] + "/" + MP.SrcLang + MP.UrlLang + "/?1023749634;" + encodeURIComponent(location.href);
            document.body.appendChild(script);
        }
        return false;
    },
    switchToLang: function (url) {
        location.href = url;
    }
}
//<!-- mp_trans_disable_end -->

// SKINNY NAV FUNCTIONALITY - START - skinny nav is cancelled for now 6/30/2021 so commenting below
/*
gnav20.initSkinnyNav = function(){
	gnav20.headerElement = document.querySelector('.gnav20')
	gnav20.lastScrollTop = 0;
	gnav20.goingSkinny = false;
	gnav20.scrollDirection = 'up';
	window.addEventListener("scroll", function(){    
		if(!gnav20.goingSkinny){
		 	var currentScrollTop = window.pageYOffset || document.documentElement.scrollTop; 
		 	if (currentScrollTop > gnav20.lastScrollTop && gnav20.scrollDirection != 'down'){      
		    gnav20.scrollDirection = 'down'
		    gnav20.headerElement.classList.add('gnav20-skinny')
		 } else if(currentScrollTop < gnav20.lastScrollTop && gnav20.scrollDirection != 'up') {
		    gnav20.scrollDirection = 'up'
		    gnav20.headerElement.classList.remove('gnav20-skinny')
		 }
		 gnav20.lastScrollTop = currentScrollTop <= 0 ? 0 : currentScrollTop;
		 console.log('skinny scroll')
		}
	}, false);

	var hiddenLinks = document.querySelectorAll('.gnav20 .gnav20-desktop .gnav20-row-one a, .gnav20 .gnav20-promo-ribbon a, .gnav20 .gnav20-promo-ribbon button')
	for (i = 0; i < hiddenLinks.length; i++) {
		hiddenLinks[i].addEventListener("focus", function(){
			if(gnav20.scrollDirection == 'down'){
				gnav20.scrollDirection = 'up'
		  	gnav20.headerElement.classList.remove('gnav20-skinny')
			}
		});
	}clearFocusTrap
}
*/
// SKINNY NAV FUNCTIONALITY - END


//A11y Fix. Start of code to restrict the visual TAB  focus within the overlay/flyout
gnav20.setFocusTrap = function(container){
		
	var focusableList = container.querySelectorAll('a[href]:not([disabled]), button:not([disabled]):not(.gnav20-back-to-menu), textarea:not([disabled]), input[type="search"]:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])');
			indexInc = 1;
	gnav20.focusTrapContainer = container;
	gnav20.firstFocusableEl = focusableList[0];
	
	/*
	for (i = 0; i < focusableList.length; i++){
		console.log(window.getComputedStyle(focusableList[i], null).getPropertyValue("display"),focusableList[i])
	}
	*/	
	gnav20.lastFocusableEl = focusableList[focusableList.length - indexInc];
	while(gnav20.lastFocusableEl && !gnav20.lastFocusableEl.offsetParent){// for cases where we have hidden elements
		indexInc ++
		gnav20.lastFocusableEl = focusableList[focusableList.length - indexInc];
	}
	gnav20.focusTrapContainer.removeEventListener('keydown',gnav20.focusTrap)
	gnav20.focusTrapContainer.addEventListener('keydown',gnav20.focusTrap)
}
gnav20.clearFocusTrap = function(){
	
	if(gnav20.focusTrapContainer){
		gnav20.focusTrapContainer.removeEventListener('keydown',gnav20.focusTrap)
		gnav20.activeCloseButton = null
	}
}
gnav20.focusTrap = function(event){
		
	if(event.keyCode != 9){
		return
	}
	if (event.shiftKey) /* shift + tab */ {
      if (document.activeElement == gnav20.firstFocusableEl) {
          gnav20.lastFocusableEl.focus();
          event.preventDefault()
      }
  } else /* tab */ {
      if (document.activeElement == gnav20.lastFocusableEl) {
          gnav20.firstFocusableEl.focus();
          event.preventDefault()
      }
  }
}

/* commented 11/5/21
gnav20.toggleZindex = function(bool){
	gnav20.contentWrapper = document.querySelector('.gnav20 .gnav20-sticky-content')
	if(gnav20.contentWrapper){
		var cmd = bool ? 'add' : 'remove'
		gnav20.contentWrapper.classList[cmd]('gnav20-open-element')
	}
}
*/

gnav20.clickOutsideClose = function(event){
	//console.log('clickOutsideClose')
	if(!event.target.closest(gnav20.closeElementQuery) && gnav20.activeCloseButton){
		gnav20.activeCloseButton.click()
	}
}

gnav20.initVisualCue = function() {
	testIndicatorIndex = 0
	testIndicatorInterval = setInterval(function(){
		testIndicatorIndex ++;
		if(document.querySelector('#vz-gf20 .gnav20-footer-level-two .copyright-section') && !document.getElementById('visual-cue')){
			var vc = document.createElement('DIV')
			vc.id = 'visual-cue';
			vc.innerHTML = '<div></div><div></div><div></div>'
			document.querySelector('#vz-gf20 .gnav20-footer-level-two .copyright-section').appendChild(vc); 
		}
		if(window.runningExperiment && document.getElementById('visual-cue')){
			var indicator = document.getElementById('visual-cue'),
					divs = indicator.children
			window.runningExperiment.forEach(function(item,index){
				if(/optimization/.test(item.toLowerCase())){
					divs[0].setAttribute('class', 'visual-cue-show')
					indicator.style.display = 'block';
				}else if(/merchandising/.test(item.toLowerCase())){
					divs[1].setAttribute('class', 'visual-cue-show')
					indicator.style.display = 'block';
				}else if(/personalization/.test(item.toLowerCase())){
					divs[2].setAttribute('class', 'visual-cue-show')
					indicator.style.display = 'block';
				}
			})			
			clearInterval(testIndicatorInterval)
		}
		if(testIndicatorIndex>29){
			clearInterval(testIndicatorInterval)
		}
	},1000)
}

 
gnav20.check4BusinessCookie = function(){
	var bizCookie = gnav20.getCookie('VZ_ATLAS_SITE_PERS')
	if(bizCookie && /=business/.test(bizCookie) && !gnav20.getCookie('hideBizBubble')){
		if(!gnav20.bizSpan){
			gnav20.bizSpan = document.createElement('span');
			gnav20.bizSpan.className = 'biz-bubble';
			gnav20.bizSpan.style.marginLeft = 0;
			gnav20.bizSpan.innerHTML = 'Looking for Business?<button id="close-biz-look-bubble">&times;</button>';		
			
			var bizBut = gnav20.bizSpan.querySelector('button')
			if(gnav20.bizSpan && bizBut){
				bizBut.setAttribute('aria-label', 'close the looking for business alert')
				bizBut.addEventListener('click', function(){
					document.querySelector('.gnav20-desktop .gnav20-utility .gnav20-store a').focus()
					gnav20.bizSpan.style.display = 'none';
					gnav20.setCookie('hideBizBubble', 'true')
					setTimeout("document.querySelector('.gnav20-desktop .gnav20-utility .gnav20-store a').focus()",100)
				})
			}
		}
		
		var bizContainer = document.querySelector('.gnav20-eyebrow-link-list-item.gnav20-two')
		if(bizContainer && !bizContainer.querySelector('.biz-bubble')){
			bizContainer.appendChild(gnav20.bizSpan);
		}
				
		/* commenting code until animation is improved
		bizAniInc = 1
		bizAniMax = 50
		bizAniInt = 60
		bizAniRange = 5
		bizAniInterval = setInterval(function(){
			var ml = parseInt(gnav20.bizSpan.style.marginLeft)
			if(bizAniMax < 0 && !ml){
				clearInterval(bizAniInterval)
			}else{
				if(ml > bizAniRange){
					bizAniInc = -1;
				}
				if(ml < bizAniRange* -1){
					bizAniInc = 1;
				}
				gnav20.bizSpan.style.marginLeft = ml + bizAniInc + 'px'
				bizAniMax --
			}
		},bizAniInt)
		*/
	}
}

/* DCMP-8423 Start */
window.addEventListener('load',function(){
    if(window.location.href.indexOf('.verizon.com/signin?action=otp') > -1){
        if(document.querySelector('#otpLink')){
            document.querySelector('#otpLink').click();
        }
    }
});
/* DCMP-8423 End */


    		/* OLD CART LOGIC
        prepayCart = gnav20.getCookie('isPrepayCartExist') || (gnav20.getCookie('role') == 'prepay'),
        accessoryCart = gnav20.getCookie('AccessoryOnlyCartAvailable'),
        prospectCart = gnav20.getCookie('prospectCartAvailable'),
        nseCart = gnav20.getCookie('nseCartItemsAvailable'),
        hubCart = gnav20.getCookie('hubProspectCart'),
        loggedInCart = gnav20.getCookie('loggedIn'),
        href = prepayCart
            ? domain + '/od/prepaid/cart/'
            : loggedInCart
              ? domain + '/sales/next/expresscheckout.html?pageName=cart' //'/sales/digital/expressCheckout.html?pageName=cart'
              : accessoryCart && !prospectCart && !nseCart
                ? domain + '/od/cust/cart/getCartDetails' // accessory cart 
                : hubCart == 'true'
                	? domain + '/sales/digital/prospectCheckout.html' // hubcart
	                : nseCart
	                	? '/sales/nse/cart.html' // nse cart
	                	: prospectCart
	                		? domain + '/onedp/cart' // bau prospect cart
	                	  : domain + '/sales/nse/cart.html' // nse cart default
				*/
				
    


gnav20.initPromo = function () {   

/* start - code commented until they want a carousel in the promo ribbon
	var promoIconEleActive;    
	var itemClassName = "gnav20-promotext";
	var promoWrapper = document.querySelector(".gnav20-promo-ribbon-wrapper");
	
	// placing 'var' in front of the below vars which were set globally and caused numerous problems
	var items = document.getElementsByClassName(itemClassName),
			totalItems = items.length,
			slide = 0,
			moving = true,
			autoplay = true,
			autoplayduration = 3000;
	
	if(promoWrapper && promoWrapper.dataset && promoWrapper.dataset.autoCycle && promoWrapper.dataset.autoCycleDuration) {
		if(promoWrapper.dataset.autoCycle == "on") {
			autoplayduration = promoWrapper.dataset.autoCycleDuration * 1000;
		}
	}
			
	
	function setInitialClasses() {
		if(totalItems > 1) {
			items[totalItems - 1].classList.add("prev");
			items[0].classList.add("active");
			items[1].classList.add("next");
		} else if (totalItems == 1) {
			items[0].classList.add("active");
		}
	}
		
	function setEventListeners() {
		if(totalItems > 1) {
			var next = document.getElementsByClassName('gnav20-carousel-button-next')[0],
				prev = document.getElementsByClassName('gnav20-carousel-button-prev')[0];
			if(next) {
				next.addEventListener('click', moveNext);
			}
			if(prev) {
				prev.addEventListener('click', movePrev);
			}
		}
	}
			
	function moveNext(triggeredByAutoplay) {
		if(triggeredByAutoplay != true) {			
			autoplay = false;
			setTimeout(
				function(){
					if(promoWrapper && promoWrapper.dataset && promoWrapper.dataset.autoCycle && promoWrapper.dataset.autoCycleDuration) {
						if(promoWrapper.dataset.autoCycle == "on") {
							autoplay = true
						}
					}
				}, autoplayduration);

		}
		if (!moving) {
			if (slide === (totalItems - 1)) {
				slide = 0;
			} else {
				slide++;
			}
			moveCarouselTo(slide);
		}
	}

	
	function movePrev() {
		if (!moving) {
			if (slide === 0) {
			  slide = (totalItems - 1);
			} else {
			  slide--;
			}
			moveCarouselTo(slide);
		}
	}
			
	function disableInteraction() {
		moving = true;
		setTimeout(function(){
			moving = false
		}, 1000);
	}
			
	function moveCarouselTo(slide) {
		if(!moving) {
			disableInteraction();
			var newPrevious = slide - 1,
				newNext = slide + 1,
				oldPrevious = slide - 2,
				oldNext = slide + 2;
			if (newPrevious <= 0) {
				oldPrevious = (totalItems - 1);
			} 
			if (newNext >= (totalItems - 1)){
				oldNext = 0;
			}
			if (slide === 0) {
				newPrevious = (totalItems - 1);
				oldPrevious = (totalItems - 2);
				oldNext = (slide + 1);
			} else if (slide === (totalItems -1)) {
				newPrevious = (slide - 1);
				newNext = 0;
				oldNext = 1;
			}
			items[oldPrevious].className = itemClassName;
			items[oldNext].className = itemClassName;
			if(newNext == newPrevious) {
				if(newNext == 0) 
					items[newPrevious].className = itemClassName + " prev";
				else
					items[newNext].className = itemClassName + " next";	
			} else {
				items[newPrevious].className = itemClassName + " prev";
				items[newNext].className = itemClassName + " next";			
			}
			items[slide].className = itemClassName + " active";				
		}
	}
	
	function autoPlay() {
		if(autoplay) {
			moveNext(autoplay);
		}
	}
			
	function initCarousel() {
		setInitialClasses();
		setEventListeners();
		moving = false;	
		
		if(totalItems > 1 && promoWrapper && promoWrapper.dataset && promoWrapper.dataset.autoCycle && promoWrapper.dataset.autoCycleDuration) {
			if(promoWrapper.dataset.autoCycle == "on") {
				window.setInterval(autoPlay, promoWrapper.dataset.autoCycleDuration* 1000);
			}
		}
		

	}
	*/ // end - code commented until they want a carousel in the promo ribbon
	
	function openPromo(event) {
        if (event.target.closest(".gnav20-promo-ribbon") && event.target.closest(".gnav20-promo-ribbon").querySelector('.gnav20-modal-content-placeholder') 
			&& event.target.closest(".gnav20-promo-ribbon-wrapper") && event.target.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-modal')) {
				
			event.target.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-modal-content-wrapper').innerHTML = event.target.closest(".gnav20-promo-ribbon").querySelector('.gnav20-modal-content-placeholder').innerHTML;
			
            event.target.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-modal').style.display = "block";
            event.target.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-promo-close-icon').focus();
            toggleAriaHiddenGnav20("modal", !0);       
            gnav20.setFocusTrap(document.querySelector(".gnav20-modal-content"))     
			promoIconEleActive = event.target;
			autoplay = false;
			gnav20.activeCloseButton = event.target.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-promo-close-icon');
        }
    };

	var promoIconEleActive = null; // rcw added here for 2406 ER
    function closePromo(event) {
        var closeModal = event.target.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-modal')
        if (closeModal) {
            closeModal.style.display = "none";

        }
        if (promoIconEleActive) {
            promoIconEleActive.focus();
        }
        toggleAriaHiddenGnav20("modal", !1);
        gnav20.clearFocusTrap()
        
    /* code commented until they want a carousel in the promo ribbon    
		setTimeout(
			function(){
				if(promoWrapper && promoWrapper.dataset && promoWrapper.dataset.autoCycle && promoWrapper.dataset.autoCycleDuration) {
					if(promoWrapper.dataset.autoCycle == "on") {
						autoplay = true
					}
				}
			}, autoplayduration);
		*/
		
    };
	
	// code commented until they want a carousel in the promo ribbon		
	//initCarousel(); 

	gnav20.modal = document.getElementById('gnav20-modal')
	if(gnav20.modal){
		gnav20.modal.addEventListener('click', function(event){
			if(!event.target.closest('.gnav20-modal-content')){
				gnav20.modal.style.display = "none";
			}
		})
	}
	
	
	var promoIconEle = document.querySelectorAll('.gnav20-promo-text .gnav20-promo-icon');	
	for (var i = 0; i < promoIconEle.length; i++) {
		promoIconEle[i].removeEventListener('click', openPromo);
		promoIconEle[i].addEventListener('click', openPromo);
    }
	
	var promoCloseEle = document.querySelectorAll('.gnav20-promo-ribbon-wrapper .gnav20-modal .gnav20-promo-close-icon');
	
    for (var i = 0; i < promoCloseEle.length; i++) {
		promoCloseEle[i].removeEventListener('click', closePromo);
		promoCloseEle[i].addEventListener('click', closePromo);
		
    }

    //Change Start DCMP-10010
    var promoTimerEle = document.querySelector('.gnav20-promo-ribbon-wrapper .gnav20-promo-timer');
    if(promoTimerEle) {
        if(typeof(gnavCountdownInterval) != 'undefined'){
            clearInterval(gnavCountdownInterval);
        }
        gnavCountdownInterval = setInterval(function() {
            // Set the date we're counting down to
            var gnavCountdownExpiry = new Date(promoTimerEle.getAttribute('timestamp')).getTime();
            // Get today's date and time
            var gnavNow = Date.parse(new Date().toLocaleString("en-US", {timeZone: 'America/New_York'}));;

            // Find the differance between now and the count down date
            var gnavTimeLeft = gnavCountdownExpiry - gnavNow;

            // If the count down is finished, write some text
            if (gnavTimeLeft < 0) {
                clearInterval(gnavCountdownInterval);
                promoTimerEle.innerText = 'Ends in 00d:00h:00m';
                return;
            }

            var gnavCountdownDays = Math.floor(gnavTimeLeft / (1000 * 60 * 60 * 24));
            var gnavCountdownHours = Math.floor((gnavTimeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var gnavCountdownMinutes = Math.floor((gnavTimeLeft % (1000 * 60 * 60)) / (1000 * 60));

            var strTemp = 'Ends in ' + (gnavCountdownDays < 10 ? '0' : '') + gnavCountdownDays + 'd:' + (gnavCountdownHours < 10 ? '0' : '') + gnavCountdownHours + 'h:' + (gnavCountdownMinutes < 10 ? '0' : '') + gnavCountdownMinutes + 'm';
            promoTimerEle.innerText = strTemp;

        }, 1000);
    }
    //Change End DCMP-10010

    var promoElement = document.querySelector('.gnav20-promo-ribbon-wrapper .gnav20-promo-text');
    if(promoElement && promoElement.getAttribute('auto-load') == 'yes') {
        if (promoElement.closest(".gnav20-promo-ribbon") && promoElement.closest(".gnav20-promo-ribbon").querySelector('.gnav20-modal-content-placeholder')
			&& promoElement.closest(".gnav20-promo-ribbon-wrapper") && promoElement.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-modal')) {

			promoElement.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-modal-content-wrapper').innerHTML = promoElement.closest(".gnav20-promo-ribbon").querySelector('.gnav20-modal-content-placeholder').innerHTML;

            promoElement.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-modal').style.display = "block";
            promoElement.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-promo-close-icon').focus();
            toggleAriaHiddenGnav20("modal", !0);
            gnav20.setFocusTrap(document.querySelector(".gnav20-modal-content"));
            promoIconEleActive = promoElement.querySelector(".gnav20-promo-icon a");
			autoplay = false;
			gnav20.activeCloseButton = promoElement.closest(".gnav20-promo-ribbon-wrapper").querySelector('.gnav20-promo-close-icon');
        }
    }
};
gnav20.initSearch = function () {
    
    var searchIcon = document.querySelectorAll('.gnav20-search-icon')
    for (i = 0; i < searchIcon.length; i++) {
        searchIcon[i].addEventListener("click", openSearchBar);
    }

	var searchIconNav = document.querySelectorAll('.gnav20-desktop .gnav20-primary-menu.gnav20-featured-card .gnav20-nav-search-icon')
    for (i = 0; i < searchIconNav.length; i++) {
        searchIconNav[i].addEventListener("click", openSearchBarFromNav);
        if(document.querySelector('#gnav20-search-icon')) {
            searchIconNav[i].setAttribute('data-placeholder-text', document.querySelector('#gnav20-search-icon').getAttribute('data-placeholder-text'))
        }
    }

    function openSearchBarFromNav() {
			if(document.querySelector('.gnav20-desktop .gnav20-search-icon')) {
				document.querySelector('.gnav20-desktop .gnav20-search-icon').click();
			}
		}
    
    function openSearchBar(event) {
	    	if(window.oneSearchTrigger){ // new search team search api has been initialized
	    		setTimeout('window.oneSearchTrigger.click()',10)
	    		return
	    	}else if(gnav20.bu == 'smb' && gnavdl.yextSearchURL){ // new Yext search experience for VBG
				initBizSearch(event)
				return
			}

        if(gnav20.bu == 'vec' && window.vec_gnav_globalSearch){ // call VEC search method
      		window.vec_gnav_globalSearch()
        	return
        } else  if(gnav20.appid == 'k12'){ // call k12 search method
      		openK12Search()
        	return
        } else { // call new search team api
        	initNewSearchAPI(event)
        	return
        }
   	
        window.removeEventListener('click', checkCloseSearch)
        window.addEventListener('click', checkCloseSearch)
        
    }
    
    function initNewSearchAPI(event){
    	window.acConfig = {
			targetEl : "oneSearchContainerGnav", 
			source: "GNAV", 
			src: gnav20.bu
		}
		var dom = 'https://scache-ws.vzw.com';
		if(document.getElementById("gnav20-search-context")) {
			dom = /true/.test(document.getElementById("gnav20-search-context").value) ? 'https://scache-ws.vzw.com' : gnav20.getScriptOrigin();
			if(window.location.origin.indexOf("ecommstage.verizon.com") > 0) {
				dom = 'https://scache-ws.vzw.com/stg'
			} else if (document.getElementById("gnav20-search-context").value == 'true' && gnav20.getCookie('redirect_to').includes("canary")) {
				dom = 'https://scache-ws.vzw.com/ec'
			}
		}
		var body = document.getElementsByTagName('body')[0]
		var addDiv = document.createElement('div');
		addDiv.id = 'oneSearchContainerGnav';
		addDiv.style.zIndex = 4600;
		addDiv.style.position = 'absolute';
		addDiv.style.width = '100%';
		//addDiv.innerHTML = '<div style="height:100vh;background:black;"></div>';		
		
		body.insertBefore(addDiv, body.firstChild);
		window.oneSearchDiv = addDiv;

		//if(document.querySelector('.gnav20 .gnav20-desktop').offsetHeight){
		//	document.querySelector('#oneSearchContainerGnav>div').style.marginTop = '35px'
		//}
					
		var addScript1 = document.createElement('script');
		addScript1.type = 'text/javascript';
		addScript1.src = dom + '/onedigital/search/build/common/bundle.common.js';
		addScript1.onload = function(){
			console.log('bundle common loaded',window.renderAutoSuggest)
		}
		document.getElementsByTagName('head')[0].appendChild(addScript1);

		var addScript2 = document.createElement('script');
		addScript2.type = 'text/javascript';
		addScript2.src = dom + '/onedigital/search/build/autosuggest/bundle.autosuggest.js';
		addScript2.onload = function(){
			console.log('bundle auto loaded',window.renderAutoSuggest)
		}
		document.getElementsByTagName('head')[0].appendChild(addScript2);
		
		window.searchFileInti = 0

		clearInterval(window.searchFileInt)

		window.searchFileInt = setInterval(function(){
			if(searchFileInti > 500){clearInterval(window.searchFileInt)}
			window.searchFileInti ++
			window.oneSearchTrigger = document.querySelector('#oneSearchContainerGnav button.searchBtn')
			//console.log(searchFileInti,'--int',!window.renderAutoSuggest , !window.oneSearchTrigger)
			
			if(window.renderAutoSuggest && !window.autoRendered){
				window.renderAutoSuggest(window.acConfig)
				window.autoRendered = true
				console.log(searchFileInti,'----int renderAutoSuggest')
			}
			
			if(window.oneSearchTrigger && window.autoRendered){
				window.oneSearchTrigger.parentElement.style.height = '0'
				window.oneSearchTrigger.parentElement.style.overflow = 'hidden'
				window.oneSearchTrigger.click()
				console.log(searchFileInti,'----int oneSearchTrigger click')
				clearInterval(window.searchFileInt)
			}
				
		},30)

    }
    
    function openK12Search(){
    	var searchDiv = document.createElement('div')
			searchDiv.innerHTML = '<div style="margin:0 auto; width:calc(100vw - 17px); max-width:1272px; padding: 0 0 0 144px;"><div style="height:64px; background:#FFF; position:relative; top:-60px"></div></div>'+
			'<div style="height:100vh; background:#FFF; position:relative; top:-60px"><form action="https://www.verizon.com/learning/search" method="GET" class="gnav20-search-para gnav20-search-form" autocomplete="off">'+
			'<button type="button" id="gnav20-closex-searcher" class="gnav20-close-icon" aria-label="Close Search Modal"></button>'+
			'<input name="q" class="gnav20-search-inp" placeholder="What are you looking for?"/>'+
			'<span tabindex="0" class="gnav20-clearInput"  aria-label="clear search form text, button" style="cursor:pointer"></span></form></div>'
			searchDiv.className = 'gnav20'
			searchDiv.style = 'position:fixed; width:100vw; height:100vh; z-index:4999; text-align:center; top:60px' 
			document.body.appendChild(searchDiv)

			var searchBut = document.getElementById('gnav20-closex-searcher')
			searchBut.addEventListener('click', function(){event.preventDefault();searchDiv.remove()})
			searchBut.focus()

			var mystyText = '.gnav20 .gnav20-search-para.gnav20-search-form{height:100%; width:100%; max-width:1272px; margin:0 auto;top:0; border:0; position:relative}'+
			'.gnav20 .gnav20-search-para.gnav20-search-form .gnav20-close-icon{right: 36px; position: absolute; width: 24px; height: 24px;}'+
			'.gnav20 .gnav20-search-inp{width:80vw; max-width:400px; border-bottom: 2px solid #333; font-size:24px; top: 48px; position: absolute; right: 36px; padding: 0 0 12px 0; background:#FFF !important}'+
			'.gnav20 .gnav20-clearInput:focus{outline:1px dashed black;outline-offset:2px}'
			var mysty = document.createElement('style')
			mysty.textContent = mystyText
			document.head.appendChild(mysty)
			var clearMe = document.querySelector('.gnav20 .gnav20-search-form .gnav20-clearInput')
			clearMe && ['click','keydown'].forEach( function(evt) {clearMe.addEventListener(evt, function(){clearMe.previousElementSibling.value="";if(event.key == "Tab"){document.getElementById('gnav20-closex-searcher').focus()}}, false);});

    }
    
    // add click div to body for desktop open search menu
    var clickDiv = document.createElement('div')
    clickDiv.classList.add('gnav20-click-div')
    document.body.appendChild(clickDiv)
    
}  
  
//*******************************************
//Polyfill for IE

if (!Element.prototype.matches) {
    Element.prototype.matches = Element.prototype.msMatchesSelector ||
        Element.prototype.webkitMatchesSelector;
}
if (!Element.prototype.closest) {
    Element.prototype.closest = function (s) {
        var el = this;
        do {
            if (el.matches(s)) return el;
            el = el.parentElement || el.parentNode;
        } while (el !== null && el.nodeType === 1);
        return null;
    };
}


//Eyebrow position - mobile
function mobilelabelposition() {
    var xc = document.querySelectorAll(".gnav20-mobile .gnav20-eyebrow-links-list-item.gnav20-more")
    var vyc = document.querySelector(".gnav20-mobile  .gnav20-eyebrow-link-list-item.gnav20-more");
    if (vyc) {
        var vy = vyc.children;
        if (vy.length > 2) {
            var p = 1;
            for (i = 0; i < vy.length; i++) {
                if (!vy[i].classList.contains("gnav20-selected")) {
                    vy[i].classList.add("gnav20-nonselcted" + p);
                    p = p + 1;
                }
            }
        }
    }

    if (xc != undefined && xc.length > 0) {
        var xc = document.querySelectorAll(".gnav20-mobile .gnav20-eyebrow-links-list-item.gnav20-more")
        var xpos = 0;
        for (var p = 0; p <= (xc[0].children.length) - 1; p++) {
            if (!(xc[0].children[p].classList.contains("gnav20-selected"))) {
                xc[0].children[p].style.left = xpos + "%";
                xpos = xpos + 50;
            }
        }
    }
} 
//*******************************************
//Language Mobile Content 
function laguageMenuToggle(event) {
    var eTarget = event.target || this;
    if (eTarget.closest('.gnav20-language-box') && eTarget.closest('.gnav20-language-box').querySelector('.gnav20-dropdown-menu')) {
        if (eTarget.closest('.gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.contains("gnav20-hide")) {
            signinContentHide();
            storeContentHide();
            document.querySelector("#gnav20-mobile-menu #gnav20-ulwrapper").classList.add("gnav20-hide");
            eTarget.closest('.gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.remove("gnav20-hide");
            if (window.innerWidth < 1272) {
                eTarget.closest('.gnav20-mobile .gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.add("gnav20-open-menu");
                document.querySelector(".gnav20-vzhmoverlay").classList.toggle('gnav20-menuop');
            }
        } else {
            languageContentHide();
            MenuContentBack();
            var element = document.querySelectorAll(".gnav20-mobile .gnav20-visibilty-hidden");
            if (window.innerWidth < 1272 && eTarget.closest('.gnav20-mobile .gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.contains("gnav20-open-menu")) {
                eTarget.closest('.gnav20-mobile  .gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.remove("gnav20-open-menu");
                document.querySelector(".gnav20-vzhmoverlay").classList.toggle('gnav20-menuop');
            }
            for (var i = 0; i < element.length; i++) {
                element[i].classList.remove("gnav20-visibilty-hidden");
            }
        }
    }
}

function mobileLwindowclose(event) {
		var eTarget = event.target || this;
    if (eTarget.closest('.gnav20-mobile .gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.contains("gnav20-open-menu")) {
        eTarget.closest('.gnav20-mobile .gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.remove("gnav20-open-menu");
        eTarget.closest('.gnav20-mobile .gnav20-language-box').querySelector('.gnav20-dropdown-menu').classList.add("gnav20-hide");
        document.querySelector(".gnav20-vzhmoverlay").classList.toggle('gnav20-menuop');
        document.querySelector("#gnav20-mobile-menu #gnav20-ulwrapper").classList.remove("gnav20-hide");
    }
}





//*******************************************
function signinToggleForMobile() {
    var signinmobiled = document.querySelectorAll(".gnav20-mobile .gnav20-account-utility .gnav20-dropdown-menu")
    if((signinmobiled.length > 0) && (signinmobiled[0].classList.contains("gnav20-hide"))){
        languageContentHide();
        if(!signinmobiled[0].closest('.gnav20-stacked-utility')){
        	document.querySelector("#gnav20-mobile-menu #gnav20-ulwrapper").classList.add("gnav20-hide");
        }else{
        	document.querySelector("#gnav20-mobile-menu .gnav20-eyebrow").classList.add("gnav20-hide");
        }
        
        signinmobiled[0].classList.remove("gnav20-hide");
    } else {
        signinContentHide();
        storeContentHide();
        MenuContentBack();
        var element = document.querySelectorAll(".gnav20-mobile .visibilty-hidden");
        for (var i = 0; i < element.length; i++) {
            element[i].classList.remove("gnav20-visibilty-hidden");
        }
    }

    if (document.querySelector(".gnav20-mobile #footerlink .gnav20-footerStores") !== null) {
        for (var i = 0; i < document.querySelectorAll(".gnav20-mobile #gnav20-footerlink .gnav20-footerStores").length; i++) {
            document.querySelectorAll(".gnav20-mobile #gnav20-footerlink .gnav20-footerStores")[i].classList.add("gnav20-hide");
        }
    }
    toggleAriaHiddenGnav20("signin", !0); 
    gnav20.toggleMobileSignInHideEls('none')      
    gnav20.setFocusTrap(gnav20.mobileMenu)
    if (document.querySelector(".gnav20-mobile #gnav20-mobile-menu .gnav20-dropdown-menu .gnav20-goback .gnav20-back-to-menu")) {
        document.querySelector(".gnav20-mobile #gnav20-mobile-menu .gnav20-dropdown-menu .gnav20-goback .gnav20-back-to-menu").focus();
    }
}
//*******************************************
//Signin Mobile Content Hideback
function languageContentHide() {
    document.querySelector(".gnav20-mobile #gnav20-ulwrapper").classList.add("gnav20-hide");
    document.querySelector("#gnav20-mobile-menu #gnav20-ulwrapper").classList.remove("gnav20-hide");
}
//*******************************************
//Signin Mobile Content Hideback
function signinContentHide() {
	var x = document.querySelectorAll(".gnav20-mobile .gnav20-dropdown-menu"),
			eyebrow = document.querySelector("#gnav20-mobile-menu .gnav20-eyebrow");
			
    for (i = 0; i < x.length; i++) {
  		 x[i].classList.add("gnav20-hide")
  	}
    if(eyebrow){eyebrow.classList.remove("gnav20-hide");}
    
    document.querySelector("#gnav20-mobile-menu #gnav20-ulwrapper").classList.remove("gnav20-hide");
    toggleAriaHiddenGnav20("signin", !1); 
    gnav20.toggleMobileSignInHideEls('block')      
    gnav20.clearFocusTrap(gnav20.mobileMenu)
    if (document.querySelector(".gnav20-mobile #gnav20-mobile-menu #gnav20-footerlink .gnav20-account-utility .gnav20-sign-in")) {
        document.querySelector(".gnav20-mobile #gnav20-mobile-menu #gnav20-footerlink .gnav20-account-utility .gnav20-sign-in").focus();
    }
}
//*******************************************
//Stores Mobile Content Hideback 
function storeContentHide() {
    var e =  document.querySelectorAll(".gnav20-mobile .gnav20-stores-list")
    for (i=0;i<e.length; i++){
        e[i].classList.add("gnav20-hide");    
    }
    
    document.querySelector("#gnav20-mobile-menu #gnav20-ulwrapper").classList.remove("gnav20-hide");
   // toggleAriaHiddenGnav20("signin", !1);
  //  if (document.querySelector(".gnav20-mobile #gnav20-mobile-menu #gnav20-footerlink .gnav20-account-utility .gnav20-sign-in")) {
    //    document.querySelector(".gnav20-mobile #gnav20-mobile-menu #gnav20-footerlink .gnav20-account-utility .gnav20-sign-in").focus();
   // }
}
//*******************************************
//Signin Mobile Content Hideback
function completeMenuhide() {
    if (winWidth <= 1272) {
        var cg = document.querySelectorAll("#gnav20-mobile-menu .gnav20-global-nav-list");
        cg[0].classList.add("gnav20-hide");
    }
}

function completeMenuShow() {
    if (winWidth <= 1272) {
        var cg = document.querySelectorAll("#gnav20-mobile-menu .gnav20-global-nav-list");
        cg[0].classList.remove("gnav20-hide");
    }
}
//*******************************************

//*******************************************
//Mobile Menu content Getback
function MenuContentBack() {
    var x = document.querySelectorAll(".gnav20-dont-show-in-mobile");
    for (i = 0; i < x.length; i++) {
        x[i].classList.remove("gnav20-dont-show-in-mobile");
        x[i].style.display = 'block';
    }
    x = document.querySelectorAll(".gnav20-current");
    for (i = 0; i < x.length; i++) {
        x[i].classList.remove("gnav20-current");
    }
    x = document.querySelectorAll(".gnav20-autoflow");
    for (i = 0; i < x.length; i++) {
        x[i].classList.remove("gnav20-autoflow");
    }
    x = document.querySelectorAll(".gnav20-mobile .gnav20-sub-menu");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    x = document.querySelectorAll(".gnav20-mobile .gnav20-submenu-column.gnav20-L2");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    x = document.querySelectorAll(".gnav20-mobile .gnav20-submenu-column.gnav20-L3");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    //x = document.querySelectorAll(".gnav20-Level-2.gnav20-sub-nav-list.gnav20-current");
    x = document.querySelectorAll("ul.gnav20-submenu-column.gnav20-L1 > li.gnav20-current");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "unset";
    }
	
	x = document.querySelectorAll(".gnav20-mobile .gnav20-goback");
    for (i = 0; i < x.length; i++) {
        x[i].removeAttribute("style")
    }
    
	x = document.querySelector(".gnav20-mobile .gnav20-sub-lob-box .gnav20-dropdown-menu");
    if (x && !x.classList.contains ("gnav20-hide")) {
        x.classList.add("gnav20-hide");
    }
	
	var lobLink = document.querySelector(".gnav20-mobile .gnav20-sub-lob-box .gnav20-sub-lob");
	if (lobLink && lobLink.classList.contains("gnav20-hide")) {
		lobLink.classList.remove("gnav20-hide");
	}

}

//*******************************************

function megaAnimation(selectedMenu){
	window.megaColumns = selectedMenu.querySelectorAll("[class*='offRight']");
	
	setTimeout(function(){
		var col = 0;
		for (i = 0; i < window.megaColumns.length; i++){	
			window.megaColumns[i].classList.add('column' + col + '-transLeft');	
			col++;					
		}
	},100)
}

/* this polyfill should no longer be needed. commenting on 7/23/2024	
//polyfill for IE
(function () {
  if ( typeof window.CustomEvent === "function" ) return false; //If not IE
  function CustomEvent ( event, params ) {
    params = params || { bubbles: false, cancelable: false, detail: undefined };
    var evt = document.createEvent( 'CustomEvent' );
    evt.initCustomEvent( event, params.bubbles, params.cancelable, params.detail );
    return evt;
   }
  CustomEvent.prototype = window.Event.prototype;
  window.CustomEvent = CustomEvent;
})();
*/

function toggleMenuL1(event) {
	event.preventDefault()
	var eTarget = event.target || this;
	if(eTarget.getAttribute('aria-expanded') == "false") {
		document.querySelector('.gnav20 .gnav20-desktop .gnav20-logo').style.zIndex = 4505 // logo is no longer aria-hidden with L1 open
		document.querySelector('.gnav20 .gnav20-desktop .gnav20-logo').style.position = 'relative'
		openMenuL1(event);
		
	} else {
		if(event.target.closest(".gnav20-featured-card")){	
			document.querySelector('.gnav20 .gnav20-desktop .gnav20-logo').style.zIndex = '' // logo is no longer aria-hidden with L1 open
			closeMenuL1(event);
		}
	}
}

function openMenuL1(event) {
	if(event && event.target.closest('.gnav20-desktop')){
		gnav20.signInCloseMenu()
		gnav20.closeCart()
	}
	toggleAriaHiddenGnav20("L1", !0);
	
	var eTarget = event.target || this;
	var myL2 = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) .gnav20-submenu-column.gnav20-L2")
	for (i = 0; i < myL2.length; i++) {
		myL2[i].style.display = 'none';
	}
	
	var myL3 = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) .gnav20-submenu-column.gnav20-L3")
	for (i = 0; i < myL3.length; i++) {
		myL3[i].style.display = 'none';
	}
	
	//var myL2Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card:not(.gnav20-featured-grouping) li.gnav20-Level-2 > a.gnav20-subanchor.gnav20-haschild")
	var myL2Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card:not(.gnav20-featured-grouping) ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-haschild")
	for (i = 0; i < myL2Links.length; i++) {
		myL2Links[i].classList.remove('gnav20-open');
		myL2Links[i].setAttribute('aria-expanded',false);
	}
	
	//var myL3Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card:not(.gnav20-featured-grouping) li.gnav20-Level-3 > a.gnav20-subanchor.gnav20-haschild")
	var myL3Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card:not(.gnav20-featured-grouping) ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-haschild")
	for (i = 0; i < myL3Links.length; i++) {
		myL3Links[i].classList.remove('gnav20-open');
		myL3Links[i].setAttribute('aria-expanded',false);
	}
	
	if(event.target.closest(".gnav20-featured-card") && event.target.closest(".gnav20-desktop")){
		var L1FeaturedCard = event.target.closest(".gnav20-featured-card").querySelectorAll(".gnav20-desktop .gnav20-featured-card .gnav20-left-featured-card, .gnav20-desktop .gnav20-featured-card .gnav20-right-featured-card")
		for (i = 0; i < L1FeaturedCard.length; i++) {
			L1FeaturedCard[i].style.display = 'block';
		}
		
		/*
		if(event.target.closest(".gnav20") && !event.target.closest(".gnav20").classList.contains("gnav20-sticky")) {
			event.target.closest(".gnav20").classList.add("gnav20-sticky");
			event.target.closest(".gnav20").classList.add("stickyadded");			
		}
		*/
		
		document.body.classList.add("gnav20-no-scroll");		
		
		gnav20.activeCloseButton = event.target.closest(".gnav20-featured-card").querySelector('.gnav20-nav-close')
	}
	
	
	if(event.target.closest(".gnav20-L1-aligned") && event.target.closest(".gnav20-desktop")){
		//console.log(event.target.offsetLeft);
		if (event.target.closest(".gnav20-L1-aligned").querySelector(".gnav20-content-wrapper") ) {
			event.target.closest(".gnav20-L1-aligned").querySelector(".gnav20-content-wrapper").style.marginLeft = (event.target.offsetLeft - 40) + 'px';
		}
	}
		
	// *************************************************************************
	// Menu Animation Start
	// *************************************************************************
	if (eTarget.closest(".gnav20-desktop") && eTarget.closest(".gnav20-primary-menu") && eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-sub-menu")) {
			if (document.activeElement && !event.target.closest(".gnav20-featured-card")){
				document.activeElement.blur();
			}
			var buttons = eTarget.closest('.gnav20-global-nav-list.gnav20-navigation-list').querySelectorAll('button.gnav20-menu-label-button')
			for (i = 0; i < buttons.length; i++){
				buttons[i].setAttribute('aria-expanded',false)
			}
			

		var selectedMenu = eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-sub-menu"),
				main;
		selectedMenu.style.display = "flex";
		eTarget.setAttribute('aria-expanded', 'true');
		//eTarget.focus();
		//console.log('tried to set focus on target')
		/*
		if(main = eTarget.closest(".gnav20-main")){
			main.classList.add('gnav20-nav-open')
		}			
		*/
		var menuElements = document.querySelectorAll('.gnav20-desktop .gnav20-sub-menu');
		for (i = 0; i <= menuElements.length - 1; i++) {
			if (menuElements[i] != selectedMenu) {
				menuElements[i].style.display = "none"
			}
		}

		window.selectedMenu = selectedMenu
		setTimeout(function () {
			var mega = window.selectedMenu.closest('.gnav20-mega-drawer')
					addClass = mega ? 'gnav20-mega-active' : 'gnav20-grouping-active',
					main = eTarget.closest(".gnav20-main");
			window.selectedMenu.style.display = "flex";
			/*
			if(main){
					main.classList.add('gnav20-nav-open')
				}
				*/
			window.selectedMenu.classList.add(addClass)
			window.selectedMenu.querySelector('.gnav20-content-wrapper').classList.add(addClass);
			
			if(eTarget.closest(".gnav20-featured-card") && !eTarget.closest(".gnav20-featured-grouping")){			
				window.selectedMenu.querySelector('.gnav20-featured-card-top-label').classList.add("gnav20-column-highlight");
				window.selectedMenu.querySelector('.gnav20-submenu-column').classList.add("gnav20-column-highlight");
			}

			if(mega){
				megaAnimation(window.selectedMenu)
			}
			
			var qString = '.gnav20-sub-menu .'+ addClass;
						if(document.querySelector('.gnav20.gnav20-sticky .gnav20-sticky-content') &&  document.querySelector(qString) && window.innerHeight < document.querySelector(qString).offsetHeight + document.querySelector('.gnav20.gnav20-sticky .gnav20-sticky-content').offsetHeight){
							document.querySelector('.gnav20.gnav20-sticky .gnav20-sticky-content').style.position = 'static';
							//this is messing up sticky skinnyNav and is likely no longer necessary
							window.scrollTo(0,0)
						}  
								
		}, 10);
		
				if (eTarget.closest(".gnav20-mega-drawer")) {
					gnav20.l1Target = eTarget;

					//var mymegaL2 = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer li.gnav20-Level-2 > a.gnav20-subanchor")
					var mymegaL2 = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer ul.gnav20-submenu-column.gnav20-L1 > li > a")
					for (i = 0; i < mymegaL2.length; i++) {
						mymegaL2[i].classList.remove('gnav20-open');
						mymegaL2[i].setAttribute('aria-expanded','false');
					}
					
					var myL2Menu = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-submenu-column.gnav20-L2")
					for (i = 0; i < myL2Menu.length; i++) {
						myL2Menu[i].style.display = 'none';
					}
					
					setTimeout( function () { 
						var mouseevent = new CustomEvent('mouseover', {
							'view': window,
							'bubbles': true,
							'cancelable': true
						});
						//var firstElement = selectedMenu.querySelector("li.gnav20-Level-2.gnav20-sub-nav-list:not(.gnav20-hide-on-desktop)");
						var firstElement = selectedMenu.querySelector("ul.gnav20-submenu-column.gnav20-L1 > li:not(.gnav20-hide-on-desktop)");
						if(firstElement) {
							//var element = firstElement.querySelector(".gnav20-subanchor.gnav20-haschild");
							var element = firstElement.querySelector("a.gnav20-haschild");
							if(element) {
								var container = document.querySelector('.gnav20-desktop .gnav20-mega-drawer .gnav20-submenu-column'),
										maxColHeight = 460;
								element.dispatchEvent(mouseevent);
								element.classList.add('gnav20-open');
								if(container){
									container.removeAttribute('style')
								}
								var ul = element.parentElement.querySelectorAll('ul');
								for (i = 0; i <= ul.length - 1; i++) {
									ul[i].style.display = 'block';
									if(container && ul[i].offsetHeight > maxColHeight){
										maxColHeight = ul[i].offsetHeight;
										container.style.height = maxColHeight + 40 + 'px';
										if(container.closest('.gnav20-sub-menu')){
											container.closest('.gnav20-sub-menu').style.maxHeight = maxColHeight + 200 + 'px';
										}
									}
								}
							}
						}
						gnav20.l1Target.focus();
					}, 100);
				}
				
	} else { // Mobile code below 	
		var cg = document.querySelectorAll("#gnav20-mobile-menu .gnav20-global-nav-list");
		for (i = 0; i < cg.length; i++) {
			cg[i].classList.add("gnav20-non-header");
		}
		//x = document.querySelectorAll(".gnav20-mobile .gnav20-submenu-column .gnav20-Level-2");
		x = document.querySelectorAll(".gnav20-mobile .gnav20-submenu-column ul.gnav20-submenu-column.gnav20-L1 > li");
		if (eTarget.closest(".gnav20-mobile").querySelector(".gnav20-autoflow")) {
			eTarget.closest(".gnav20-mobile").querySelector(".gnav20-autoflow").classList.remove("gnav20-autoflow");
		}
		eTarget.closest(".gnav20-mobile .gnav20-primary-menu").querySelector(".gnav20-sub-menu").classList.add("gnav20-autoflow");
		for (i = 0; i < x.length; i++) {
			x[i].style.display = "block";
		}
		if (eTarget.nextElementSibling != null) {
			eTarget.nextElementSibling.setAttribute('aria-expanded', 'true');
			window.mySubMenuTarget = eTarget.nextElementSibling;
			setTimeout('window.mySubMenuTarget.focus()', 4)
		}

		var sel_eyebrow = document.querySelectorAll(".gnav20-mobile .gnav20-eyebrow .gnav20-main-header.gnav20-selected");
		for (i = 0; i < sel_eyebrow.length; i++) {
			sel_eyebrow[i].style.display = "none";
		}
		eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-sub-menu").style.display = "block"
		var x = eTarget.closest(".gnav20-mobile").querySelectorAll(".gnav20-primary-menu");
		for (i = 0; i < x.length; i++) {
			x[i].classList.add("gnav20-dont-show-in-mobile");
		}
		eTarget.closest(".gnav20-primary-menu").classList.add("gnav20-current");
		eTarget.closest(".gnav20-primary-menu").classList.remove("gnav20-dont-show-in-mobile");
		
		gnav20.mobileMenu = document.getElementById('gnav20-mobile-menu')
		gnav20.mobileMenu.classList.add('gnav20-openL1')
		gnav20.setFocusTrap(gnav20.mobileMenu)
		
		
		
		if(event){
			event.preventDefault();
			event.stopPropagation();	
		}
	}	
    //eTarget.parentElement.classList.add("shiftMenu");
    //console.log('document.activeElement',document.activeElement)
}

function menuL2ToggleOnSpaceKey(event){
	if(event !== undefined && event.keyCode !== null &&  event.keyCode=== 32){
		eTarget.click();
	}
}

function toggleMenuL2(event) {
	event.preventDefault()
	var eTarget = event.target || this;
	if(eTarget.getAttribute('aria-expanded') == "false") {
		openMenuL2(event);
	} else {
		if(event.target.closest(".gnav20-featured-card")){
			closeMenuL2(event);
		}
	}
}

function columnHighlight2(event, highlight){
	//console.log('navigation.js - columnHighlight2')
	var list = event.target.closest('ul'),
			highlight = highlight ? 'add' : 'remove'
	list.classList[highlight]('gnav20-column-highlight');
	if(list.previousElementSibling) {		
		list.previousElementSibling.classList[highlight]('gnav20-column-highlight');
	}
}

function openMenuL2(event) {
	if(gnav20.megaL2hover && gnav20.megaL2hover.parentElement && gnav20.megaL2hover.parentElement  != gnav20.megaL2hover.parentElement.parentElement.querySelector(':hover') && window.getComputedStyle(gnav20.mobileHeader).getPropertyValue('display')=='none'){
		return
	}  
	var eTarget;
	if(event && event.target){
		gnav20.megaL2hover = null;
		eTarget = event.target
	}else{
		eTarget = gnav20.megaL2hover ? gnav20.megaL2hover : this;
	}  
    //var myL2 = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-isactive > li > a.gnav20-subanchor, .gnav20-desktop .gnav20-featured-card .gnav20-isactive > li > a.gnav20-subanchor.gnav20-haschild")
    var myL2 = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-isactive > li > a, .gnav20-desktop .gnav20-featured-card .gnav20-isactive > li > a.gnav20-haschild")
    for (i = 0; i < myL2.length; i++) {
        myL2[i].classList.remove('gnav20-open');
		myL2[i].setAttribute('aria-expanded','false');
    }
	
	//var myL3Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card li.gnav20-Level-3 > a.gnav20-subanchor.gnav20-haschild")
	var myL3Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-haschild")
	for (i = 0; i < myL3Links.length; i++) {
		myL3Links[i].classList.remove('gnav20-open');
		myL3Links[i].setAttribute('aria-expanded','false');
	}
	
	if(eTarget.classList){
		eTarget.classList.add('gnav20-open');
    eTarget.setAttribute('aria-expanded','true');
		eTarget.focus();
	}
    
	if(eTarget.closest && eTarget.closest(".gnav20-featured-card")){
		var L1FeaturedCard = event.target.closest(".gnav20-featured-card").querySelectorAll(".gnav20-featured-card .gnav20-L2-featured-card")
		for (i = 0; i < L1FeaturedCard.length; i++) {
			L1FeaturedCard[i].style.display = 'block';
		}
		columnHighlight2(event, false)
	}
    
  var myL2Menu = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-submenu-column.gnav20-L2, .gnav20-desktop .gnav20-featured-card .gnav20-submenu-column.gnav20-L2")
  for (i = 0; i < myL2Menu.length; i++) {
      myL2Menu[i].style.display = 'none';
  }
	
	var myL3 = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card .gnav20-submenu-column.gnav20-L3")
	for (i = 0; i < myL3.length; i++) {
		myL3[i].style.display = 'none';
	}
	if(eTarget.closest && eTarget.closest(".gnav20-featured-card")){
		var L1FeaturedCard = event.target.closest(".gnav20-featured-card").querySelectorAll(".gnav20-featured-card .gnav20-left-featured-card, .gnav20-desktop .gnav20-featured-card .gnav20-right-featured-card")
		for (i = 0; i < L1FeaturedCard.length; i++) {
			L1FeaturedCard[i].style.display = 'none';
		}
	}
    
  if (eTarget.closest && eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li") && eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").querySelector(".gnav20-submenu-column.gnav20-L2")) {
        //eTarget.closest(".gnav20-sub-nav-list").querySelector(".gnav20-submenu-column.gnav20-L2").style.display = "block";
		
		var myL3Columns =  eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").querySelectorAll(".gnav20-submenu-column.gnav20-L2"),
				container = maxColHeight = document.querySelector('.gnav20-desktop .gnav20-mega-drawer .gnav20-submenu-column'),
				maxColHeight = 460;
		if(container){
			container.removeAttribute('style')
		}
		for (i = 0; i < myL3Columns.length; i++) {
			myL3Columns[i].style.display = 'block';
			if(eTarget.closest(".gnav20-featured-card")){
				myL3Columns[i].classList.add("gnav20-column-highlight");
			}
			if(container && myL3Columns[i].offsetHeight > maxColHeight){
				maxColHeight = myL3Columns[i].offsetHeight;
				container.style.height = maxColHeight + 40 + 'px';
				if(container.closest('.gnav20-sub-menu')){
					container.closest('.gnav20-sub-menu').style.maxHeight = maxColHeight + 200 + 'px';
				}
			}
		}
		
        if (eTarget.closest(".gnav20-submenu-column")) {			
            eTarget.closest(".gnav20-submenu-column").classList.add("gnav20-isactive");
        }		
        
        if (eTarget.closest(".gnav20-mobile")) {
            //var x = eTarget.closest(".gnav20-primary-menu").querySelectorAll(".gnav20-Level-2");
            //var y = eTarget.closest(".gnav20-submenu-column").querySelectorAll(".gnav20-Level-2.gnav20-sub-nav-list");
            var x = eTarget.closest(".gnav20-primary-menu").querySelectorAll("ul.gnav20-submenu-column.gnav20-L1 > li");
            var y = eTarget.closest(".gnav20-submenu-column").querySelectorAll("ul.gnav20-submenu-column.gnav20-L1 > li");
            eTarget.closest(".gnav20-mobile").querySelector(".gnav20-autoflow").classList.remove("gnav20-autoflow");
            //eTarget.closest(".gnav20-mobile .gnav20-sub-nav-list").querySelector(".gnav20-L2-content-wrapper").classList.add("gnav20-autoflow");
            eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector(".gnav20-L2-content-wrapper").classList.add("gnav20-autoflow");
            for (i = 0; i < y.length; i++) {
                y[i].style.display = "none";
            }
            eTarget.parentElement.style.display = "block";
            eTarget.closest(".gnav20-primary-menu.gnav20-current").querySelector(".gnav20-goback").style.display = "none";
            for (i = 0; i < x.length; i++) {
                x[i].classList.add("gnav20-dont-show-in-mobile");
            }
            //eTarget.closest(".gnav20-Level-2").classList.add("gnav20-current");
            //eTarget.closest(".gnav20-Level-2").classList.remove("gnav20-dont-show-in-mobile");
            eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").classList.add("gnav20-current");
            eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").classList.remove("gnav20-dont-show-in-mobile");
            eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-goback").classList.add("gnav20-dont-show-in-mobile");
            /*
            if(eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list") && eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback") ){
            	eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback").setAttribute('aria-expanded','true');
            	eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback").focus();
            }
            */
            if(eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li") && eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-goback") ){
            	eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-goback").setAttribute('aria-expanded','true');
            	eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-goback").focus();
            }
            
            gnav20.setFocusTrap(gnav20.mobileMenu)
            
            if(event){
			        event.preventDefault();
			        event.stopPropagation();
				    }
	      }
  }
}

function toggleMenuL3(event) {
	event.preventDefault()
	var eTarget = event.target || this;
	if(eTarget.getAttribute('aria-expanded') == "false") {
		openMenuL3(event);
	} else {
		if(event.target.closest(".gnav20-featured-card")){
			closeMenuL3(event);
		}
	}
}


function openMenuL3(event) {
		var eTarget = event.target || this;
    if (eTarget && eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li") && eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li").querySelector(".gnav20-submenu-column.gnav20-L3")) {
        // Null Check
    	//var currentElementL2 = eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li.gnav20-current");
    	var currentElementL2 = eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li.gnav20-current");
    	if(currentElementL2 && currentElementL2.querySelector(".gnav20-goback")){
            currentElementL2.querySelector(".gnav20-goback").style.display="none";
        }
		
		var myL3 = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card .gnav20-submenu-column.gnav20-L3")
		for (i = 0; i < myL3.length; i++) {
			myL3[i].style.display = 'none';
		}
		
		if(event.target.closest(".gnav20-featured-card")){
			var L2FeaturedCard = event.target.closest(".gnav20-featured-card").querySelectorAll(".gnav20-featured-card .gnav20-L2-featured-card")
			for (i = 0; i < L2FeaturedCard.length; i++) {
				L2FeaturedCard[i].style.display = 'none';
			}
			columnHighlight2(event, false)
		}
		
		
		//var myL2Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card li.gnav20-Level-3 > a.gnav20-subanchor.gnav20-haschild")
		var myL2Links = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-haschild")
		for (i = 0; i < myL2Links.length; i++) {
			myL2Links[i].classList.remove('gnav20-open');
			myL2Links[i].setAttribute('aria-expanded','false');
		}		
		eTarget.classList.add('gnav20-open');
		eTarget.setAttribute('aria-expanded','true');
		
        var myL3Links = eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li").querySelectorAll(".gnav20-submenu-column.gnav20-L3");
		for (i = 0; i < myL3Links.length; i++) {
			myL3Links[i].style.display = "block";
			if(eTarget.closest(".gnav20-featured-card")){
				myL3Links[i].classList.add("gnav20-column-highlight");
			}
		}
		
        
        if (eTarget.closest(".gnav20-mobile")) {
            //var x = eTarget.closest(".gnav20-primary-menu").querySelectorAll(".gnav20-Level-3");
            var x = eTarget.closest(".gnav20-primary-menu").querySelectorAll("ul.gnav20-submenu-column.gnav20-L2 > li");
            for (i = 0; i < x.length; i++) {
                x[i].classList.add("gnav20-dont-show-in-mobile");
            }
            eTarget.closest(".gnav20-L2").classList.add('gnav20-submenu-open')
            //eTarget.closest(".gnav20-Level-3").classList.add("gnav20-current");
            //eTarget.closest(".gnav20-Level-3").classList.remove("gnav20-dont-show-in-mobile");
            eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li").classList.add("gnav20-current");
            eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li").classList.remove("gnav20-dont-show-in-mobile");
            //eTarget.closest(".gnav20-Level-2").querySelector(".gnav20-goback").classList.add("gnav20-dont-show-in-mobile");
            eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").querySelector(".gnav20-goback").classList.add("gnav20-dont-show-in-mobile");
            /*
            if(eTarget.closest(".gnav20-mobile .gnav20-Level-3.gnav20-sub-nav-list") && eTarget.closest(".gnav20-mobile .gnav20-Level-3.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback") ){
            	eTarget.closest(".gnav20-mobile .gnav20-Level-3.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback").setAttribute('aria-expanded','true');
            	eTarget.closest(".gnav20-mobile .gnav20-Level-3.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback").focus();
            }
            */
            if(eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L2 > li") && eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L2 > li").querySelector("a.gnav20-goback") ){
            	eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L2 > li").querySelector("a.gnav20-goback").setAttribute('aria-expanded','true');
            	eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L2 > li").querySelector("a.gnav20-goback").focus();
            }
            
            gnav20.setFocusTrap(gnav20.mobileMenu)
            
            if(event){
		        	event.preventDefault();
		        	event.stopPropagation();
		        }
        }
    }
}

function goBackToL1(event) {
		var eTarget = event.target || this;
    if (eTarget.closest(".gnav20-mobile") && eTarget.closest(".gnav20-primary-menu") && eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-sub-menu")) {
        eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-sub-menu").style.display = "none";
        var sel_eyebrow = document.querySelectorAll(".gnav20-mobile .gnav20-eyebrow .gnav20-main-header.gnav20-selected");
        eTarget.closest(".gnav20-mobile").querySelector(".gnav20-autoflow").classList.remove("gnav20-autoflow");
        var cg = document.querySelectorAll("#gnav20-mobile-menu .gnav20-global-nav-list");
        for (i = 0; i < cg.length; i++) {
            cg[i].classList.remove("gnav20-non-header");
        }
        for (i = 0; i < sel_eyebrow.length; i++) {
            sel_eyebrow[i].style.display = "block";
        }
        var x = eTarget.closest(".gnav20-mobile").querySelectorAll(".gnav20-primary-menu");
        for (i = 0; i < x.length; i++) {
            x[i].classList.remove("gnav20-dont-show-in-mobile");
            x[i].classList.remove("gnav20-current");
        }
        if (eTarget.previousElementSibling != null && eTarget.previousElementSibling.previousElementSibling != null) {
            eTarget.previousElementSibling.previousElementSibling.setAttribute('aria-expanded', 'false');
            window.myMenuBackTarget = eTarget.previousElementSibling.previousElementSibling;
            setTimeout('window.myMenuBackTarget.focus()', 10)
        }
        
        document.getElementById('gnav20-mobile-menu').classList.remove('gnav20-openL1')
        gnav20.setFocusTrap(gnav20.mobileMenu)
        
        if(event){
        	event.preventDefault();
        	event.stopPropagation();
        }
    }
}

function goBackToL2(event) {
		var eTarget = event.target || this;
    //if (eTarget.closest(".gnav20-mobile") && eTarget.closest(".gnav20-Level-2") && eTarget.closest(".gnav20-Level-2").querySelector(".gnav20-submenu-column.gnav20-L2")) {
   	if (eTarget.closest(".gnav20-mobile") && eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li") && eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").querySelector(".gnav20-submenu-column.gnav20-L2")) {
        //var l2SubMenu = eTarget.closest(".gnav20-Level-2").querySelectorAll(".gnav20-submenu-column.gnav20-L2");
        var l2SubMenu = eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").querySelectorAll(".gnav20-submenu-column.gnav20-L2");
		for (i = 0; i < l2SubMenu.length; i++) {
			l2SubMenu[i].style.display = "none";
		}
		
        eTarget.closest(".gnav20-mobile").querySelector(".gnav20-autoflow").classList.remove("gnav20-autoflow");
        eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-sub-menu").classList.add("gnav20-autoflow");
        if (eTarget.closest(".gnav20-submenu-column")) {
            eTarget.closest(".gnav20-submenu-column").classList.remove("gnav20-isactive");
			var allColumns = eTarget.closest(".gnav20-submenu-column").parentElement.children;
			for (i = 0; i < allColumns.length; i++) {
                allColumns[i].style.display = "block";
            }			
        }
        //var x = eTarget.closest(".gnav20-mobile").querySelectorAll(".gnav20-Level-2");
        var x = eTarget.closest(".gnav20-mobile").querySelectorAll("ul.gnav20-submenu-column.gnav20-L1 > li");
        eTarget.style.display="";
        //var y = eTarget.closest(".gnav20-submenu-column").querySelectorAll(".gnav20-Level-2.gnav20-sub-nav-list");
        var y = eTarget.closest(".gnav20-submenu-column").querySelectorAll("ul.gnav20-submenu-column.gnav20-L1 > li");
        for (i = 0; i < y.length; i++) {
            y[i].style.display = "block";
        }
        eTarget.closest(".gnav20-primary-menu.gnav20-current").querySelector(".gnav20-goback").style.display = "";

        for (i = 0; i < x.length; i++) {
            x[i].classList.remove("gnav20-dont-show-in-mobile");
            x[i].classList.remove("gnav20-current");
        }
        eTarget.closest(".gnav20-primary-menu").querySelector(".gnav20-goback").classList.remove("gnav20-dont-show-in-mobile");
        /*
        if(eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list") && eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback") ){
        	eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-goback").setAttribute('aria-expanded','false');
        	eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-haschild").setAttribute('aria-expanded','false');
        	eTarget.closest(".gnav20-mobile .gnav20-Level-2.gnav20-sub-nav-list").querySelector(".gnav20-subanchor.gnav20-haschild").focus();
        }
        */
        if(eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li") && eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-goback") ){
        	eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-goback").setAttribute('aria-expanded','false');
        	eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-haschild").setAttribute('aria-expanded','false');
        	eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-haschild").focus();
        }
        
        gnav20.setFocusTrap(gnav20.mobileMenu)
        
        if(event){
        	event.preventDefault();
        	event.stopPropagation();
        }
    }
}
function goBackToL3(event) {
		if(event){
    	event.preventDefault();
    	event.stopPropagation();
    }
		var eTarget = event.target || this;
		//console.log('goBackToL3',eTarget.closest(".gnav20-Level-3").querySelector(".gnav20-submenu-column.gnav20-L3"))
    //if (eTarget && eTarget.closest(".gnav20-mobile") && eTarget.closest(".gnav20-Level-3") && eTarget.closest(".gnav20-Level-3").querySelector(".gnav20-submenu-column.gnav20-L3")) {
        //eTarget.closest(".gnav20-Level-3").querySelector("ul.gnav20-submenu-column.gnav20-L3").style.display = "none";
    if (eTarget && eTarget.closest(".gnav20-mobile") && eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li") && eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li").querySelector(".gnav20-submenu-column.gnav20-L3")) {
        eTarget.closest("ul.gnav20-submenu-column.gnav20-L2 > li").querySelector("ul.gnav20-submenu-column.gnav20-L3").style.display = "none";
        //var currentElementL2 = eTarget.closest(".gnav20-Level-2.gnav20-sub-nav-list.gnav20-current");
        var currentElementL2 = eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li.gnav20-current");
    		if(currentElementL2 && currentElementL2.querySelector(".gnav20-goback")){
            currentElementL2.querySelector(".gnav20-goback").style.display="block";
            eTarget.closest(".gnav20-L2").classList.remove('gnav20-submenu-open');
        }
        //var x = eTarget.closest(".gnav20-mobile").querySelectorAll(".gnav20-Level-3");
        var x = eTarget.closest(".gnav20-mobile").querySelectorAll("ul.gnav20-submenu-column.gnav20-L2 > li");
        for (i = 0; i < x.length; i++) {
            x[i].classList.remove("gnav20-dont-show-in-mobile");
            x[i].classList.remove("gnav20-current");
        }
		/*
				var navList = document.querySelector('.gnav20 .gnav20-mobile:not(.gnav20-stacked-utility) .gnav20-navigation-list.gnav20-non-header')
				if(navList){
					navList.style.height = '222px'
					setTimeout(function(){navList.style.height = 'auto'},10)
				}
		*/
        //eTarget.closest(".gnav20-Level-2").querySelector(".gnav20-goback").classList.remove("gnav20-dont-show-in-mobile");
        eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").querySelector(".gnav20-goback").classList.remove("gnav20-dont-show-in-mobile");
        
        //var navList = eTarget.closest(".gnav20-mobile .gnav20-Level-3.gnav20-sub-nav-list")
        var navList = eTarget.closest(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L2 > li")
        /*
        if(navList && navList.querySelector(".gnav20-subanchor.gnav20-goback") ){
        	navList.querySelector(".gnav20-subanchor.gnav20-goback").setAttribute('aria-expanded','false');
        	navList.querySelector(".gnav20-subanchor.gnav20-haschild").setAttribute('aria-expanded','false');
        	navList.querySelector(".gnav20-subanchor.gnav20-haschild").focus();
        }
        */
        if(navList && navList.querySelector("a.gnav20-goback") ){
        	navList.querySelector("a.gnav20-goback").setAttribute('aria-expanded','false');
        	navList.querySelector("a.gnav20-haschild").setAttribute('aria-expanded','false');
        	navList.querySelector("a.gnav20-haschild").focus();
        }
        
        gnav20.setFocusTrap(gnav20.mobileMenu)
        
    }
}

function closeMenuL1(event,noFocus) {   
    toggleAriaHiddenGnav20("L1", !1);
    
	if(event && event.target){
		var eTarget = event.target
	}else{
		var eTarget = this
	}
    
    var	l2div = document.querySelector('.gnav20.gnav20-sticky .gnav20-sticky-content')     	
    if(l2div){l2div.removeAttribute('style')}
    
    var element = document.querySelector(".gnav20-primary-menu.gnav20-mega-drawer ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-haschild.gnav20-open")			
		if(element) {element.classList.remove('gnav20-open')}
		
		/*
	var openL1 = document.querySelectorAll(".gnav20-primary-menu.gnav20-featured-card button.gnav20-menu-label-button[aria-expanded=true]")			
	for (i = 0; i < openL1.length; i++) {
		 openL1[i].setAttribute('aria-expanded','false');
	}
    */
    var mySubMenus = document.querySelectorAll(".gnav20-desktop .gnav20-sub-menu");
    for (i = 0; i < mySubMenus.length; i++) {
        mySubMenus[i].style.display = 'none';
        mySubMenus[i].classList.remove('gnav20-grouping-active')
        mySubMenus[i].classList.remove('gnav20-mega-active')
        mySubMenus[i].querySelector('.gnav20-content-wrapper').classList.remove('gnav20-grouping-active')
        mySubMenus[i].querySelector('.gnav20-content-wrapper').classList.remove('gnav20-mega-active')
    }
	
	/*
	if(eTarget.closest(".gnav20") && eTarget.closest(".gnav20").classList.contains("stickyadded")) {
		eTarget.closest(".gnav20").classList.remove("gnav20-sticky");
		eTarget.closest(".gnav20").classList.remove("stickyadded");
	}
	*/
	
	if(document.body.classList.contains("gnav20-no-scroll") && !document.body.classList.contains("gnav20-modal-menu-open")) {
		document.body.classList.remove("gnav20-no-scroll");
	}
    
    if(window.megaColumns){
		var col = 0;
		for (i = 0; i < window.megaColumns.length; i++){
			window.megaColumns[i].classList.remove('column' + col + '-transLeft');			
			col++;
		}   	
		var myL3 = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-submenu-column.gnav20-L2")
		if(myL3){
			 for (i = 0; i < myL3.length; i++) {
				 myL3[i].style.display = 'none';
			 }
		}	
    }
    
    if(eTarget.tagName != 'BUTTON' && document.querySelector('.gnav20 .gnav20-desktop .gnav20-navigation-list button[aria-expanded=true]')){
    	eTarget = document.querySelector('.gnav20 .gnav20-desktop .gnav20-navigation-list button[aria-expanded=true]')
    }
    
    if (eTarget.closest && eTarget.closest(".gnav20-desktop") && eTarget.closest(".gnav20-primary-menu") && eTarget.closest(".gnav20-primary-menu").querySelector('.gnav20-sub-menu')) {       
      var l1Button = eTarget.closest('.gnav20-navigation-item').querySelector('[id*="-L1"]')
      if(l1Button){
      	if(eTarget.classList && eTarget.classList.contains('gnav20-nav-close')){
      		// DOPMO-195659 - needed to remove and replace the L1 trigger button due to bug in NVDA which was not reading aria-expanded attribute correctly
      		var prnt = l1Button.parentElement
	      	l1Button.remove() 
		      prnt.prepend(l1Button)            
      	}else{
	      	// DOPMO-195659 - needed to remove and replace the aria-expanded attribute  button due to bug in NVDA which was not reading aria-expanded attribute correctly
		      l1Button.blur()
		      l1Button.removeAttribute('aria-expanded') 
	      }	 
	      l1Button.setAttribute('aria-expanded', 'false') 
		  if(!noFocus){ l1Button.focus()}
      }
    }
}

function closeMenuL2(event) {
	var eTarget = event.target || this;
	//var myL2MegaDrawer = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-isactive > li > a.gnav20-subanchor");
	var myL2MegaDrawer = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-isactive > li > a");
	if(myL2MegaDrawer){
		for (i = 0; i < myL2MegaDrawer.length; i++) {
			myL2MegaDrawer[i].classList.remove('gnav20-open');
		}
		eTarget.setAttribute('aria-expanded','false');
	}	    
	    
	var myL3 = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-submenu-column.gnav20-L2, .gnav20-desktop .gnav20-featured-card .gnav20-submenu-column.gnav20-L2")
	if(myL3){
		for (i = 0; i < myL3.length; i++) {
			myL3[i].style.display = 'none';
		}
	}
	
	if(eTarget.closest(".gnav20-featured-card")){
		eTarget.classList.remove('gnav20-open');		
		eTarget.setAttribute('aria-expanded','false');
		columnHighlight2(event, true)
	}
	    
    if (eTarget.closest(".gnav20-desktop") && eTarget.querySelector('.gnav20-submenu-column.gnav20-L2')) {
        eTarget.querySelector('.gnav20-submenu-column.gnav20-L2').style.display = "none";
		//var element = eTarget.closest(".gnav20-Level-2").querySelector(".gnav20-subanchor.gnav20-haschild.gnav20-open");		
		var element = eTarget.closest("ul.gnav20-submenu-column.gnav20-L1 > li").querySelector("a.gnav20-haschild.gnav20-open");			
		if(element) {
			element.classList.remove('gnav20-open');
		}
    }
}

function closeMenuL3(event) {
	var eTarget = event.target || this;
	if(eTarget.closest(".gnav20-featured-card")){
		eTarget.classList.remove('gnav20-open');		
		eTarget.setAttribute('aria-expanded','false');
		columnHighlight2(event, true)
		
		var myL4 = document.querySelectorAll(".gnav20-desktop .gnav20-featured-card .gnav20-submenu-column.gnav20-L3")
		if(myL4){
			for (i = 0; i < myL4.length; i++) {
				myL4[i].style.display = 'none';
			}
		}
	}
	
	
	
    if (eTarget.closest(".gnav20-desktop") && eTarget.closest(".gnav20-submenu-column.gnav20-L2") && eTarget.closest(".gnav20-submenu-column.gnav20-L2").querySelector('.gnav20-submenu-column.gnav20-L3')) {
        eTarget.closest(".gnav20-submenu-column.gnav20-L2").querySelector('.gnav20-submenu-column.gnav20-L3').style.display = "none";
    }
}

function expandMenuClick(event) {
		var eTarget = event.target || this;
		var targetL1Href = eTarget.parentElement.querySelector('.gnav20-menu-label-link'); // added for ITT-640920
    if(gnav20.mouseOverL1 && document.body.classList.contains("gnav20-using-mouse") && targetL1Href && targetL1Href.getAttribute('href')){
    	var targetToOpen = eTarget.parentElement.querySelector('.gnav20-menu-label-link').getAttribute('target');
    	if(targetToOpen ==="_self" || targetToOpen ==="_blank"){
    		window.open(targetL1Href,targetToOpen);
    	}else{
    		window.open(targetL1Href, '_self');
    	}
    	
    	
    } else if (eTarget.closest(".gnav20-primary-menu").querySelector('.gnav20-sub-menu').style.display === "flex") {
        closeMenuL1(event);
    } else {
        openMenuL1(event);
    }
}

function setGnavMouseOver(event){
	if(gnav20 && event.type == 'mouseenter' && event.relatedTarget && event.relatedTarget.tagName == 'DIV'){
		gnav20.mouseOverL1 = true
	} else {
		gnav20.mouseOverL1 = false
	}
}

function megaAddSelected(event){	
	//console.log('megaAddSelected',event.type)
	if(event.type == 'mouseover' ){
		gnav20.megaL2hover = event.target;
		setTimeout('openMenuL2(event)',10)
	}else{
		gnav20.megaL2hover = null;
		openMenuL2(event)
	}
	
}

function toggleMenuL2ForMegaDrawer(event){	
	
	//console.log('toggleMenuL2ForMegaDrawer',event.target.classList)
	if(event && (event.keyCode=== 13  || event.keyCode=== 32)){
		event.preventDefault();
		if(event.target && event.target.classList.contains("gnav20-open")){
			closeMenuL2(event);
		}else {
			openMenuL2(event);
		}
	}
}

function megaGoToHref(event){	
	if(event && event.target && event.target.getAttribute('data-href') && !gnav20.megaTouch){
		location.href = event.target.getAttribute('data-href');
	}
}

function signInLinkClick(event){	
	if(document.querySelector('body.gnav20-using-mouse')){
		var signinDesktopLInk = event.target.closest('.gnav20-account-box').querySelector('.gnav20-sign-in span[data-href]:not(.gnav20-hide)');
		if(signinDesktopLInk){
			var hrefValue = signinDesktopLInk.getAttribute('data-href');
			if(hrefValue){
				location.href = hrefValue;
			}
		}		
	}
}

/* start of code for eliminating the duplicate IDs- Jira - https://onejira.verizon.com/browse/BOVV-54539*/
function removeDuplicateIDs(){
	/*
	var unusedElements = document.querySelectorAll('.gnav20 .gnav20-desktop a.gnav20-hide-on-desktop, .gnav20 .gnav20-desktop .gnav20-goback, .gnav20 .gnav20-mobile .gnav20-hide-on-mobile, .gnav20 .gnav20-mobile .gnav20-menu-label-link, #vz-gh20 #cradle-context, #vz-gf20 #gnav20-skip-to-main-content-id')
	//console.log(unusedElements.length,'unusedElements')
	for(i=0;i<unusedElements.length;i++){
		unusedElements[i].parentNode.removeChild(unusedElements[i])
	}
	*/
	// special code for Int'l biz pages and VEC which have spaces in eybrow link labels
	var eyebrows = document.querySelectorAll('.gnav20 .gnav20-eyebrow-link-list-item a')
	if(gnavdl.bu == 'smb' && /meganav/.test(gnavdl.appid) && eyebrows.length == 4){
		eyebrows[0].id = eyebrows[2].id = "gnav20-eyebrow-link-Personal"
		eyebrows[1].id = eyebrows[3].id = "gnav20-eyebrow-link-Business"
	}else{
		for(i=0;i<eyebrows.length;i++){
			eyebrows[i].id = eyebrows[i].id.replace(/[^a-zA-Z0-9-:_\.]/g,'-') || 'eyebrow_'+i
		}
	}
	
	var mobileIds = document.querySelectorAll('.gnav20 .gnav20-mobile [id]')
	for(i=0;i<mobileIds.length;i++){
		if(document.querySelector('.gnav20 .gnav20-desktop #'+mobileIds[i].id)){
			mobileIds[i].id = mobileIds[i].id + '-mobile'
			if(mobileIds[i] && mobileIds[i].classList && mobileIds[i].classList.contains('gnav20-goback')){
				mobileIds[i].id = mobileIds[i].id + '-goback'
			}
		}
	}
}
/* End of code for eliminating the duplicate Ids*/


// Start code to add attributes for toggle buttons
function customizeButtons(){
	//var butts = document.querySelectorAll('.gnav20-mobile .gnav20-subanchor.gnav20-haschild, .gnav20-desktop .gnav20-featured-card .gnav20-subanchor.gnav20-haschild')
	var butts = document.querySelectorAll('.gnav20-mobile a.gnav20-haschild, .gnav20-desktop .gnav20-featured-card a.gnav20-haschild')
	for(i=0;i<butts.length;i++){
		if(!butts[i].closest('.gnav20-featured-grouping')){
			butts[i].setAttribute('role', 'button')
			butts[i].setAttribute('href', 'javascript:void(0)')
			butts[i].setAttribute('aria-label', butts[i].innerText.trim() + ' menu list')
		}
	}
}
// End code to add attributes for toggle buttons 

//Fix for DOPMO-104434
function initializeEventListners(){	
	var drops = document.querySelectorAll('.gnav20-dropdown li.gnav20-dropdown-list');

	for (var i = 0; i < drops.length; i++) {
	    if (!drops[i].firstElementChild) {
	        drops[i].innerHTML = '<a tabindex="0">' + drops[i].innerHTML + '</a>';
	    }
	    drops[i].firstElementChild.addEventListener('focus', function () {
	        this.parentElement.classList.add('gnav20-focus-selected');
	    })
	    drops[i].firstElementChild.addEventListener('blur', function () {
	        this.parentElement.classList.remove('gnav20-focus-selected');
	    })

	}

	/* rcw commenting out for a11y 2406 ER
	var dropParents = document.querySelectorAll('.gnav20-desktop .gnav20-primary-menu:not(.gnav20-featured-card) button.gnav20-menu-label-button, .gnav20-desktop .gnav20-utility a:not(.gnav20-content-list-arrow), .gnav20-desktop .gnav20-utility [tabindex="0"]:not(.gnav20-dropdown-list-item), #gnav20-sign-id ');
	for (var i = 0; i < dropParents.length; i++) {

	    dropParents[i].addEventListener('focus', function (event) {
	    	if(document.querySelector('.gnav20 .gnav20-desktop .gnav20-sub-header-menu.gnav20-grouping-active')){
	    		closeMenuL1(event)
	    	}
	    })


	}
	*/

	var footerDefaultEle = document.querySelector('#gnav20-language-selection-footer-default')
	//close the Language Options dropdown if focus goes back to the 'default-selected' while pressing shift+tab key.
	if (footerDefaultEle) {
	    footerDefaultEle.addEventListener('focus', function () {
	    	if (!/gnav20-hide/.test(document.querySelector('.gnav20-dropdown-footer-menu').classList)) {
	    		languageFooterShowHide();
	        }
	    	
	    })
	}

	//Start Of-  closing the Language Options drop-down if focus goes out of the dropdown 
	if (footerDefaultEle) {
	    footerDefaultEle.addEventListener('blur', checklanguageFocus);
	}
	
	var gnav20LanguageSelectionItems = document.querySelectorAll(".gnav20-dropdown-footer-menu .gnav20-footer-lang .gnav20-footer-list .gnav20-language-item-footer");

	if (gnav20LanguageSelectionItems) {
	    for (var i = 0; i < gnav20LanguageSelectionItems.length; i++) {
	        gnav20LanguageSelectionItems[i].removeEventListener("blur", checkLanguageSelectionItemFooterFocus);
	        gnav20LanguageSelectionItems[i].addEventListener("blur", checkLanguageSelectionItemFooterFocus);
	    }
	}
}


/* start of  fix for CXTDT-99660 */
function skipToMainContent(){
	/*console.log('skip to main content')*/
	event.preventDefault()
	document.querySelector('#gnav20-header-end').focus()	
}

/* End of  fix for CXTDT-99660 */

function checkCloseL3(event) {
	if(this.classList.contains('gnav20-open') && !document.body.classList.contains('gnav20-using-mouse')){
		this.dispatchEvent(new Event("closeMenu",  { bubbles: true, cancelable: false }));
	} else if(this.closest('.gnav20-submenu-column') && this.closest('.gnav20-submenu-column').querySelector('.gnav20-open') && !document.body.classList.contains('gnav20-using-mouse')){
		this.closest('.gnav20-submenu-column').querySelector('.gnav20-open').dispatchEvent(new Event("closeMenu",  { bubbles: true, cancelable: false }));
		this.focus()
	}
}


gnav20.focusedMenu = 'none'

closeOpenMenu = function(){

	//console.log('this',this)

	if(document.querySelector('body.gnav20-using-mouse')){
		return;
	}

	gnav20.focusedMenu = this

	setTimeout(function(){
		//console.log('activeElement',document.activeElement)
		//console.log('activeCloseButton',gnav20.activeCloseButton)
		if(!gnav20.focusedMenu.contains(document.activeElement) && gnav20.activeCloseButton){
			//console.log('close me ' , gnav20.activeCloseButton)
			document.body.removeEventListener('click', gnav20.clickOutsideClose)
			if(/gnav20-nav-close/.test(gnav20.activeCloseButton.classList)){
				//console.log('close test L1')
				closeMenuL1(event,!0)
			}else if(/gnav20-close-account-utility/.test(gnav20.activeCloseButton.classList)){
				//console.log('close test sign in')
				gnav20.signInCloseMenu(event,!0)
			}else if(/gnav20-closex/.test(gnav20.activeCloseButton.classList)){
				gnav20.openUnifiedCart(event,!0)// this really closes the cart
			}
			gnav20.activeCloseButton = null
		}
	},100)
}


/* 

function highlightNavColumn(event) {
	var featuredCardNavColumns = document.querySelectorAll('.gnav20 .gnav20-desktop .gnav20-primary-menu.gnav20-featured-card ul.gnav20-submenu-column');
	for (var i = 0; i < featuredCardNavColumns.length; i++) { 
		featuredCardNavColumns[i].classList.remove('gnav20-column-highlight');
		if(featuredCardNavColumns[i].previousElementSibling) {
			featuredCardNavColumns[i].previousElementSibling.classList.remove('gnav20-column-highlight');
		}
	}
	if(event.target.closest(".gnav20-submenu-column")) {
		event.target.closest(".gnav20-submenu-column").classList.add('gnav20-column-highlight');
		if(event.target.closest(".gnav20-submenu-column") && event.target.closest(".gnav20-submenu-column").previousElementSibling) {
			event.target.closest(".gnav20-submenu-column").previousElementSibling.classList.add('gnav20-column-highlight');
		}
	};
	event.stopPropagation();
}
*/

gnav20.initNav = function () {
	//this is initiating some a11y stuff for 2406 start
	var myMenus = document.querySelectorAll('.gnav20-row-two .gnav20-navigation-item, .gnav20-row-two .gnav20-account-utility, .gnav20-row-two .gnav20-unifiedcart'),
		butLabel;
	for(i=0;i<myMenus.length;i++){
		if(!myMenus[i].querySelector('a.gnav20-menu-label-button')){// this is a list of row 2 divs with dropdowns: L1, signin, cart
			if(/gnav20-navigation-item/.test(myMenus[i].classList)){// this is a list of L1 divs with dropdowns
				if(myMenus[i].querySelector('.gnav20-featured-card-top-label')){
					myMenus[i].querySelector('.gnav20-featured-card-top-label').role = 'heading'
				}
				if(myMenus[i].querySelector('.gnav20-nav-mask')){
					myMenus[i].querySelector('.gnav20-nav-mask').ariaHidden = 'true'
				}
				if(myMenus[i].querySelector('.gnav20-menu-label-button') && myMenus[i].querySelector('.gnav20-nav-close')){
					butLabel = myMenus[i].querySelector('.gnav20-menu-label-button').innerText
					myMenus[i].querySelector('.gnav20-nav-close').ariaLabel = 'Close ' + butLabel + ' menu list'
				}				
			}		
			myMenus[i].addEventListener('focusout',closeOpenMenu)
		}
	}
	setTimeout(function(){
		var movers = document.querySelectorAll('.gnav20-mobile #gnav20-cclosex-mobile, .gnav20-mobile .gnav20-close-account-utility'),prnt
		for(i=0;i<movers.length;i++){ 
			prnt = movers[i].parentElement
			movers[i].remove()
			prnt.prepend(movers[i])
		}
	},100)
	//this is initiating some a11y stuff for 2406 end

	var skipToMainContentLink = document.querySelector('#gnav20-skip-to-main-content-id');
	if(skipToMainContentLink){
		skipToMainContentLink.removeEventListener("click", skipToMainContent);
	    skipToMainContentLink.addEventListener("click", skipToMainContent);
	}
    
    var mobileCartLinks = document.querySelectorAll('.gnav20 .gnav20-unified-cart .gnav20-content-list:first-child a')
    for (var i = 0; i < mobileCartLinks.length; i++) {
        mobileCartLinks[i].removeEventListener("click", gnav20.cartUtility);
        mobileCartLinks[i].addEventListener("click", gnav20.cartUtility);
        mobileCartLinks[i].href = "#"
    }
	
    var signInLink = document.querySelectorAll('.gnav20 .gnav20-utility .gnav20-sign-in:not(.gnav20-hasDropdown)')
    gnav20.personal = gnavdl.bu ? 'home wireless'.indexOf(gnavdl.bu)>-1 : true;
    if(gnav20.personal){
        for (var i = 0; i < signInLink.length; i++) {
            signInLink[i].removeEventListener("click", signInLinkClick);
            signInLink[i].addEventListener("click", signInLinkClick);
        }
    }
	
	//var featuredCardLinks = document.querySelectorAll('.gnav20 .gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) li.gnav20-sub-nav-list .gnav20-subanchor');
	var featuredCardLinks = document.querySelectorAll('.gnav20 .gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) ul.gnav20-submenu-column > li a');
	for (var i = 0; i < featuredCardLinks.length; i++) { 
		//featuredCardLinks[i].addEventListener("mouseover", highlightNavColumn);
		featuredCardLinks[i].addEventListener("focus", checkCloseL3);
	}
	
	//var megaL2WithChild = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-content-wrapper > ul > li > a.gnav20-subanchor")
	var megaL2WithChild = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-content-wrapper > ul > li > a")
    for (var i = 0; i < megaL2WithChild.length; i++) {
    	megaL2WithChild[i].addEventListener("mouseover", megaAddSelected);
    	//megaL2WithChild[i].addEventListener("mouseleave", closeMenuL2); // Added for DOPMO-99624
    	megaL2WithChild[i].addEventListener("focus", megaAddSelected);
    	megaL2WithChild[i].addEventListener("keydown", toggleMenuL2ForMegaDrawer);
    	megaL2WithChild[i].addEventListener("click", megaGoToHref);
    	megaL2WithChild[i].addEventListener("touchstart", function(){gnav20.megaTouch=true}, {passive: true});
    	megaL2WithChild[i].setAttribute('aria-expanded', 'false')
    }
    var l2Nav = document.querySelectorAll(".gnav20-desktop .gnav20-grouping ul.gnav20-L2, .gnav20-desktop .gnav20-featured-card.gnav20-featured-grouping ul.gnav20-L2");
    for (var i = 0; i < l2Nav.length; i++) {
        l2Nav[i].style.display = "block";
    }
	
	var l3Nav = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer ul.gnav20-L3");
    for (var i = 0; i < l3Nav.length; i++) {
        l3Nav[i].style.display = "block";
    }

    var linkL1DesktopWrapper = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu:not(.gnav20-featured-card)");
    // Need to add eventhandler on buttons that don't have child to closeMenuL1 on mouseover for this to work
    for (var i = 0; i < linkL1DesktopWrapper.length; i++) {
        // clickcode use condition to prevent mouseleave
        if(gnav20.bu != 'vecXXX'){
        	linkL1DesktopWrapper[i].removeEventListener("mouseleave", closeMenuL1);
        	linkL1DesktopWrapper[i].addEventListener("mouseleave", closeMenuL1);
        } 
    }
	
	
	var linkL1DesktopWrapperClose = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card .gnav20-nav-close, .gnav20-desktop .gnav20-primary-menu.gnav20-featured-card .gnav20-nav-search-icon, .gnav20-desktop .gnav20-primary-menu.gnav20-featured-card .gnav20-nav-mask");
    // Need to add eventhandler on buttons that don't have child to closeMenuL1 on mouseover for this to work
    for (var i = 0; i < linkL1DesktopWrapperClose.length; i++) {
        linkL1DesktopWrapperClose[i].removeEventListener("click", closeMenuL1);
        linkL1DesktopWrapperClose[i].addEventListener("click", closeMenuL1);
    }
	
	//var linkL1DesktopWrapperReactClose = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card .gnav20-sub-nav-list .gnav20-subanchor:not(.gnav20-haschild)");
	var linkL1DesktopWrapperReactClose = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card ul.gnav20-submenu-column > li a:not(.gnav20-haschild)");
	// Need to add eventhandler on buttons that don't have child to closeMenuL1 on mouse click.
	for (var i = 0; i < linkL1DesktopWrapperReactClose.length; i++) {
		linkL1DesktopWrapperReactClose[i].removeEventListener("click", closeMenuL1);
		linkL1DesktopWrapperReactClose[i].addEventListener("click", closeMenuL1);
	}
  
  /* This code likely obsolet and caused some problems with mega copy desktop to mobile
  var megaDrawers = document.querySelectorAll(".gnav20-desktop .gnav20-mega-drawer .gnav20-content-wrapper:first-child")
	for (i = 0; i < megaDrawers.length; i++){	
		var megaL2 = megaDrawers[i].querySelector('.gnav20-Level-2:not(.gnav20-hide-on-desktop)');
		if(megaL2) {
			var columns = megaL2.querySelectorAll('ul.gnav20-submenu-column.gnav20-L2')			
			var col = 0;
			for (ii = 0; ii < columns.length; ii++){			
				columns[ii].classList.add('column' + col + '-offRight');
				col++;			
			}		
		}
	}
	*/
    //var linkL2DesktopWrapper = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu:not(.gnav20-grouping) li.gnav20-Level-2.gnav20-sub-nav-list");
    var linkL2DesktopWrapper = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu:not(.gnav20-grouping) ul.gnav20-submenu-column.gnav20-L1 > li");
    for (var i = 0; i < linkL2DesktopWrapper.length; i++) {
				linkL2DesktopWrapper[i].removeEventListener("mouseleave", closeMenuL2);
        //linkL2DesktopWrapper[i].addEventListener("mouseleave", closeMenuL2);
    }

    var linkL3DesktopWrapper = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-grouping ul.gnav20-submenu-column.gnav20-L2 > li");
    for (var i = 0; i < linkL3DesktopWrapper.length; i++) {
        linkL3DesktopWrapper[i].removeEventListener("mouseleave", closeMenuL3);
        linkL3DesktopWrapper[i].addEventListener("mouseleave", closeMenuL3);
    }

    var linkL1Desktop = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu:not(.gnav20-featured-card) .gnav20-menu-label-button.gnav20-haschild");
    for (var i = 0; i < linkL1Desktop.length; i++) {
				if(gnav20.bu == 'vecXXX'){ // code for clickcode
					linkL1Desktop[i].removeEventListener("click", toggleMenuL1);
        	linkL1Desktop[i].addEventListener("click", toggleMenuL1);
        	linkL1Desktop[i].classList.add("gnav20-clickL1");
				}else{ // hover code
					linkL1Desktop[i].removeEventListener("mouseover", openMenuL1);
	        linkL1Desktop[i].addEventListener("mouseover", openMenuL1);
	        linkL1Desktop[i].removeEventListener("click", expandMenuClick);
	        linkL1Desktop[i].addEventListener("click", expandMenuClick);
				}
    }
	
	var linkL1Desktop = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card button.gnav20-menu-label-button.gnav20-haschild[aria-expanded~='false']");
    for (var i = 0; i < linkL1Desktop.length; i++) {
        linkL1Desktop[i].removeEventListener("click", toggleMenuL1);
        linkL1Desktop[i].addEventListener("click", toggleMenuL1);
        linkL1Desktop[i].setAttribute('aria-expanded', 'false')
    }	
    
    var gnavButtonParent = document.querySelectorAll(".gnav20-desktop .gnav20-navigation-list .gnav20-primary-menu");
		for (var i = 0; i < gnavButtonParent.length; i++) {
		    gnavButtonParent[i].addEventListener("mouseenter", setGnavMouseOver);
		    gnavButtonParent[i].addEventListener("mouseleave", setGnavMouseOver);
		}

    //var linkL2Desktop = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) li.gnav20-Level-2.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-haschild");
    var linkL2Desktop = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-haschild");
    for (var i = 0; i < linkL2Desktop.length; i++) {
		linkL2Desktop[i].removeEventListener("click", toggleMenuL2);
        linkL2Desktop[i].addEventListener("click", toggleMenuL2);
        linkL2Desktop[i].removeEventListener("closeMenu", toggleMenuL2);
        linkL2Desktop[i].addEventListener("closeMenu", toggleMenuL2);
        linkL2Desktop[i].setAttribute('aria-expanded', 'false')
    }
      
    //var linkL3Desktop = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) li.gnav20-Level-3.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-haschild");
    var linkL3Desktop = document.querySelectorAll(".gnav20-desktop .gnav20-primary-menu.gnav20-featured-card:not(.gnav20-featured-grouping) ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-haschild");
    for (var i = 0; i < linkL3Desktop.length; i++) {
        linkL3Desktop[i].removeEventListener("click", toggleMenuL3);
        linkL3Desktop[i].addEventListener("click", toggleMenuL3);
        linkL3Desktop[i].removeEventListener("closeMenu", toggleMenuL3);
        linkL3Desktop[i].addEventListener("closeMenu", toggleMenuL3);
        linkL3Desktop[i].setAttribute('aria-expanded', 'false')
    }
    
    var linkL1Mobilef = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu .gnav20-menu-label-button.gnav20-haschild");
    for (var i = 0; i < linkL1Mobilef.length; i++) {
        linkL1Mobilef[i].removeEventListener("click", openMenuL1);
        linkL1Mobilef[i].addEventListener("click", openMenuL1);
    }

    //var linkL2Mobilef = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu li.gnav20-Level-2.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-haschild");
    var linkL2Mobilef = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-haschild");
    for (var i = 0; i < linkL2Mobilef.length; i++) {
        linkL2Mobilef[i].removeEventListener("click", openMenuL2);
        linkL2Mobilef[i].addEventListener("click", openMenuL2);
    }

    //var linkL3Mobilef = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu li.gnav20-Level-3.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-haschild");
    var linkL3Mobilef = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-haschild");
    for (var i = 0; i < linkL3Mobilef.length; i++) {
        linkL3Mobilef[i].removeEventListener("click", openMenuL3);
        linkL3Mobilef[i].addEventListener("click", openMenuL3);
    }

    var linkL1Mobileb = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu .gnav20-menu-label-button.gnav20-goback");
    for (var i = 0; i < linkL1Mobileb.length; i++) {
        linkL1Mobileb[i].removeEventListener("click", goBackToL1);
        linkL1Mobileb[i].addEventListener("click", goBackToL1);
    }

    //var linkL2Mobileb = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu li.gnav20-Level-2.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-goback");
    var linkL2Mobileb = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-goback");
    for (var i = 0; i < linkL2Mobileb.length; i++) {
        linkL2Mobileb[i].removeEventListener("click", goBackToL2);
        linkL2Mobileb[i].addEventListener("click", goBackToL2);
    }
    //var linkL2ClickableMobile = document.querySelectorAll(".gnav20-mobile li.gnav20-Level-2.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-haschild");
    var linkL2ClickableMobile = document.querySelectorAll(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-haschild");
    for (var i = 0; i < linkL2ClickableMobile.length; i++) {
    	linkL2ClickableMobile[i].removeEventListener("keyup", menuL2ToggleOnSpaceKey);
    	linkL2ClickableMobile[i].addEventListener("keyup", menuL2ToggleOnSpaceKey);
    }
    //var goBackLinkL2ClickableMobile = document.querySelectorAll(".gnav20-mobile li.gnav20-Level-2.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-goback");
    var goBackLinkL2ClickableMobile = document.querySelectorAll(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-goback");
    for (var i = 0; i < goBackLinkL2ClickableMobile.length; i++) {
    	goBackLinkL2ClickableMobile[i].removeEventListener("keyup", menuL2ToggleOnSpaceKey);
    	goBackLinkL2ClickableMobile[i].addEventListener("keyup", menuL2ToggleOnSpaceKey);
    }
    //var linkL3ClickableMobile = document.querySelectorAll(".gnav20-mobile li.gnav20-Level-3.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-haschild");
    var linkL3ClickableMobile = document.querySelectorAll(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-haschild");
    for (var i = 0; i < linkL3ClickableMobile.length; i++) {
    	linkL3ClickableMobile[i].removeEventListener("keyup", menuL2ToggleOnSpaceKey);
    	linkL3ClickableMobile[i].addEventListener("keyup", menuL2ToggleOnSpaceKey);
    }
    //var goBackLinkL3ClickableMobile = document.querySelectorAll(".gnav20-mobile li.gnav20-Level-3.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-goback");
    var goBackLinkL3ClickableMobile = document.querySelectorAll(".gnav20-mobile ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-goback");
    for (var i = 0; i < goBackLinkL3ClickableMobile.length; i++) {
    	goBackLinkL3ClickableMobile[i].removeEventListener("keyup", menuL2ToggleOnSpaceKey);
    	goBackLinkL3ClickableMobile[i].addEventListener("keyup", menuL2ToggleOnSpaceKey);
    }

    //var linkL3Mobileb = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu li.gnav20-Level-3.gnav20-sub-nav-list > .gnav20-subanchor.gnav20-goback");
    var linkL3Mobileb = document.querySelectorAll(".gnav20-mobile .gnav20-primary-menu ul.gnav20-submenu-column.gnav20-L2 > li > a.gnav20-goback");
    for (var i = 0; i < linkL3Mobileb.length; i++) {
        linkL3Mobileb[i].removeEventListener("click", goBackToL3);
        linkL3Mobileb[i].addEventListener("click", goBackToL3);
    }

    var signInBackMenu = document.querySelectorAll(".gnav20-mobile #gnav20-mobile-menu .gnav20-account-box .gnav20-dropdown-menu .gnav20-goback ");
    for (var i = 0; i < signInBackMenu.length; i++) {
        signInBackMenu[i].removeEventListener("click", signinContentHide);
        signInBackMenu[i].addEventListener("click", signinContentHide);
    }

    var storesBackMenu = document.querySelectorAll(".gnav20-mobile  #gnav20-mobile-menu .gnav20-store .gnav20-dropdown-menu .gnav20-goback ");
    for (var i = 0; i < storesBackMenu.length; i++) {
        storesBackMenu[i].removeEventListener("click", storeContentHide);
        storesBackMenu[i].addEventListener("click", storeContentHide);
    }
    
    //var megaLinks = document.querySelectorAll('.gnav20-mega-drawer .gnav20-Level-2 > a.gnav20-haschild ');
    var megaLinks = document.querySelectorAll('.gnav20-mega-drawer ul.gnav20-submenu-column.gnav20-L1 > li > a.gnav20-haschild ');
		for (i = 0; i < megaLinks.length; i++){
		  	megaLinks[i].setAttribute('tabindex', '0')
		}

    // Espanol Link 
		var langEle = document.querySelectorAll('.gnav20 .gnav20-lang-link');
		for (var i = 0; i < langEle.length; i++) {
		    langEle[i].addEventListener('click', function (event) {
	        	event.preventDefault();
	        	/*if(window.gnavdl && gnavdl.variation == 'privacy' || gnavdl.appid == 'vpd'){*/
	        		gnav20.smartlingTranslation()
	        	/*}else{
	        		var newLang = location.host.indexOf('es') ? 'es' : 'en';
		        	if(!MP.switchLanguage(newLang)){
		        		console.log('MP returned false')
		          	//location.href = event.target.href
		          }
	        	} */ 	
		    });
		}
		
		// Mobile hamburger open background
		var vzhmoverlay = document.querySelector(".gnav20-vzhmoverlay");
		if(vzhmoverlay){
			vzhmoverlay.style.height = 0;
			vzhmoverlay.addEventListener('transitionstart', function() {
				this.style.height = '100%';
			});
			vzhmoverlay.addEventListener('transitionend', function() {
				if(this.className == 'gnav20-vzhmoverlay'){
					this.style.height = 0;
				}
			});
			// special condition for iOS. beforeunload not well supported. found this - https://developer.mozilla.org/en-US/docs/Web/API/Window/pagehide_event
			gnav20.vzhmoverlay = vzhmoverlay
			window.addEventListener('pagehide', function() {
				gnav20.vzhmoverlay.style.height = 0;
			});
		}
		
		// transition desktop from black to white for nav elements
		blankStuff = document.querySelectorAll('.gnav20 .gnav20-desktop .gnav20-row-one,.gnav20 .gnav20-desktop .gnav20-row-two .gnav20-navigation,.gnav20 .gnav20-desktop .gnav20-row-two .gnav20-utility')
		for (i = 0; i < blankStuff.length; i++) {
			 blankStuff[i].classList.add('opacityOne')
		}
			
    //*******************************************
    //Footer Dropdown content alignment
    var footerContent = document.querySelectorAll(".gnav20-mobile .gnav20-dropdown-menu .gnav20-dropdown");
    for (var i = 0; i < footerContent.length; i++) {
        footerContent[i].classList.add("gnav20-fixed-top", "gnav20-navigation-item");
    }
    //*******************************************       
    
    // SkinnyNav settings - start
    if(/skinnyNav=true/.test(location.search) && window.gnavdl && gnavdl.options && gnavdl.options.sticky){
			gnavdl.options.skinny = true;
		}	
		if(window.gnavdl && gnavdl.options && gnavdl.options.sticky && gnavdl.options.skinny){
			gnav20.initSkinnyNav()
		}
		// SkinnyNav settings - end
		
		
    removeDuplicateIDs();
    
    customizeButtons();
    
    initializeEventListners();  //Fix for DOPMO-104434
    
};


/*
var alinks = document.querySelectorAll('a');
for (var i = 0; i < alinks.length; i++) {
    alinks[i].setAttribute('tabindex', '0');
}
*/

var newel = document.createElement('meta');
newel.setAttribute("http-equiv", "X-UA-Compatible");
newel.content = "IE=Edge";
document.head.insertBefore(newel, document.head.firstElementChild);

function langTranslate() {
    try {
        MP.UrlLang = 'mp_js_current_lang';
        MP.SrcUrl = decodeURIComponent('mp_js_orgin_url');
        MP.oSite = decodeURIComponent('mp_js_origin_baseUrl');
        MP.tSite = decodeURIComponent('mp_js_translated_baseUrl');
        MP.init();
        var mp_langLink = function () {
            var langlinks = document.querySelectorAll('.gnav20-langLink');
            for (var i = 0; i < langlinks.length; i++) {
                langlinks.item(i).onclick = function () {
                    MP.init();
                    var lang = this.getAttribute('data-lang');
                    var url = this.getAttribute('data-href');
                    var tSite = MP.tSite.replace(/(https?:\/\/|\/?$)/g, '');
                    url = url.replace(/(https?:\/\/|\/?$)/g, '');
                    MP.switchLanguage(tSite.search(url) != -1 ? MP.oSite : url, lang, true);
                    return false;
                }
            }
        };
        if (window.addEventListener) {
            window.addEventListener('load', mp_langLink, false);
        } else if (window.attachEvent) {
            window.attachEvent('onload', mp_langLink);
        }
    }
    catch (e) {
        console.log("E in langtransalate", e);
    }
}

function switchLanguage(lang) {
    try {
        MP.SrcUrl = unescape('mp_js_orgin_url');
        MP.UrlLang = 'mp_js_current_lang';
        MP.init();
        MP.switchLanguage(MP.UrlLang == lang ? 'en' : lang); return false;
    }
    catch (e) {
        console.log("E in langtransalate", e);
    }
}



// Start Of-  closing the Quick task drop-down if focus goes out of the dropdown 

function checkQuickTaskFocus() {
    setTimeout(function () {
        if (document.activeElement.className !== 'gnav20-quick-task-item-footer' && (!/gnav20-hide/.test(document.querySelector('.gnav20-dropdown-quick-task-menu').classList))) {
            quickTaskShowHide();
        }
    }, 10)
}

function checkQuickTaskItemFooterFocus() {
    setTimeout(function () {
        if (document.activeElement.className !== 'gnav20-quick-task-item-footer' && document.activeElement.id !== 'gnav20-quick-task-menu-default') {
            quickTaskShowHide();
        }
    }, 10)
}

//End  Of-  closing the Quick task drop-down if focus goes out of the drop-down 

function quickTaskShowHide() {
    var quickTasks = document.getElementById("gnav20-quick-tasks");
    var arrowqt = document.getElementById("gnav20-arrowqt");
    var taskManuEle = document.querySelector('#gnav20-quick-task-menu-default');
    if (quickTasks) {
        quickTasks.classList.toggle("gnav20-hide");
        if (!quickTasks.classList.contains('gnav20-hide')) {
            arrowqt.classList.add('gnav20-arrow-up');
            if (taskManuEle) {
                taskManuEle.setAttribute('aria-expanded', 'true');
            }

        }
        else {
            arrowqt.classList.remove('gnav20-arrow-up');
            if (taskManuEle) {
                taskManuEle.setAttribute('aria-expanded', 'false');
            }
        }
    }
}

function expandQuickTaskMenOnKeyPress(event) {
	event.preventDefault();
    event.stopPropagation();
    var keyCode = event.which;
    if (keyCode == 13 || keyCode == 32) {
        	quickTaskShowHide(event);
         
    }
}



function checklanguageFocus() {
    setTimeout(function () {
        if (document.activeElement.className !== 'gnav20-language-item-footer' && (!/gnav20-hide/.test(document.querySelector('.gnav20-dropdown-footer-menu').classList))) {
            languageFooterShowHide();
        }
    }, 10)
}

function checkLanguageSelectionItemFooterFocus() {
    setTimeout(function () {
        if (document.activeElement.className !== 'gnav20-language-item-footer' && document.activeElement.id !== 'gnav20-language-selection-footer-default') {
            languageFooterShowHide();
        }
    }, 10)
}
//End  Of-  closing the Language Options drop-down if focus goes out of the drop-down 

function languageFooterShowHide() {
		var footerDefaultEle = document.querySelector('#gnav20-language-selection-footer-default')
		var footerEle = document.getElementById("gnav20-localization-footer");
	    var arrawEle = document.getElementById("gnav20-arrow");

	    if (footerEle) {
	        footerEle.classList.toggle("gnav20-hide");
	        if (!footerEle.classList.contains('gnav20-hide')) {
	            arrawEle.classList.add('gnav20-arrow-up');
	            if (footerDefaultEle) {
	                footerDefaultEle.setAttribute('aria-expanded', 'true');
	            }

	        } else {
	            arrawEle.classList.remove('gnav20-arrow-up');
	            if (footerDefaultEle) {
	                footerDefaultEle.setAttribute('aria-expanded', 'false');
	            }
	        }
	    }
}

// Close the dropdown menu if the user clicks outside of it

window.onclick = function (event) {
    if (!(event.target || this).matches('.gnav20-quick-task')) {
        var dropdowns = document.querySelectorAll('.gnav20-dropdown li.gnav20-footer-list');
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('gnav20-hide')) {
                openDropdown.classList.remove('gnav20-hide');
            }
        }
    }
}
window.onclick = function (event) {
    if (!(event.target || this).matches('.gnav20-language-box-footer')) {
        var dropdowns1 = document.querySelectorAll('.gnav20-dropdown li.gnav20-footer-list');

        for (var i = 0; i < dropdowns1.length; i++) {
            var openDropdown1 = dropdowns1[i];
            if (openDropdown1.classList.contains('gnav20-hide')) {
                openDropdown1.classList.remove('gnav20-hide');
            }
        }
    }
}

gnav20.initSignIn = function () {
		gnav20.mobileMenu = document.getElementById('gnav20-mobile-menu')
    var localizationforDesktop = document.querySelector('.gnav20-desktop .gnav20-localization #gnav20-language-selection-menu');
    
    if(localizationforDesktop){
    	localizationMenu = localizationforDesktop.parentElement.querySelector('.gnav20-dropdown-menu')
    	if(localizationMenu){
    		localizationMenu.addEventListener('keydown',function(){
	    		setTimeout(function(){
	    			if(!document.activeElement.closest('.gnav20-dropdown')){
	    				localizationClose()
	    			}
	    		},10)
	    	})
    	}
    }
    		
    function localizationOpen(){
        document.querySelector('.gnav20-desktop .gnav20-language-box .gnav20-dropdown-menu').classList.remove("gnav20-hide");
    }

    var languageBox = document.getElementsByClassName("gnav20-localization");
    for (var i = 0; i < languageBox.length; i++) {
        languageBox[i].removeEventListener("mouseleave", localizationClose);
        languageBox[i].addEventListener("mouseleave", localizationClose); 
    }

    function localizationClose(){
        var e = document.querySelector('.gnav20-desktop .gnav20-dropdown-menu#localization')
        if(e){
            e.classList.add("gnav20-hide");
        }
    }
    
    function localizationToggle(){
    	if(event.which == 13 || event.which == 32 ){
        if(localizationforDesktop.parentElement.querySelector('.gnav20-dropdown-menu.gnav20-hide')){
        	localizationOpen()
        }else{
        	localizationClose()
        }
      }
    }
   	
	function signInOpenMenu(event) {
        //console.log('signInOpenMenu closeCart on next line')
        gnav20.closeCart()
        var box = event.target.closest(".gnav20-account-box"),
        		container = box.querySelector(".gnav20-dropdown-menu");
        if(box && container) {
            box.querySelector(".gnav20-sign-in").setAttribute('aria-expanded','true');
            //container.setAttribute('aria-expanded','true');
            container.classList.remove("gnav20-hide");            
            if(event.target.closest(".gnav20-mobile") && box.querySelector(".gnav20-vzmoverlay") && box.querySelector(".gnav20-close-account-utility")) {
                box.querySelector(".gnav20-vzmoverlay").classList.add("gnav20-menuop");
                box.querySelector(".gnav20-close-account-utility").focus(); 
            }
            if(box.closest('.gnav20-mobile')){
            	document.body.classList.add('gnav20-modal-menu-open')
                toggleAriaHiddenGnav20("signinFromHeader", !0);  // rcw  moved to mobile only for a11y 2406 ER
                gnav20.setFocusTrap(container)// rcw  moved to mobile only for a11y 2406 ER
            }else{
            	gnav20.closeElementQuery = '#gnav20-sign-in'
            	setTimeout("document.body.addEventListener('click', gnav20.clickOutsideClose)",1)
            }
            
            gnav20.activeCloseButton = box.querySelector('.gnav20-close-account-utility')
        }        
    }
    
  gnav20.toggleMobileSignInHideEls = function(disp){  		
  	var tabby = disp == 'none' ? -1 : 0;
  	var mobileSignin = document.querySelector('#gnav20-mobile-menu .gnav20-navigation')
  	if(mobileSignin){
  		mobileSignin.style.display = disp 
  	}
    //var footerLinks = document.querySelectorAll('#gnav20-footerlink .gnav20-subanchor,#gnav20-mobile-menu .gnav20-main-header, #gnav20-sign-id-mobile, #gnav20-mobile-menu .gnav20-close-account-utility')
    // commented above to remove dependency on "gnav20-subanchor" class. may cause issues
    var footerLinks = document.querySelectorAll('#gnav20-footerlink a,#gnav20-mobile-menu .gnav20-main-header, #gnav20-sign-id-mobile, #gnav20-mobile-menu .gnav20-close-account-utility')
    for (var i = 0; i < footerLinks.length; i++) {
    	footerLinks[i].setAttribute('tabindex',tabby)
    }
    
  }
	
	function signInCloseMenu(event,noFocus) {
        //console.log('signInCloseMenu')
        var box = event
        		? event.target.closest(".gnav20-account-box")
        		: document.querySelector('.gnav20 .gnav20-desktop .gnav20-utility-wrapper:not(.gnav20-hide-on-desktop) .gnav20-account-box'),
        		btn,
        		target;
        if(box && box.querySelector(".gnav20-dropdown-menu")) {
            if(btn = box.querySelector(".gnav20-sign-in")){
                btn.remove() // DOPMO-195659 - needed to remove and replace the L1 trigger button due to bug in NVDA which was not reading aria-expanded attribute correctly
                box.prepend(btn)
                btn.setAttribute('aria-expanded','false');
            }
            //box.querySelector(".gnav20-dropdown-menu").setAttribute('aria-expanded','false');
            box.querySelector(".gnav20-dropdown-menu").classList.add("gnav20-hide");   
            gnav20.activeCloseButton = null // rcw added 2407 a11y        
            if(event && event.target.closest(".gnav20-mobile") && box.querySelector(".gnav20-vzmoverlay") && box.querySelector("#gnav20-sign-id-mobile")) {
                box.querySelector(".gnav20-vzmoverlay").classList.remove("gnav20-menuop");
                box.querySelector("#gnav20-sign-id-mobile").focus();
            }           
            if(box.closest('.gnav20-mobile')){
            	document.body.classList.remove('gnav20-modal-menu-open')
                toggleAriaHiddenGnav20("signinFromHeader", !1); //  rcw moved to mobile only 2406 ER
                gnav20.clearFocusTrap() //  rcw moved to mobile only 2406 ER
            }else{
            	document.body.removeEventListener('click', gnav20.clickOutsideClose)
            	if(event && event.target && !noFocus){ // rcw mod a11y 2406 ER
            		if(event.target.closest('.gnav20-account-box') && event.target.closest('.gnav20-account-box').querySelector('button.gnav20-hasDropdown')){
	            		event.target.closest('.gnav20-account-box').querySelector('button.gnav20-hasDropdown').focus()
	            	}
            	}            	
            }
            
        }
    }
    gnav20.signInCloseMenu = signInCloseMenu
	
    function signinToggle(event) {
    	//console.log('signinToggle')
		if(event.target.closest(".gnav20-account-box") && event.target.closest(".gnav20-account-box").querySelector(".gnav20-dropdown-menu")) {
			var accountDropDownListForDesktop = event.target.closest(".gnav20-account-box").querySelector(".gnav20-dropdown-menu");
			if(accountDropDownListForDesktop && (/gnav20-hide/.test(accountDropDownListForDesktop.classList))){
				signInOpenMenu(event);
			}else{
				signInCloseMenu(event);
			}
		}
    };

    /* rcw commented for a11y 2406 ER
    var desktopDropdownLinks = document.querySelectorAll(".gnav20-desktop .gnav20-dropdown-menu .gnav20-dropdown-list-item");

    if (desktopDropdownLinks) {
        for (var i = 0; i < desktopDropdownLinks.length; i++) {
            desktopDropdownLinks[i].removeEventListener("blur", checkDropdownFocus);
            desktopDropdownLinks[i].addEventListener("blur", checkDropdownFocus);
        }
    }
    */

    function checkDropdownFocus(event) {
        setTimeout(function () {
            if (!document.activeElement.closest('.gnav20-dropdown-menu')) {
                signInCloseMenu()
                dropdownCloseMenu(event)
            }
        },10)
    };
    
    var accountBox = document.querySelectorAll(".gnav20 .gnav20-width-wrapper:not(.gnav20-new-design) .gnav20-desktop .gnav20-account-box");
    for (var i = 0; i < accountBox.length; i++) {  
        accountBox[i].removeEventListener("mouseleave", signInCloseMenu);
        accountBox[i].addEventListener("mouseleave", signInCloseMenu);
    }
	
	var SignInElementForDesktop = document.querySelectorAll('.gnav20-width-wrapper:not(.gnav20-new-design) .gnav20-desktop .gnav20-utility  .gnav20-account-utility .gnav20-account-box .gnav20-sign-in');
			
    for (i = 0; i < SignInElementForDesktop.length; i++) {
    	SignInElementForDesktop[i].removeEventListener("mouseover", signInOpenMenu);
    	SignInElementForDesktop[i].addEventListener("mouseover", signInOpenMenu);
        
    	SignInElementForDesktop[i].removeEventListener("click", signinToggle);
    	SignInElementForDesktop[i].addEventListener("click", signinToggle);
		
		//SignInElementForDesktop[i].removeAttribute("aria-haspopup");
		
    	SignInElementForDesktop[i].addEventListener('focus', function (event) {
    		
            if (!/gnav20-hide/.test(document.querySelector('.gnav20-desktop .gnav20-dropdown-menu').classList)) {
                signInCloseMenu(event)
            }
        });
    }

     var newSignInElementForDesktop = document.querySelectorAll('.gnav20-width-wrapper .gnav20-gnav-new-design .gnav20-desktop .gnav20-utility  .gnav20-account-utility .gnav20-account-box .gnav20-sign-in.gnav20-hasDropdown');
			
    for (i = 0; i < newSignInElementForDesktop.length; i++) {
    	newSignInElementForDesktop[i].removeEventListener("click", signinToggle);
    	newSignInElementForDesktop[i].addEventListener("click", signinToggle);
		//newSignInElementForDesktop[i].removeAttribute("aria-haspopup");
    }
    
	//VCGAF-252
    var closeSignInPanel = document.querySelectorAll('.gnav20-desktop .gnav20-utility  .gnav20-account-utility .gnav20-dropdown-menu .gnav20-close-account-utility');
    for (var i = 0; i < closeSignInPanel.length; i++) {   //VCGAF-252
        closeSignInPanel[i].removeEventListener("click", signInCloseMenu);	//VCGAF-252
        closeSignInPanel[i].addEventListener("click", signInCloseMenu);		//VCGAF-252
    }

    /**********************Implementation of click anywhere to close the signin panel for VCGAF-252****************
    var areaOutSideSignInPanel = document.getElementById("gnav20-sign-id");

    document.removeEventListener('click', 
    	function(event){
			var clickedSignIn = areaOutSideSignInPanel.contains(event.target);
        	if(!clickedSignIn){
            	signInCloseMenu();
        }
    });

    document.addEventListener('click', 
    	function(event){
			var clickedSignIn = areaOutSideSignInPanel.contains(event.target);
        	if(!clickedSignIn){
            	signInCloseMenu();
        }
    });
    **********************Implementation of click anywhere to close the signin panel for VCGAF-252****************/

    if (localizationforDesktop) {
    	localizationforDesktop.setAttribute("tabindex", "0");
    	
    	localizationforDesktop.removeEventListener("mouseover", localizationOpen);
        localizationforDesktop.addEventListener("mouseover", localizationOpen);
        
      localizationforDesktop.removeEventListener("keydown", localizationToggle);
        localizationforDesktop.addEventListener("keydown", localizationToggle);
    }
    
	var signInElementMobile = document.querySelectorAll(".gnav20-mobile .gnav20-account-box .gnav20-account-box .gnav20-sign-in");
    for (i = 0; i < signInElementMobile.length; i++) {
    	signInElementMobile[i].removeEventListener("click", signinToggle)
        signInElementMobile[i].addEventListener("click", signinToggle);
    }
    
    var signInElementMobileFooterlink = document.querySelectorAll(".gnav20-mobile #gnav20-footerlink .gnav20-sign-in"),
    		ariaLabel;
    for (i = 0; i < signInElementMobileFooterlink.length; i++) {
    	signInElementMobileFooterlink[i].removeEventListener("click", signinToggleForMobile)
      signInElementMobileFooterlink[i].addEventListener("click", signinToggleForMobile);
      ariaLabel = signInElementMobileFooterlink[i].querySelector('span>span')
	     if(ariaLabel){
	     	ariaLabel = ariaLabel.innerText.trim() + ' menu list'
	     	signInElementMobileFooterlink[i].setAttribute('aria-label',ariaLabel)
	     }
    }
	
	var signInElementOption1A = document.querySelectorAll(".gnav20-mobile .gnav20-utility .gnav20-account-box .gnav20-sign-in");
    for (i = 0; i < signInElementOption1A.length; i++) {
        signInElementOption1A[i].removeEventListener("click", signInOpenMenu)
        signInElementOption1A[i].addEventListener("click", signInOpenMenu);
    }
	
	var signInElementOption1AClose = document.querySelectorAll(".gnav20-mobile .gnav20-utility .gnav20-account-box .gnav20-close-account-utility");    
    for (i = 0; i < signInElementOption1AClose.length; i++) { 
        signInElementOption1AClose[i].removeEventListener("click", signInCloseMenu)
        signInElementOption1AClose[i].addEventListener("click", signInCloseMenu);
    }
    
    var signInElementOption1ACloseMenu = document.querySelectorAll(".gnav20-mobile .gnav20-utility .gnav20-account-box .gnav20-vzmoverlay");
    for (i = 0; i < signInElementOption1ACloseMenu.length; i++) {  
        signInElementOption1ACloseMenu[i].removeEventListener("click", signInCloseMenu)
        signInElementOption1ACloseMenu[i].addEventListener("click", signInCloseMenu);
    }
	
	
	function dropdownOpenMenu(event) {
		var myTarget = (event.target || this)
		if(myTarget.closest(".gnav20-dropdown-box") && myTarget.closest(".gnav20-dropdown-box").querySelector(".gnav20-dropdown-menu")) {
			myTarget.closest(".gnav20-dropdown-box").querySelector(".gnav20-dropdown-menu").classList.remove("gnav20-hide");
			myTarget.setAttribute('aria-expanded','true');		
		}
		if(myTarget.closest('.gnav20-mobile')){
			gnav20.toggleMobileSignInHideEls('none')      
  		    gnav20.setFocusTrap(gnav20.mobileMenu)
		}
  };

	function dropdownCloseMenu(event) {
		var myTarget = (event.target || this),
				parent = myTarget.closest('.gnav20-dropdown-box')
		if(parent && parent.querySelector(".gnav20-dropdown-menu") && parent.querySelector("button")){
			parent.querySelector(".gnav20-dropdown-menu").classList.add("gnav20-hide");
			parent.querySelector("button").setAttribute('aria-expanded','false');	
		}
		if(myTarget.closest('.gnav20-mobile')){
			myTarget.closest('.gnav20-dropdown-box').querySelector("button").setAttribute('aria-expanded','false');	
			gnav20.toggleMobileSignInHideEls('block')
			gnav20.clearFocusTrap(gnav20.mobileMenu)
		}
  };
  
  function dropdownToggleForDesktop(event) {
  	if(event.target.nextElementSibling.classList.contains('gnav20-hide')){
  		dropdownOpenMenu(event)
  	}else{
  		dropdownCloseMenu(event)
  	}
  }
	
	function dropdownToggleForMobile(event) {
      var myTarget = (event.target || this)
      if(myTarget.closest(".gnav20-dropdown-box") && myTarget.closest(".gnav20-dropdown-box").querySelector(".gnav20-dropdown-menu") 
			&& (/gnav20-hide/.test(myTarget.closest(".gnav20-dropdown-box").querySelector(".gnav20-dropdown-menu").classList))){
        	dropdownOpenMenu(event);
        }else{
        	dropdownCloseMenu(event);
        }
    };
	
	var dropdownElementsForDesktop = document.querySelectorAll('.gnav20-desktop .gnav20-utility .gnav20-dropdown-box button');
  var dropdownElementsForMobile = document.querySelectorAll(".gnav20-mobile .gnav20-mobile-menu .gnav20-dropdown-box button");
	
	for (var i = 0; i < dropdownElementsForDesktop.length; i++) {
		
		dropdownElementsForDesktop[i].removeEventListener("mouseover", dropdownOpenMenu);
    	dropdownElementsForDesktop[i].addEventListener("mouseover", dropdownOpenMenu);
		
        dropdownElementsForDesktop[i].closest(".gnav20-dropdown-box").removeEventListener("mouseleave", dropdownCloseMenu);
        dropdownElementsForDesktop[i].closest(".gnav20-dropdown-box").addEventListener("mouseleave", dropdownCloseMenu);
        
        dropdownElementsForDesktop[i].removeEventListener("click", dropdownToggleForDesktop);
    	dropdownElementsForDesktop[i].addEventListener("click", dropdownToggleForDesktop);
  }
    
	
	for (var i = 0; i < dropdownElementsForMobile.length; i++) {
		
		dropdownElementsForMobile[i].removeEventListener("click", dropdownToggleForMobile)
        dropdownElementsForMobile[i].addEventListener("click", dropdownToggleForMobile);
		
	}
	
};








var googleSearchInitialized = false;
var autocomplete;

function handleStoreLocatorFocus(e) {
	loadGoogleScript()
}

function mobilecheck() {
	var check = false;
	(function (a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true; })(navigator.userAgent || navigator.vendor || window.opera);
	return check;
}

function loadGoogleScript() {
	if (!window.google || !window.google.maps) {
		var channel = mobilecheck() ? 'mobile' : 'desktop';
		var gglScript = document.createElement('script');
		gglScript.type = 'text/javascript';
		gglScript.rel = 'stylesheet';
		gglScript.async = 'true';
		gglScript.src = 'https://maps.googleapis.com/maps/api/js?client=gme-verizonwireless2&channel=vzw-' + channel + '&libraries=places&callback=initGoogleSearch';
		(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(gglScript);
		//console.log('loaded googlemaps script')
	} else if (!googleSearchInitialized) {
		initGoogleSearch()
	}
}

function initGoogleSearch() {
	googleSearchInitialized = true;
	var input = document.getElementById('gnav20-google-search-input');
	//var infowindowContent = document.getElementById('gnav20-google-search-content');
	autocomplete = new google.maps.places.Autocomplete(input);
	autocomplete.setComponentRestrictions({ 'country': ['us'] });
	autocomplete.setTypes(['geocode'])
	autocomplete.addListener('place_changed', function () {
		var place = autocomplete.getPlace();
		if (!place.geometry) {
			return;
		}
		if (navigator.userAgent.search("Firefox") >= 0) {
			var sourceUrl = window.location.href;
			history.pushState({}, '', sourceUrl);
		}
		var lat = place.geometry.location.lat() ? place.geometry.location.lat().toFixed(6) : '';
		var lng = place.geometry.location.lng() ? place.geometry.location.lng().toFixed(6) : '';
		location.href = "https://www.verizonwireless.com/stores/storesearchresults/?allow=1&lat=" + lat + "&long=" + lng + "&result=all&q=" + encodeURI(place.formatted_address);
	});
}

gnav20.initGnavMenu = function () {
	function toggleMenu() {
		//console.log('toggleMenu')
		if(event == gnav20.hamburgerClickEvent){
  		return false;
  	}
  	
  	document.getElementById('gnav20-mobile-menu').classList.remove('gnav20-openL1')
  	
  	gnav20.hamburgerClickEvent = event;
		var menuEle = document.querySelector("#gnav20-mobile-menu.gnav20-mobile-menu")
		if (menuEle) {
			menuEle.classList.toggle('gnav20-open-menu');
			menuEle.classList.toggle("gnav20-hide");
		}
		
		if(menuEle.classList.contains('gnav20-open-menu')){	// Toggle Open
			gnav20.setFocusTrap(menuEle)
			toggleAriaHiddenGnav20("hamburger", !0);
			gnav20.activeCloseButton = document.querySelector('#gnav20-mobile-menu .gnav20-closex')
		}else{																							// Toggle closed
			gnav20.clearFocusTrap()
			toggleAriaHiddenGnav20("hamburger", !1);
		}
		
		var overlayEle = document.querySelector(".gnav20-vzhmoverlay");
		var x = document.getElementsByTagName("body");
		for (var i = 0; i < x.length; i++) {
			x[0].classList.toggle('gnav20-modal-menu-open');
		}
		if (overlayEle) {
			overlayEle.classList.toggle('gnav20-menuop');
			mobilelabelposition();
		}
		var closeEle = document.querySelector("#gnav20-mobile-menu #gnav20-closex.gnav20-closex")
		if (closeEle) {
			closeEle.focus();
		}
		
		var localizaEle = document.querySelector(".gnav20-mobile #gnav20-footerlink .gnav20-localization")
		if (localizaEle && localizaEle.classList.contains("gnav20-hide")) {
				localizaEle.classList.remove("gnav20-hide");
		}
		if (document.getElementsByClassName("gnav20-non-header").length) {
			document.querySelector(".gnav20 .gnav20-mobile .gnav20-navigation-list.gnav20-non-header").classList.remove("gnav20-non-header");
			var selectedLOB = document.querySelector(".gnav20 .gnav20-mobile .gnav20-eyebrow-link-list-item a.gnav20-main-header.gnav20-selected")
			if(selectedLOB){
				selectedLOB.style.display = "block"
			}
		}
	}


	//suresh
	function toggleLocal() {
		var element = document.querySelector(".gnav20-mobile .gnav20-language-box .gnav20-dropdown-menu");
		var overlayEle = document.querySelector(".gnav20-vzhmoverlay");
		if (element) {
			if(!element.closest('#gnav20-footerlink')){
				overlayEle.classList.toggle('gnav20-menuop')
			}
			if (element.classList.contains('gnav20-hide')) {
				element.classList.add("gnav20-open-menu");
				element.classList.remove("gnav20-hide");

			}
			else {
				element.classList.remove("gnav20-open-menu");
				element.classList.add("gnav20-hide");
			}
		}
	}

	var e = document.querySelector(".gnav20-mobile #gnav20-closex3.gnav20-closex")
	if (e) {
		e.removeEventListener('click', toggleLocal);
		e.addEventListener('click', toggleLocal);
	}

	var e = document.querySelector(".gnav20-mobile #gnav20-language-selection-menu")
	if (e) {
		e.removeEventListener('click', toggleLocal);
		e.addEventListener('click', toggleLocal);
	}
	//suresh 
	
	
	// account icon guy code for mobile menu
	var iconGuy = document.querySelector('.gnav20-mobile .gnav20-account-icon')
	if(iconGuy){
		iconGuy.removeEventListener('click', gotoAccount);
		iconGuy.addEventListener('click', gotoAccount);
	}
	function gotoAccount(){
		toggleMenu()
		var accountLink = document.querySelector('.gnav20-mobile .gnav20-primary-menu:not(.gnav20-hide) #gnav20-Account-L1-mobile') || document.querySelector('.gnav20-mobile .gnav20-primary-menu:not(.gnav20-hide) #gnav20-Account-L1');
		var closeIcon = document.querySelector('#gnav20-mobile-menu #gnav20-closex');
		
		if(accountLink){
			accountLink.click()
		}
		if(closeIcon){
			closeIcon.focus()
		}
	}


	//Mobile Menu outside click
	document.body.addEventListener("click", function (event) {
		if ((event.target || this).classList.contains("gnav20-menuop") || (event.target || this).classList.contains("gnav20-contactus")) {
			closeMenu(event);
			if ((event.target || this).classList.contains("gnav20-contactus") && (event.target || this).id) {
				var url = window.location.href;
				window.location.href = url + '/#' + (event.target || this).id
			}
		}
		//close L1 menu on click outside of main nav
		if(event.target && !event.target.closest('.gnav20-mobile') && !event.target.closest('.gnav20-global-nav-list') && !event.target.closest('.gnav20-utility') && document.querySelector('.gnav20 .gnav20-desktop .gnav20-sub-header-menu.gnav20-grouping-active')) {
			closeMenuL1(event);
		}
		// close mobile menu on click of href. some href do not reload page
		if(event.target && event.target.href && event.target.closest('.gnav20-mobile-menu') && document.getElementById('gnav20-closex')){
			document.getElementById('gnav20-closex').click();
		}
		
		if(event.target && event.target.href && event.target.closest('.gnav20-account-utility') && event.target.closest('.gnav20-account-utility').querySelector('.gnav20-close-account-utility')){
			event.target.closest('.gnav20-account-utility').querySelector('.gnav20-close-account-utility').click();
		}
	});

	function closeMenu(event) {
		toggleMenu();
		setTimeout(function () {
			signinContentHide();
			storeContentHide();
			MenuContentBack();
			languageContentHide();
		}, 500);


		var element = document.querySelectorAll(".gnav20-mobile .gnav20-visibilty-hidden");
		for (var i = 0; i < element.length; i++) {
			element[i].classList.remove("gnav20-visibilty-hidden");
		}
		var navEle = document.querySelector("#gnav20-nav-toggle")
		if (navEle) {
			setTimeout(function () {
				navEle.focus();
			}, 1000);
		}
		
		event.preventDefault();
	}

	// cart close for MObile 
	function closeMCart() {
		var element = document.querySelector(".gnav20-unifiedcart #gnav20-mySidenav");
		if (element) {
			element.classList.add("gnav20-hide");
		}
	}


	var togglEle = document.querySelector("#gnav20-nav-toggle")
	if (togglEle) {
		togglEle.removeEventListener('click', toggleMenu);
		togglEle.addEventListener('click', toggleMenu);
	}
	var closeEle = document.querySelector("#gnav20-closex.gnav20-closex")
	if (closeEle) {
		closeEle.removeEventListener('click', closeMenu);
		closeEle.addEventListener('click', closeMenu);
	}





	var cCloseEle = document.querySelector("#gnav20-cclosex.ganv20-closex")
	if (cCloseEle) {
		cCloseEle.removeEventListener('click', closeMCart);
		cCloseEle.addEventListener('click', closeMCart);
	}


	
	
};


gnav20.initUnifiedCart = function() {
    var unifiedCartSvg = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart, .gnav20-unified-cart .gnav20-closex')
    for (var i = 0; i < unifiedCartSvg.length; i++) {
        unifiedCartSvg[i].removeEventListener('click', openUnifiedCart);
        unifiedCartSvg[i].addEventListener("click", openUnifiedCart);
    }

    function openUnifiedCart(event, noFocus) {
        if (event == gnav20.cartClickEvent) {
            return false;
        }
        var signInPanel = document.querySelector('.gnav20-account-box .gnav20-dropdown-menu:not(.gnav20-hide)')
        if (signInPanel) {
            gnav20.signInCloseMenu()
        }
        gnav20.cartClickEvent = event;
        if (event) {
            var unifiedCart = event.target.closest('.gnav20-unifiedcart').querySelector('.gnav20-unified-cart')
            var closeButtonOnCart = event.target.closest('.gnav20-unifiedcart').querySelector('.gnav20-closex')
            var selcartBackDrop = document.querySelector(".gnav20-tablet-back-drop");
            var cartIcon = event.target.parentElement.closest('.gnav20-unifiedcart').querySelector('.gnav20-cart')
            var isMobile = event.target.closest('.gnav20-mobile')
            var isDesktopOverlay = event.target.closest('.gnav20-desktop')
            var flyoutEnabled = document.querySelector(".gnav20-unified-cart").classList.contains('gnav20-flyout-cart-enabled');
        } else {
            var unifiedCart = document.querySelector('.gnav20-desktop .gnav20-unified-cart')
            var closeButtonOnCart = unifiedCart.querySelector('.gnav20-closex')
            var cartIcon = unifiedCart.parentElement.querySelector('.gnav20-cart')
        }

        if (selcartBackDrop) {
            cartBackDrop = event.target.closest(".gnav20-utility").querySelector(".gnav20-tablet-back-drop");
            cartBackDrop.classList.remove('gnav20-hide');
        }
        if (unifiedCart) {
            if (unifiedCart.classList.contains("gnav20-hide")) { //Open cart	        
                gnav20.activeCloseButton = unifiedCart.querySelector('.gnav20-closex')
                unifiedCart.classList.remove("gnav20-hide");
                if (closeButtonOnCart && isMobile) {
                    closeButtonOnCart.focus();
                }
                if (cartIcon) {
                    cartIcon.setAttribute('aria-expanded', 'true');
                }
                if (unifiedCart.closest('.gnav20-unifiedcart').querySelector(".gnav20-vzmoverlay")) {
                    unifiedCart.closest('.gnav20-unifiedcart').querySelector(".gnav20-vzmoverlay").classList.add('gnav20-menuop');
                }
                if (isDesktopOverlay) {
					var flyoutEnabledOverlay = document.querySelector('.gnav20-flyout-cart-enabled');
				  if(flyoutEnabledOverlay){
                   document.querySelector(".gnav20-vzmoverlay").classList.add("gnav20-desktopOverlay")
					}
                }
                if (isMobile) {
                    document.body.classList.add('gnav20-modal-menu-open')
                    gnav20.closeElementQuery = '#gnav20-my-side-nav-mobile'
                    toggleAriaHiddenGnav20("cart", !0); // rcw moved to mobile only for a11y 2406 ER
                    gnav20.setFocusTrap(unifiedCart) //rcw moved to mobile only for a11y 2406 ER
                } else {
                    gnav20.closeElementQuery = '#gnav20-my-side-nav'
                }

                var cartToast = unifiedCart.classList.contains('gnav20-cart-toast');
                var flyoutSuccess = unifiedCart.classList.contains('gnav20-unified-flyout-success');
                var pdpFlyoutCart = cartIcon.classList.contains('gnav20-cart-icon-flyout');
                if (flyoutEnabled && !cartToast && flyoutSuccess) {
                    if (pdpFlyoutCart) {
						var unifiedCartFlyoutPdp = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart');
							for (var i = 0; i < unifiedCartFlyoutPdp.length; i++) {
								if(unifiedCartFlyoutPdp[i].checkVisibility()) {
									var flyoutFrame = document.createElement("iframe");
										flyoutFrame.setAttribute("class", "gnav20-cart-flyout");
										flyoutFrame.setAttribute("src", "/nextgendigital/sales/browse/flyoutcart/pdp");
										unifiedCartFlyoutPdp[i].closest('.gnav20-unifiedcart').querySelector('.gnav20-unified-cart').append(flyoutFrame);
									var loader = document.createElement("div");
										loader.setAttribute("class", "flyout-overlay");
									var loaderPos = unifiedCartFlyoutPdp[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-flyout-cart-enabled");
										loaderPos.insertBefore(loader,loaderPos.children[2]);
										unifiedCartFlyoutPdp[i].closest('.gnav20-unifiedcart').querySelector(".flyout-overlay").innerHTML = "<div id='load-indicator'></div>";
									gnav20.removeLoader();
									unifiedCartFlyoutPdp[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart-content-title").innerHTML = "<div class='gnav20-cart-title-success' id ='gnav20-cart-title-wrapper'><div class='gnav20-cart-title-successIcon'></div><div class='gnav20-cart-title-successMessage' id='gnav20-cart-success-title-flyout'>Added to your cart</div></div>";
								}
							}
                        document.querySelector("#gnav20-cclosex").setAttribute("data-track", "global nav: PDP flyout close shopping cart");
                    } else {
						var unifiedCartFlyoutGnav = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart');
							for (var i = 0; i < unifiedCartFlyoutGnav.length; i++) {
								if(unifiedCartFlyoutGnav[i].checkVisibility()) {
									if(unifiedCartFlyoutGnav[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart-title-success")){
									unifiedCartFlyoutGnav[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart-title-success").remove();
									}
									unifiedCartFlyoutGnav[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart-content-title").innerText = "Your cart";
									gnav20.flyoutCartGnav();
								}
							}
                        document.querySelector("#gnav20-cclosex").setAttribute("data-track", "global nav:flyout close shopping cart");
                        window.coreData = window.coreData || [];
                        window.coreData.push({
                            task: "emit",
                            event: "openView",
                            params: {
                                selector: ".gnav20-unified-cart",
                                name: "global nav:Flyout cart menu Global Nav"
                            }
                        });
                        document.querySelector("#gnav20-cclosex").setAttribute("data-track", "global nav:flyout close shopping cart");
                    }
                } else {
                    window.coreData = window.coreData || [];
                    window.coreData.push({
                        task: "emit",
                        event: "openView",
                        params: {
                            selector: ".gnav20-unified-cart",
                            name: "global nav:cart menu"
                        }
                    });
                }

                if (!isMobile) {
                    var desktopOverlay = document.querySelector(".gnav20-desktopOverlay");
                    desktopOverlay.addEventListener('click', function() {
                        gnav20.closeCart();
                    })
                }

                setTimeout("document.body.addEventListener('click', gnav20.clickOutsideClose)", 1)


            } else { // Close cart

                if (cartIcon) {
                    cartIcon.setAttribute('aria-expanded', 'false')
                    if (!noFocus) {
                        cartIcon.focus()
                    } // rcw a11y 2406 ER 
					var flyoutEnabled = document.querySelector('.gnav20-flyout-cart-enabled');
					if (flyoutEnabled) {
						document.querySelector("#gnav20-cart-icon").classList.remove("gnav20-cart-icon-flyout");
					}
                }
                unifiedCart.classList.add("gnav20-hide");
                if (unifiedCart.closest('.gnav20-unifiedcart').querySelector(".gnav20-vzmoverlay")) {
                    unifiedCart.closest('.gnav20-unifiedcart').querySelector(".gnav20-vzmoverlay").classList.remove('gnav20-menuop');
                }
                if (flyoutEnabled) {
                    document.querySelector("#gnav20-cart-icon").classList.remove("gnav20-cart-icon-flyout");
                    document.querySelector(".gnav20-vzmoverlay").classList.remove("gnav20-desktopOverlay");
                    if (document.querySelectorAll(".gnav20-flyout-cart-enabled iframe").length > 0) {
                        document.querySelector(".gnav20-flyout-cart-enabled iframe").remove();
                    }
                }
                gnav20.activeCloseButton = null // rcw added 2407 a11y

                if (selcartBackDrop) {
                    cartBackDrop = event.target.closest(".gnav20-utility").querySelector(".gnav20-tablet-back-drop");
                    cartBackDrop.classList.add('gnav20-hide');
                }

                document.body.removeEventListener('click', gnav20.clickOutsideClose)
                document.body.classList.remove('gnav20-modal-menu-open')
                if (isMobile) {
                    toggleAriaHiddenGnav20("cart", !1); // rcw moved to mobile only for a11y 2406 ER
                    gnav20.clearFocusTrap() // rcw moved to mobile only for a11y 2406 ER
                }

            }
        }
    }
    gnav20.openUnifiedCart = openUnifiedCart
}

gnav20.closeCart = function() {
    var cartPanel = document.getElementById('gnav20-my-side-nav'),
        cartButt = document.getElementById('gnav20-cclosex')
    if (cartPanel && cartButt && !cartPanel.classList.contains('gnav20-hide')) {
        cartButt.click()
    }
	var flyoutEnabled = document.querySelector('.gnav20-flyout-cart-enabled');
	 if (flyoutEnabled) {
		document.querySelector("#gnav20-cart-icon").classList.remove("gnav20-cart-icon-flyout");
	 }
}


//Show smb cart icon
/*
gnav20.showSMBBubble = function() {
	var cartCount = "";
	if (gnav20.getCookie('SMB_PROSPECT_CARTQTY')) {
		cartCount = parseInt(gnav20.getCookie('SMB_PROSPECT_CARTQTY'));
	}

	if (cartCount > 0 || gnav20.getCookie('prospectFlowType')) {
		var gnavCart = document.getElementsByClassName("gnav20-cart-wrapper");
		for (i = 0; i < gnavCart.length; i++) {
			gnavCart[i].classList.remove("gnav20-hide");
		}
		
		var cartBubble = document.getElementsByClassName("gnav20-cart-bubble");
		for (i = 0; i < cartBubble.length; i++) {
			cartBubble[i].style.display = 'block';
		}
	}
};
*/
//NEW Show smb cart icon - VBG38665-157
gnav20.showSMBBubble = function() {
    var vbgCartCookies = ["vbmlqresult", "prospectCartId", "SMB_PROSPECT_CARTQTY"],
        cookieVal, gnavCart, cartBubble

    for (ii = 0; ii < vbgCartCookies.length; ii++) {

        cookieVal = gnav20.getCookie(vbgCartCookies[ii])

        if (cookieVal && parseInt(cookieVal) != 0) {

            gnavCart = document.getElementsByClassName("gnav20-cart-wrapper");
            for (i = 0; i < gnavCart.length; i++) {
                gnavCart[i].classList.remove("gnav20-hide");
                gnavCart[i].style.display = 'block';
            }

            cartBubble = document.getElementsByClassName("gnav20-cart-bubble");
            for (i = 0; i < cartBubble.length; i++) {
                cartBubble[i].style.display = 'block';
            }

            break;
        }
    }
}

var btnEle = document.querySelector('.gnav20-custom-modal-btn');
var closeBtnEle = document.querySelector('.gnav20-custom-modal-close-btn')
if (btnEle) {
    btnEle.removeEventListener('click', openContactUsModal);
    btnEle.addEventListener('click', openContactUsModal);
}

if (closeBtnEle) {
    closeBtnEle.removeEventListener('click', closeContactUsModal);
    closeBtnEle.addEventListener('click', closeContactUsModal);
}

var modalEle = document.querySelector('.gnav20-modal')
function openContactUsModal(event) {

    if (modalEle) {
        modalEle.style.display = "block";
        modalEle.setAttribute('aria-hidden', 'false');
        modalEle.setAttribute('tabindex', '0');
        closeBtnEle.focus();
				gnav20.setFocusTrap(modalEle)
        
        event.preventDefault();
        event.stopPropagation();

    }
}

function closeContactUsModal(event) {
    if (modalEle) {
        modalEle.style.display = "none";
        modalEle.setAttribute('aria-hidden', 'true');
        modalEle.setAttribute('tabindex', '-1');
        gnav20.clearFocusTrap()
        event.preventDefault();
        event.stopPropagation();
    }
}


function downFunction() {
    document.body.scrollTop = 1750;
    document.documentElement.scrollTop = 1750;
}

/* Accessibility code for toggling the aria hidden true/false on click of modal overlay .
 * This will restrict screen reader to read the background content, when a modal overlay is opened
 * */
function toggleAriaHiddenGnav20(overlay,bool,timer){
	
	//console.log('toggleAriaHiddenGnav20',overlay,bool,timer)// rcw added changes to this func for a11y 2406 ER
	
	if(!timer){
		gnav20.togOverlay = overlay
		gnav20.togBool = bool
		setTimeout("toggleAriaHiddenGnav20(gnav20.togOverlay,gnav20.togBool,true)",100)
		return
	}
	/*  commented 11/5/21 
	if(overlay == 'L1'){
		gnav20.toggleZindex(bool)
	}
	*/
	var toggleNodesGnav = {
		hamburger: ['.gnav20-header-accessibility','.gnav20-ribbontext','.gnav20-logo','.gnav20-utility','#vz-gf20'],
		cart: ['.gnav20-header-accessibility','.gnav20-ribbontext','.gnav20-row-one','.gnav20-logo','.gnav20-navigation','.gnav20-account-utility','.gnav20-search-utility','.gnav20-mobile .gnav20-wishlist','.gnav20-mobile #gnav20-nav-toggle','#gnav20-mobile-menu.gnav20-mobile-menu','#vz-gf20'],
		signin: ['.gnav20-header-accessibility','.gnav20-ribbontext','.gnav20-row-one','.gnav20-logo','.gnav20-navigation','.gnav20-mobile .gnav20-utility','.gnav20-mobile-menu #gnav20-footerlink .gnav20-store','.gnav20-mobile-menu #gnav20-footerlink .gnav20-localization'],
		signinFromHeader: ['.gnav20-header-accessibility','.gnav20-ribbontext','.gnav20-row-one','.gnav20-logo','.gnav20-navigation','.gnav20-search-utility','.gnav20-unifiedcart','.gnav20-mobile .gnav20-wishlist','.gnav20-mobile .gnav20-unifiedcart','.gnav20-mobile #gnav20-nav-toggle','.gnav20-mobile-menu #gnav20-footerlink .gnav20-store','.gnav20-mobile-menu #gnav20-footerlink .gnav20-localization'],
		search: ['.gnav20-header-accessibility','.gnav20-ribbontext','.gnav20-row-one','.gnav20-logo','.gnav20-navigation','.gnav20-account-utility','.gnav20-mobile .gnav20-search-icon','.gnav20-desktop .gnav20-unifiedcart','.gnav20-mobile .gnav20-unifiedcart','.gnav20-cart','.gnav20-mobile .gnav20-wishlist','.gnav20-mobile #gnav20-nav-toggle','.gnav20-mobile-menu','#vz-gf20'],
		languageChange: ['.gnav20-header-accessibility','.gnav20-ribbontext','.gnav20-logo','.gnav20-mobile .gnav20-utility .gnav20-search-utility','.gnav20-mobile .gnav20-utility .gnav20-language-box #gnav20-language-selection-menu','.gnav20-mobile .gnav20-utility #gnav20-nav-toggle','.gnav20-mobile .gnav20-mobile-menu'],
		modal: ['.gnav20-header-accessibility','.gnav20-promo-text','.gnav20-apicomponentnolayout','.gnav20-mobile .gnav20-utility #gnav20-nav-toggle','#vz-gf20'],
		L1: ['.gnav20-promo-text', '.gnav20-row-two .gnav20-utility','#gnav20-header-end'] //'.gnav20-header-accessibility','.gnav20-row-one','.gnav20-logo',
	}
	
	var toggleNodesDOM = document.querySelectorAll('body > span:not(:empty), body > div:not(:empty), body > section:not(:empty), body > header:not(:empty), body > footer:not(:empty)'),
		x;
			
	if(/responsivegrid/.test(toggleNodesDOM[0].classList)){
		//console.log('responsivegrid')
		toggleNodesDOM = document.querySelectorAll('main, #vz-gf20')
	}
	
	for(i=0; i<toggleNodesDOM.length; i++) {
			x = toggleNodesDOM[i]
			//console.log(x)
			if(x.children && x.children.length && !x.querySelector('.gnav20-desktop')){
					//console.log('toggle this one')
				x.setAttribute('aria-hidden',bool)		
				// BELOW is a hack to fix a bug in JAWS where links inside aria-hidden parent are announced if they have title or aria-label
				xl = x.querySelectorAll("a[aria-label], a[data-aria-label], a[title], a[data-title")
					for(iii=0;iii<xl.length;iii++){
						//console.log('aria-label',xl[iii].getAttribute('aria-label'))
						//console.log('data-aria-label',xl[iii].getAttribute('data-aria-label'))
						if(xl[iii].hasAttribute('aria-label') || xl[iii].hasAttribute('data-aria-label')){
							if(bool){
								xl[iii].setAttribute('data-aria-label',xl[iii].getAttribute('aria-label'));
								xl[iii].removeAttribute('aria-label')
							}else{	
								xl[iii].setAttribute('aria-label',xl[iii].getAttribute('data-aria-label'));
							}
						}
						if(xl[iii].hasAttribute('title') || xl[iii].hasAttribute('data-title')){
							if(bool){
								xl[iii].setAttribute('data-aria-label',xl[iii].getAttribute('title'));
								xl[iii].removeAttribute('title')
							}else{	
								xl[iii].setAttribute('title',xl[iii].getAttribute('data-title'));
							}
						}
						
					}
			}
	}
	
	if(toggleNodesGnav[overlay]){
		for(i=0; i<toggleNodesGnav[overlay].length; i++) {
			//console.log(overlay)
			x = document.querySelectorAll(toggleNodesGnav[overlay][i])
			for(ii=0; ii<x.length; ii++) {
				//console.log('--x =',x)
					x[ii].setAttribute('aria-hidden',bool);
					xl = x[ii].querySelectorAll("a[aria-label], a[data-aria-label]")
					for(iii=0;iii<xl.length;iii++){
						//console.log('aria-label',xl[iii].getAttribute('aria-label'))
						//console.log('data-aria-label',xl[iii].getAttribute('data-aria-label'))
						if(bool){
							xl[iii].setAttribute('data-aria-label',xl[iii].getAttribute('aria-label'));
							xl[iii].removeAttribute('aria-label')
						}else{	
							xl[iii].setAttribute('aria-label',xl[iii].getAttribute('data-aria-label'));
						}
						
					}
				//console.log(ii,toggleNodesGnav[overlay][i],x[ii])
			}
		}
	}
}
gnav20.initLOB = function () {
		function lobOpenMenu(event) {
			if ((event.target || this).closest('.gnav20-sub-lob-box') && (event.target || this).closest('.gnav20-sub-lob-box').querySelector('.gnav20-dropdown-menu')) {
				(event.target || this).setAttribute('aria-expanded', 'true');
				(event.target || this).closest('.gnav20-sub-lob-box').querySelector('.gnav20-dropdown-menu').classList.remove("gnav20-hide");
				(event.target || this).closest('.gnav20-sub-lob-box').querySelector('.gnav20-dropdown-menu').setAttribute('aria-expanded', 'true');
			}
		};

		function lobCloseMenu(event) {
			if ((event.target || this).closest(".gnav20-desktop") && (event.target || this).closest(".gnav20-desktop").querySelector('.gnav20-sub-lob-box') &&
				(event.target || this).closest(".gnav20-desktop").querySelector('.gnav20-sub-lob-box').querySelector('.gnav20-dropdown-menu') &&
				(event.target || this).closest(".gnav20-desktop").querySelector('.gnav20-sub-lob-box').querySelector('.gnav20-sub-lob')) {
				(event.target || this).closest(".gnav20-desktop").querySelector('.gnav20-sub-lob-box').querySelector('.gnav20-dropdown-menu').classList.add("gnav20-hide");
				(event.target || this).closest(".gnav20-desktop").querySelector('.gnav20-sub-lob-box').querySelector('.gnav20-dropdown-menu').setAttribute('aria-expanded', 'false');
				(event.target || this).closest(".gnav20-desktop").querySelector('.gnav20-sub-lob-box').querySelector('.gnav20-sub-lob').setAttribute('aria-expanded', 'false');
			}
		};

	function expandLOBOnKeyPress(event) {
		event.preventDefault();
        event.stopPropagation();
        var keyCode = event.which;
        if (keyCode == 13 || keyCode == 32 || keyCode == 1) {
            if ((event.target || this).nextElementSibling.classList.contains("gnav20-hide")) {
                lobOpenMenu(event);
            } else {
                lobCloseMenu(event);
            }
        }
    };
	
	function lobToggle() {		
		var lobBox = document.querySelector(".gnav20-mobile .gnav20-sub-lob-box .gnav20-dropdown-menu");
		if (lobBox.classList.contains("gnav20-hide")) {
			lobBox.classList.remove("gnav20-hide");
		}
		var lobLink = document.querySelector(".gnav20-mobile .gnav20-sub-lob-box .gnav20-sub-lob");
		if (!lobLink.classList.contains("gnav20-hide")) {
			lobLink.classList.add("gnav20-hide");
		}
	}
	
	function setBusinessUnitSelection(event) {
		if(event.target.innerText && /business|personal/.test(event.target.innerText.toLowerCase())) {
			var bu = /personal/.test(event.target.innerText.toLowerCase())
					? "personal"
					: "business"
			gnav20.setCookie("VZ_ATLAS_SITE_PERS","BusinessUnit=" + bu, 365);
		}		
	}
    
    var lobBox = document.querySelector(".gnav20-desktop .gnav20-sub-lob-box");
    if (lobBox) {
        lobBox.removeEventListener("mouseleave", lobCloseMenu);
        lobBox.addEventListener("mouseleave", lobCloseMenu);
    }
    var lobElement = document.querySelector(".gnav20-desktop .gnav20-sub-lob-box .gnav20-sub-lob");
    if (lobElement) {        
        lobElement.removeEventListener("mouseover", lobOpenMenu);
        lobElement.addEventListener("mouseover", lobOpenMenu);
		
		lobElement.removeEventListener("keypress", expandLOBOnKeyPress);
        lobElement.addEventListener("keypress", expandLOBOnKeyPress);

        // click event for Screen readers like NVDA , JAWS
        lobElement.removeEventListener("click", expandLOBOnKeyPress);
        lobElement.addEventListener("click", expandLOBOnKeyPress);
		
		var navList = document.querySelector(".gnav20-mobile .gnav20-navigation-list");
		if(navList) {
			var link = document.createElement('a');
			link.classList.add("gnav20-lob-link");
			if(document.getElementById("gnav20-lob-link-label")) {
				link.innerText = document.getElementById("gnav20-lob-link-label").value;
			}
			navList.appendChild(link);
			
			link.addEventListener("click", lobToggle);
		}
    }	
	
	var eybrowLinks = document.querySelectorAll(".gnav20-eyebrow-link-list-item > a");
	for (i=0; i < eybrowLinks.length; i++){
		eybrowLinks[i].removeEventListener("click", setBusinessUnitSelection);   
        eybrowLinks[i].addEventListener("click", setBusinessUnitSelection);    
    }
	
	// Start Of-  closing the Sub-lob-menu drop-down if focus goes out of the dropdown 
	if (lobElement) {
		lobElement.addEventListener('blur', checkSubLobMenuFocus);
	}


	function checkSubLobMenuFocus(event) {
	    setTimeout(function () {
	        if (!document.activeElement.classList.contains("gnav20-dropdown-list-item") && (!/gnav20-hide/.test(document.querySelector('.gnav20-desktop .gnav20-sub-lob-box .gnav20-dropdown-menu').classList))) {
	        	lobCloseMenu(event);
	        }
	    }, 10)
	}
	var subLobMenuItems = document.querySelectorAll(".gnav20-desktop .gnav20-sub-lob-box .gnav20-dropdown .gnav20-dropdown-list .gnav20-dropdown-list-item");

	if (subLobMenuItems != null) {
	    for (var i = 0; i < subLobMenuItems.length; i++) {
	    	subLobMenuItems[i].removeEventListener("blur", checksubLobMenuItemsFocus);
	    	subLobMenuItems[i].addEventListener("blur", checksubLobMenuItemsFocus);
	    	
	    }
	}

	function checksubLobMenuItemsFocus(event) {
	    setTimeout(function () {
	        if (!document.activeElement.classList.contains("gnav20-dropdown-list-item")) {
	        	lobCloseMenu(event);
	        }
	    }, 10)
	}

	//End  Of-  closing the Sub-lob-menu drop-down if focus goes out of the drop-down 


};








//****function to return hostname - const in rls branch ********//
gnav20.getScriptOrigin = function(){
    try{
        var cs = document.querySelector('script[src*="/vzwcom/gnav20"]');
        if(cs){
			return cs.src.substr(0,cs.src.indexOf('/etc'));
        }        
    }
    catch(err){
        //just catching it
    }
    return "https://www.verizon.com";
};

gnav20.initGnavFooter = function() {
	

	var langLink = document.querySelector("#gnav20-language-selection-menu");
	var qtLink = document.querySelector("#gnav20-quick-task-selection-menu");
	if (langLink) {
		langLink.removeEventListener('click', languageFooterShowHide);
		langLink.addEventListener('click', languageFooterShowHide);
	}
	if (qtLink) {
		qtLink.removeEventListener('click', quickTaskShowHide);
		qtLink.addEventListener('click', quickTaskShowHide);
		
		qtLink.removeEventListener('keypress', expandQuickTaskMenOnKeyPress);
		qtLink.addEventListener('keypress', expandQuickTaskMenOnKeyPress);
	}
	
	var quickTaskMenuElements = document.querySelector('#gnav20-quick-task-menu-default');

	// close the Quick task dropdown if focus goes back to the 'default-selected' while pressing shift+tab key.
	if (quickTaskMenuElements) {
		quickTaskMenuElements.addEventListener('focus', function () {
	        if (!/gnav20-hide/.test(document.querySelector('.gnav20-dropdown-quick-task-menu').classList)) {
	            quickTaskShowHide();
	        }
	    })
	}
	if (quickTaskMenuElements) {
		quickTaskMenuElements.removeEventListener('blur', checkQuickTaskFocus);
		quickTaskMenuElements.addEventListener('blur', checkQuickTaskFocus);
	}
	
	var quickTaskItems = document.querySelectorAll(".gnav20-dropdown-quick-task-menu .gnav20-dropdown .gnav20-footer-list .gnav20-quick-task-item-footer");

	if (quickTaskItems) {
	    for (var i = 0; i < quickTaskItems.length; i++) {
	        quickTaskItems[i].removeEventListener("blur", checkQuickTaskItemFooterFocus);
	        quickTaskItems[i].addEventListener("blur", checkQuickTaskItemFooterFocus);
	    }
	}
	//Added check to bypass personalization logic in author env
	 if(!gnav20.getCookie("wcmmode")){
    		gnav20.initPersona();
     }
    /*Mobile Accordion for GNAV footer code - START

	var footerContainerParent= document.querySelector(".gnav20-footer-container");
	var accordionElements = document.querySelectorAll(".gnav20-herofooter .gnav20-hero-footer-heading");
	var innerViewPort = window.innerWidth;
	var outerViewPort = window.outerWidth;
	var zoom = (outerViewPort/innerViewPort)*100;  
    
	if(footerContainerParent && footerContainerParent.classList.contains('gnav20-mobile-footer-accordion')){
		for ( var loopCounter = 0; loopCounter < accordionElements.length; loopCounter++) {
			accordionElements[loopCounter].addEventListener("click", handleAccordion);
			accordionElements[loopCounter].addEventListener("keydown", handleAccordionOnKeyPress);
		  
			if(innerViewPort <= 767.5 || zoom >= 200){
				accordionElements[loopCounter].setAttribute("aria-label",accordionElements[loopCounter].innerText+" menu list");
				accordionElements[loopCounter].setAttribute("tabindex","0");
				accordionElements[loopCounter].setAttribute("aria-expanded","false");
				accordionElements[loopCounter].setAttribute("role","button");
				accordionElements[loopCounter].nextElementSibling.setAttribute("aria-hidden","true");
			}
			else{
				accordionElements[loopCounter].setAttribute("aria-label",accordionElements[loopCounter].innerText+" menu list");				
			}			
		}
	}
	*/
	
	// remove the temp styles defined in the footer HTML
	//document.getElementById('gnav20-preload') && document.getElementById('gnav20-preload').remove()
	
	gnav20.footerContainer = document.getElementById('vz-gf20')
	if(gnav20.footerContainer){
		gnav20.mobileAccordion = function(){
			if(window.innerWidth < 768 && !gnav20.footerContainer.querySelector('.gnav20-hero-footer-heading[tabindex]')){
				var accordionElements = gnav20.footerContainer.querySelectorAll(".gnav20-herofooter .gnav20-hero-footer-heading")
				for ( var loopCounter = 0; loopCounter < accordionElements.length; loopCounter++) {
					accordionElements[loopCounter].addEventListener("click", handleAccordion);
					accordionElements[loopCounter].addEventListener("keydown", handleAccordionOnKeyPress);
					accordionElements[loopCounter].setAttribute("aria-label",accordionElements[loopCounter].innerText+" menu list");
					accordionElements[loopCounter].setAttribute("tabindex","0");
					accordionElements[loopCounter].setAttribute("aria-expanded","false");
					accordionElements[loopCounter].setAttribute("role","button");
					//accordionElements[loopCounter].nextElementSibling.setAttribute("aria-hidden","true");
					accordionElements[loopCounter].nextElementSibling.classList.add('gnav20-accordion-list')
				}
				if(event && event.target && (event.target.nodeType === 1) && event.target.closest('.gnav20-main-container') && event.target.closest('.gnav20-main-container').querySelector('.gnav20-hero-footer-heading')){
					event.target.closest('.gnav20-main-container').querySelector('.gnav20-hero-footer-heading').focus()
				}
			}
		}
		gnav20.footerContainer.addEventListener('keyup',gnav20.mobileAccordion)
		gnav20.mobileAccordion()
		
		// remove contentinfo role if footer is inside a footer HTNML element
	  var foot = document.querySelector('.gnav20 div[role=contentinfo]')
	  if(foot && foot.closest('footer')){
	  	foot.removeAttribute('role')
	  }
	  // call smbFooterData defined in smb.js
	  window.smbFooterData && smbFooterData()
	}
	
	
	
	/* Copyright update code */

	/*if(document.getElementById("copyright-year"))
		document.getElementById("copyright-year").innerHTML = new Date().getFullYear();*/
		
		
		if(!document.querySelectorAll('#vz-gf20 a[data-track]').length){
			var evnt = new Event('gnavReady');
			document.dispatchEvent(evnt);
			console.log('dispatch gnavReady after footer')
		}

};

	function handleAccordion() {		
		gnav20.toggleElementHeight()
	}
	function handleAccordionOnKeyPress(){
	    var key = event.keyCode;
	    if( key == 13 || key == 32){
				gnav20.toggleElementHeight()
	    }
	}

	gnav20.toggleElementHeight = function(){
		if(!event.target.nextElementSibling){
			return
		}
		var maxCount = 100,
			heightIncrement = 10,
			timeInterval = 5;

		if(event.target.nextElementSibling.style.display == 'block'){
			closeMe(event.target)
		}else{
			openMe(event.target)
		}

		function closeMe(target){
			var el = target.nextElementSibling,
				counter = 0,
				newHeight,
				heightInterval;
            
			target.classList.remove("gnav20-accordion-open");
			target.setAttribute('aria-expanded',false)

			heightInterval = setInterval(function(){
				var parseHeight = parseInt(el.style.height)
				/*console.log('closing',parseInt(el.style.height))*/
				if(parseHeight > 0 && counter < maxCount){
					newHeight = parseHeight < heightIncrement ? 0 : (parseHeight - heightIncrement);
					el.style.height = newHeight + 'px';
					counter++;
				}else{
					el.removeAttribute('style')
					clearTimeout(heightInterval)
				}
			},timeInterval)
		}

		function closeOthers(){
			var footerHeadings = document.querySelectorAll('.gnav20-herofooter .gnav20-hero-footer-heading')
			for(var loopCounter=0; loopCounter<footerHeadings.length; loopCounter++){
				/*console.log('closeOthers',footerHeadings[loopCounter].nextElementSibling.style.display)*/
				if(footerHeadings[loopCounter].nextElementSibling.style.display == 'block'){
					closeMe(footerHeadings[loopCounter])
				}
			}
		}

		function openMe(target){
			closeOthers()

			var el = target.nextElementSibling, counter = 0, newHeight, heightInterval;

			target.classList.add('gnav20-accordion-open')			
			target.setAttribute('aria-expanded',true)
			el.style.display = 'block';
			el.style.height = '0px';

			heightInterval = setInterval(function(){
				var parseHeight = parseInt(el.style.height)
				/*console.log('opening',parseHeight,el.scrollHeight,el.firstElementChild.offsetHeight)*/
				if(parseHeight < el.scrollHeight && counter < maxCount){
					newHeight = (parseHeight + heightIncrement) > el.scrollHeight ? el.scrollHeight : (parseHeight + heightIncrement);
					el.style.height = newHeight + 'px';

					counter++
				}else{
					clearTimeout(heightInterval)
				}
			},timeInterval)
		}
	}
	/*Mobile Accordion for GNAV footer code - END */
	
	
gnav20.checkEscapeKey = function(event) {
  if(event.keyCode == 27 && gnav20.activeCloseButton){
  	gnav20.activeCloseButton.click()
  }
}

gnav20.brOffersCaptureResponse = function(response, dispositionOptionId) {
    var xhttp = new XMLHttpRequest();
    var url = gnav20.getScriptOrigin() + "/soe/digital/auth/personalizationrecommendationsservice/pdm/brOffersCaptureResponse";
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
        }
    }
    var data = JSON.stringify({
        "source": "brOffersCaptureResponse",
        "clientId": (response.clientId ? response.clientId : 'MVO'),
        "mtn": "",
        "accountNo": "",
        "customerResponse": {
            "responseList": [
                {
                    "rank": "1",
                    "propositionId": (response.promoRibbon[0].propositionId ? response.promoRibbon[0].propositionId : ''),
                    "dispositionOptionId": dispositionOptionId,
                    "soiEngagementId": (response.promoRibbon[0].soiEngagementId ? response.promoRibbon[0].soiEngagementId : ''),
                    "tacticLocation": (response.contextInfo.pageContext ? response.contextInfo.pageContext : ''),
                    "ctaReference": "",
                    "timeStamp": (response.timestamp ? response.timestamp : '')
                }
            ]
        },
        "contextInfo": {
            "callReason": "GlobalNav",
            "category": "PromoRibbon",
            "subServiceName": "CaptureResponse",
            "pageContext": (response.contextInfo.pageContext ? response.contextInfo.pageContext : ''),
            "sessionId": (response.sessionid ? response.sessionid : '')
        }
    });
    xhttp.open("POST", url, true);
    xhttp.setRequestHeader("Channelid", "VZW-DOTCOM");
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(data);
}

gnav20.OffersCaptureResponse = function(msg,response,dispositionOptionId) {
    var gnbrCradle = '';
    if(response && response.throttleList && response.throttleList.includes("gn_br_t")) {
        gnbrCradle = "gn_br_t";
    } else if(response && response.throttleList && response.throttleList.includes("gn_br_c")) {
        gnbrCradle = "gn_br_c";
    }
    var pageContext = '';
    if(response && response.pageContext) {
        pageContext = response.pageContext;
    }
    if(dispositionOptionId == 82) {
        var impression = "L0|P1|||" + (response.promoRibbon[0].soiEngagementId ? response.promoRibbon[0].soiEngagementId : '') +
                "|" + (response.promoRibbon[0].propositionId ? response.promoRibbon[0].propositionId : '') +
                "|82|gnav ribbon_" + (response.promoRibbon[0].cardId ? response.promoRibbon[0].cardId : '' ) +
                (gnbrCradle ? "_" + gnbrCradle : "") + (pageContext ? "_" + pageContext : "");

        var impressionJSON = { "list" : impression };


        window.coreData = window.coreData || [];
        window.coreData.push({
            task : "emit",
            event : "cradleTestList",
            params : {
                id : gnbrCradle,
                strategy : (response.strategyIdentifier ? response.strategyIdentifier : ''),
                last2: (response.accountLast2 ? response.accountLast2 : '')
            }
        });
        window.coreData.push({
            task : "emit",
            event : "impression",
            params : impressionJSON
        });

        var promoCTAs = document.querySelectorAll("#gnav20-promo-placeholder .gnav20-promo a");
        for(i=0; i<promoCTAs.length; i++){
            var impressionCTA = impression + "|gnav ribbon_" + promoCTAs[i].innerText;
            impressionCTA = impressionCTA.replace("|82|","|81|");
            promoCTAs[i].setAttribute("data-track", JSON.stringify({
                "type": "impression",
                "name": impressionCTA
            }));
            gnav20.offerResponse = response;
            promoCTAs[i].addEventListener('click', function(response) {
                gnav20.brOffersCaptureResponse(gnav20.offerResponse,81);
            });

        }
        gnav20.brOffersCaptureResponse(response, dispositionOptionId);
    } else {
        var impression = "L0|P1|||||82|gnav ribbon_default_" + msg +
                (gnbrCradle ? "_" + gnbrCradle : "") + (pageContext ? "_" + pageContext : "");

        var impressionJSON = { "list" : impression };
        if(gnbrCradle.length > 0) {
            window.coreData = window.coreData || [];
            window.coreData.push({
                task : "emit",
                event : "cradleTestList",
                params : {
                    id : gnbrCradle,
                    strategy : '',
                    last2: ''
                }
            });
            window.coreData.push({
                task : "emit",
                event : "impression",
                params : impressionJSON
            });
        }
        var promoCTAs = document.querySelectorAll("#gnav20-promo-placeholder .gnav20-promo a");
        for(i=0; i<promoCTAs.length; i++){
            var impressionCTA = impression + "|gnav ribbon_" + promoCTAs[i].innerText;
            impressionCTA = impressionCTA.replace("|82|","|81|");
            promoCTAs[i].setAttribute("data-track", JSON.stringify({
                "type": "impression",
                "name": impressionCTA
            }));
        }
    }
}

gnav20.copyNav = function() {
  var	mobileHeaderComp = window.getComputedStyle(gnav20.mobileHeader)
  if(gnav20.currentNav == 'desktop' && mobileHeaderComp.getPropertyValue('display') == 'block'){
  	gnav20.mobileNav.innerHTML = gnav20.desktopNav.innerHTML
  	setTimeout(function(){
  		gnav20.initNav();
  		// Need to remove desktop styles like on learn K12 where we have aligned colums
  		var aligned = document.querySelectorAll(".gnav20 .gnav20-mobile .gnav20-content-wrapper[style]")
			for(i=0; i<aligned.length; i++){
				aligned[i].style = null
			}
			//need to open and close menu to arrange mega for mobile
  		var closex = document.getElementById('gnav20-closex')
  		if(closex){
  			closex.click();closex.click();
  		}
  	},10)
  	window.removeEventListener('resize', gnav20.copyNavTimeout)
  }else if(gnav20.currentNav == 'mobile' && mobileHeaderComp.getPropertyValue('display') == 'none'){
  	gnav20.desktopNav.innerHTML = gnav20.mobileNav.innerHTML
  	setTimeout('gnav20.initNav()',10)
  	window.removeEventListener('resize', gnav20.copyNavTimeout)
  }
  //console.log('--copyNav',new Date().getTime())
}
gnav20.resizeNav = null;
gnav20.copyNavTimeout = function(){
	clearTimeout(gnav20.resizeNav);
	gnav20.resizeNav = setTimeout(gnav20.copyNav, 250);
	//console.log(new Date().getTime())
}

gnav20.loadProspectPersonalizedRibbon = function() {
    var xhttp = new XMLHttpRequest();
    var url = gnav20.getScriptOrigin() + "/content/caas/gNavRibbon.model.isActive:true.json";
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            try {
                var promoResponse = JSON.parse(this.responseText);
                var ribbonMapping = Object.values(promoResponse.ribbonMapping);
                var fullPath = window.location.pathname;
                var searchString = window.location.search;
                var pathString = '';
                var ribbonObj;
                for(var i=0; i<ribbonMapping.length; i++) {
                    if(ribbonMapping[i].pageUrl) {
                        var regex = "^" + ribbonMapping[i].pageUrl;
                        if(!ribbonMapping[i].pageUrl.includes("*")) {
                            regex = regex + "$";
                        }
                        if(fullPath.match(new RegExp(regex)) && ribbonMapping[i].pageUrl.replace("*","").length >= pathString.length) {
                            if(ribbonObj != null && ribbonMapping[i].pageUrl.includes("*")) {
                                break;
                            }
                            if(((!ribbonMapping[i].queryParam) || ( ribbonMapping[i].queryParam && ribbonMapping[i].queryParam.length == 0))){
                                ribbonObj = ribbonMapping[i];
                                pathString = ribbonObj.pageUrl.replace("*","");
                            }
                            if(ribbonMapping[i].queryParam && searchString.length > 0 && searchString.slice(1).split("&").includes(ribbonMapping[i].queryParam)) {
                                ribbonObj = ribbonMapping[i];
                                pathString = ribbonObj.pageUrl.replace("*","") + ribbonObj.queryParam;
                            }

                        }
                    }
                }
                if(ribbonObj && ribbonObj.isHidden) {
                    document.getElementById("gnav20-promo-placeholder").innerHTML = "";
                    if(document.querySelector(".gnav20-sticky-header")) {
                        document.querySelector(".gnav20-sticky-header").classList.remove("gnav20-with-promo");
                    }
                    //break;
                }
                if(ribbonObj) {
                    if (promoResponse.ribbonContent[ribbonObj.contentFragmentId].isModal) {
                        var promostring = "<div class='gnav20-promo-text gnav20-white-focus' " +
                        "auto-load='" + (promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalAutoLoad ? 'yes' : 'no') +"'><span>" + (promoResponse.ribbonContent[ribbonObj.contentFragmentId].ribbonText ? promoResponse.ribbonContent[ribbonObj.contentFragmentId].ribbonText : '')  +
                        "<span>&nbsp;|&nbsp;</span><span class='gnav20-promo-icon'>" +
                        "<a role='button' href='javascript:void(0);' aria-label='" + promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalLinkAriaLabel + "'>" + (promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalLinkText ? promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalLinkText : 'Offer Details') + "</a></span></span>";

                        if(promoResponse.ribbonContent[ribbonObj.contentFragmentId].expirationTime) {
                            var date = new Date(promoResponse.ribbonContent[ribbonObj.contentFragmentId].expirationTime);
                            var timestamp = date.getFullYear() + "-" + date.getMonth() + "-" + date.getDate() + " 23:59:59";
                            promostring += "<span class='gnav20-promo-timer' timestamp='" + timestamp + "'></span>";
                        }
                        promostring += "</div>";

                        promostring += "<div class='gnav20-modal-content-placeholder' style='display:none;'>";
                        if(promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalHeading) {
                            promostring += "<h2 class='gnav20-modal-heading' id='gnav20-modal-heading'>" +
                                    promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalHeading + "</h2>";
                        }
                        if(promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalSubHeading) {
                            promostring += "<div class='gnav20-modal-sub-heading' id='gnav20-modal-sub-heading'>" + promoResponse.ribbonContent[ribbonObj.contentFragmentId].modalSubHeading + "</div>";
                        }
                        promostring += "<div class='gnav20-modal-cta'>";

                        if(promoResponse.ribbonContent[ribbonObj.contentFragmentId].primaryCTALabel) {
                            promostring += "<span class='gnav20-modal-primary-cta'>" +
                            "<a href='" + promoResponse.ribbonContent[ribbonObj.contentFragmentId].primaryCTALink + "' " +
                            "aria-label='" + promoResponse.ribbonContent[ribbonObj.contentFragmentId].primaryCTAAriaLabel + "'>" +
                            promoResponse.ribbonContent[ribbonObj.contentFragmentId].primaryCTALabel + "</a></span>";
                        }
                        if(promoResponse.ribbonContent[ribbonObj.contentFragmentId].secondaryCTALabel) {
                            promostring += "<span class='gnav20-modal-secondary-cta'>" +
                            "<a href='" + promoResponse.ribbonContent[ribbonObj.contentFragmentId].secondaryCTALink + "' " +
                            "aria-label='" + promoResponse.ribbonContent[ribbonObj.contentFragmentId].secondaryCTAAriaLabel + "'>" +
                            promoResponse.ribbonContent[ribbonObj.contentFragmentId].secondaryCTALabel + "</a></span>";
                        }

                        promostring += "</div></div>";

                        document.querySelector(".gnav20-promo-ribbon").innerHTML = promostring;
                    } else {
                        var promostring = "<div class='gnav20-promo-text gnav20-white-focus'>" + "<span>" + (promoResponse.ribbonContent[ribbonObj.contentFragmentId].ribbonText ? promoResponse.ribbonContent[ribbonObj.contentFragmentId].ribbonText : '') + "</span>";
                        if(promoResponse.ribbonContent[ribbonObj.contentFragmentId].expirationTime) {
                            var date = new Date(promoResponse.ribbonContent[ribbonObj.contentFragmentId].expirationTime);
                            var timestamp = date.getFullYear() + "-" + date.getMonth() + "-" + date.getDate() + " 23:59:59";
                            promostring += "<span class='gnav20-promo-timer' timestamp='" + timestamp + "'></span>";
                        }
                        promostring += "</div>";
                        document.querySelector(".gnav20-promo-ribbon").innerHTML = promostring;
                    }
                }
                //break;
            } catch (error) {
                console.log(error);
            }
            if(document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext")) {
                document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
                gnav20.initPromo();
            }
        }
    };
    xhttp.open("GET", url, true);
    xhttp.send();
}

gnav20.loadAuthPersonalizedRibbon = function(pContext) {
    var xhttp = new XMLHttpRequest();
    var url = gnav20.getScriptOrigin() + "/soe/digital/auth/personalizationrecommendationsservice/pdm/blackRibbon";
    xhttp.onload = function () {
        try {
            var promoResponse = JSON.parse(this.responseText);
            if(promoResponse.response && promoResponse.response.promoRibbon && promoResponse.response.promoRibbon.length > 0 && promoResponse.response.promoRibbon[0].aemNode) {
                if (promoResponse.response.promoRibbon[0].aemNode.isModal && promoResponse.response.promoRibbon[0].aemNode.isModal == 'true') {
                    var promostring = "<div class='gnav20-promo-text gnav20-white-focus'" +
                    "auto-load='" + (promoResponse.response.promoRibbon[0].aemNode.modalAutoLoad ? 'yes' : 'no') + "'><span>" + (promoResponse.response.promoRibbon[0].aemNode.eyebrowCopy ? promoResponse.response.promoRibbon[0].aemNode.eyebrowCopy : '')  +
                    "<span>&nbsp;|&nbsp;</span><span class='gnav20-promo-icon'>" +
                    "<a href='javascript:void(0);' aria-label='" + promoResponse.response.promoRibbon[0].aemNode.accessibilityText + "'>" + (promoResponse.response.promoRibbon[0].aemNode.primaryCTALabelCopy ? promoResponse.response.promoRibbon[0].aemNode.primaryCTALabelCopy : 'Offer Details') + "</a></span></span>";

                    if(promoResponse.response.promoRibbon[0].aemNode.expirationTime) {
                        var date = new Date(promoResponse.response.promoRibbon[0].aemNode.expirationTime);
                        var timestamp = date.getFullYear() + "-" + date.getMonth() + "-" + date.getDate() + " 23:59:59";
                        promostring += "<span class='gnav20-promo-timer' timestamp='" + timestamp + "'></span>";
                    }

                    promostring += "</div>";

                    promostring += "<div class='gnav20-modal-content-placeholder' style='display:none;'>";
                    if(promoResponse.response.promoRibbon[0].aemNode.modalHeadlineCopy) {
                        promostring += "<h2 class='gnav20-modal-heading' id='gnav20-modal-heading'>" +
                                promoResponse.response.promoRibbon[0].aemNode.modalHeadlineCopy + "</h2>";
                    }
                    if(promoResponse.response.promoRibbon[0].aemNode.modalSubheadCopy) {
                        promostring += "<div class='gnav20-modal-sub-heading' id='gnav20-modal-sub-heading'>" + promoResponse.response.promoRibbon[0].aemNode.modalSubheadCopy + "</div>";
                    }
                    promostring += "<div class='gnav20-modal-cta'>";

                    if(promoResponse.response.promoRibbon[0].aemNode.modalPrimaryCTALabel) {
                        promostring += "<span class='gnav20-modal-primary-cta'>" +
                        "<a href='" + promoResponse.response.promoRibbon[0].aemNode.modalPrimaryCTADestinationURLWeb + "' " +
                        "aria-label='" + promoResponse.response.promoRibbon[0].aemNode.modalAccessibilityText1 + "'>" +
                        promoResponse.response.promoRibbon[0].aemNode.modalPrimaryCTALabel + "</a></span>";
                    }
                    if(promoResponse.response.promoRibbon[0].aemNode.modalSecondaryCTALabel) {
                        promostring += "<span class='gnav20-modal-secondary-cta'>" +
                        "<a href='" + promoResponse.response.promoRibbon[0].aemNode.modalSecondaryCTADestinationURLWeb + "' " +
                        "aria-label='" + promoResponse.response.promoRibbon[0].aemNode.modalAccessibilityText2 + "'>" +
                        promoResponse.response.promoRibbon[0].aemNode.modalSecondaryCTALabel + "</a></span>";
                    }

                    promostring += "</div></div>";

                    document.querySelector(".gnav20-promo-ribbon").innerHTML = promostring;
                } else {
                    var promostring = "<div class='gnav20-promo-text gnav20-white-focus'>" + "<span>" + (promoResponse.response.promoRibbon[0].aemNode.eyebrowCopy ? promoResponse.response.promoRibbon[0].aemNode.eyebrowCopy : '') + "</span>";

                    if(promoResponse.response.promoRibbon[0].aemNode.expirationTime) {
                        var date = new Date(promoResponse.response.promoRibbon[0].aemNode.expirationTime);
                        var timestamp = date.getFullYear() + "-" + date.getMonth() + "-" + date.getDate() + " 23:59:59";
                        promostring += "<span class='gnav20-promo-timer' timestamp='" + timestamp + "'></span>";
                    }
                    promostring += "</div>";
                    document.querySelector(".gnav20-promo-ribbon").innerHTML = promostring;
                }
                gnav20.OffersCaptureResponse( "success", promoResponse.response, 82);
            } else if (promoResponse && promoResponse.response) {
                gnav20.OffersCaptureResponse("empty", promoResponse.response);
            }
        } catch (error) {
            gnav20.OffersCaptureResponse("exception");
        }
        document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
        gnav20.initPromo();
    };
    xhttp.onerror = function () {
        document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
        gnav20.OffersCaptureResponse("error");
        gnav20.initPromo();
    }
    xhttp.ontimeout = function () {
        document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
        gnav20.OffersCaptureResponse("timeout");
        gnav20.initPromo();
    }
    var data = JSON.stringify({
      "source": "blackRibbon",
      "pageUrl": window.location.pathname,
      "pageContext": pContext,
      "isTestFlagEnabled": false
    });
    xhttp.open("POST", url, true);
    if(document.getElementById("gnav20-prod-context") && /true/.test(document.getElementById("gnav20-prod-context").value)) {
        xhttp.timeout = 2000;
    }
    xhttp.setRequestHeader("Channelid", "VZW-DOTCOM");
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(data);
}

gnav20.initGnav = function() {
	gnav20.mobileNav = document.querySelector('.gnav20-mobile .gnav20-mobile-menu .gnav20-navigation-placeholder')
	gnav20.desktopNav = document.querySelector('.gnav20-desktop .gnav20-row-two > .gnav20-navigation')
	gnav20.mobileHeader = document.querySelector('.gnav20 .gnav20-mobile')

	if(gnav20.mobileHeader && gnav20.desktopNav && gnav20.mobileNav){
		var	mobileHeaderComp = window.getComputedStyle(gnav20.mobileHeader),
				mobileHeaderDisplay = mobileHeaderComp.getPropertyValue('display') == 'block'

		if(mobileHeaderDisplay) {
			gnav20.mobileNav.innerHTML = gnav20.desktopNav.innerHTML;
			gnav20.desktopNav.innerHTML = ''
			gnav20.currentNav = 'mobile'
		}else{
			gnav20.currentNav = 'desktop'
		}
		window.addEventListener('resize', gnav20.copyNavTimeout)
	}

	gnav20.vzwbau = document.getElementById('vzw-gn');
	if(gnav20.vzwbau && gnav20.vzwbau.querySelector('.gnav20')){
		gnav20.header = document.createElement('div');
		gnav20.vzwbau.parentElement.insertBefore(gnav20.header, gnav20.vzwbau);
		gnav20.header.innerHTML = gnav20.vzwbau.querySelector('.gnav20').parentElement.innerHTML;
		gnav20.vzwbau.parentElement.removeChild(gnav20.vzwbau);
	}
	 //Added check to bypass personalization logic in author env
	 if(!gnav20.getCookie("wcmmode")){
    		gnav20.initPersona();
     }
	gnav20.initGnavMenu();
	gnav20.initLOB();
	gnav20.initSignIn();
	gnav20.initNav();
	gnav20.initPromo();
	gnav20.initSearch();
	gnav20.initUnifiedCart();
	gnav20.personalizeHidden();
	gnav20.initIconCounts();
	MP.init();

	if(gnav20.personal && gnav20.initVisualCue){
		gnav20.check4BusinessCookie()
		gnav20.initVisualCue()
	}
	if(window.document.documentMode && gnav20.personal && !gnav20.getCookie('bannerIEClosed')){
		gnav20.bannerInt = setInterval(function(){
			if(gnav20.displaybannerIE){
				clearTimeout(gnav20.bannerInt)
				gnav20.bannerInt = null
				gnav20.displaybannerIE()
			}
			if(gnav20.bannerIEDiv){clearTimeout(gnav20.bannerInt)}
		},100)
	}
	

	if (document.getElementById("gnav20-promo-placeholder")) {
	    if ((gnav20.getCookie("blackRibbon") === "enabled" || document.getElementById("gnav20-promo-placeholder").classList.contains('enableAuthPZN')) && gnav20  && gnav20.bu && gnav20.bu == 'wireless' && gnav20.getCookie("loggedIn") === "true" && "prepay" !== gnav20.getCookie("role") && (!gnav20.variation || (gnav20.variation && gnav20.variation != 'nsa'))) {
	        if(gnav20.getCookie("br_trgt_pers") === "true") {
	            if(document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext")) {
                    document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
                    gnav20.initPromo();
                }
	        } else {
	            var xhttp = new XMLHttpRequest();
                var url = gnav20.getScriptOrigin() + "/content/caas/black-ribbon-groups.model.isActive:true.json";
                xhttp.onload = function () {
                    try {
                        var promoGroupResponse = JSON.parse(this.responseText);
                        if(promoGroupResponse.blackRibbon) {
                            var ribbonGroups = Object.values(promoGroupResponse.blackRibbon);
                            var fullPath = window.location.pathname;
                            var pathRegex = "^" + fullPath + "$";
                            var pathMatchFound = 0;
                            for(var i=0; i<ribbonGroups.length; i++) {
                                if(ribbonGroups[i].url && ribbonGroups[i].url.length > 0) {
                                    if(ribbonGroups[i].url[0].match(new RegExp(pathRegex))) {
                                        pathMatchFound = 1;
                                        gnav20.loadAuthPersonalizedRibbon(ribbonGroups[i].pageContext);
                                    }
                                }
                            }
                            if(pathMatchFound == 0) {
                                gnav20.loadProspectPersonalizedRibbon();
                            }
                        } else {
                            gnav20.loadProspectPersonalizedRibbon();
                        }
                    } catch (error) {
                      console.log(error);
                      if(document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext")) {
                          document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
                          gnav20.initPromo();
                      }
                    }
                }
                xhttp.open("GET", url, true);
                xhttp.send();
	        }

        } else if(gnav20.getCookie("br_trgt_pers") === ""){
	            var xhttpPdm = new XMLHttpRequest();
                var value = gnav20.getScriptOrigin() + "/content/caas/vcg/services/pdmrules.model.isActive:true.json";
                xhttpPdm.onload = function () {
                    try {
                        var promoGroupResponse = JSON.parse(this.responseText);
                        if(promoGroupResponse.pdmRules) {
                            var ribbonGroups = Object.values(promoGroupResponse.pdmRules);
                            var fullPath = window.vzdl.page.name;
                            var pathMatchFound = 0;
                            for(var i=0; i<ribbonGroups.length; i++) {
                                if(ribbonGroups[i].value && ribbonGroups[i].value.length > 0) {
                                    if(ribbonGroups[i].value.match(fullPath)) {
                                        pathMatchFound = 1;
										var addScript = document.createElement('script');
										addScript.type = 'module';
										addScript.src = gnav20.getScriptOrigin() + "/etc/clientlibs/vcg/aep/pdm/js/pdm.js";
										document.getElementsByTagName('head')[0].appendChild(addScript);
                                    }
                                }
                            }
                            if(pathMatchFound == 0) {
                                gnav20.loadProspectPersonalizedRibbon();
                            }
                        } else {
                            gnav20.loadProspectPersonalizedRibbon();
                        }
                    } catch (error) {
                      if(document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext")) {
                          document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
                          gnav20.initPromo();
                      }
                    }
                }
                xhttpPdm.open("GET", value, true);
                xhttpPdm.send();
		}else{
			gnav20.loadProspectPersonalizedRibbon();
		}	
	}

	var targetCurrentUrl = window.location.href;

	// String replace for URLs with placeholder for href with [current-url]
	var replaceURLs = document.querySelectorAll("a[href*='[current-url]']");
	for(i=0; i < replaceURLs.length; i++) {
		var url = replaceURLs[i].href;
        replaceURLs[i].href = url.replace('[current-url]', encodeURIComponent(targetCurrentUrl));
	}

	// String replace for URLs with placeholder for data-href with [current-url]
	var replaceSpanURLs = document.querySelectorAll("span[data-href*='[current-url]']");
	for(i=0; i < replaceSpanURLs.length; i++) {
		var url = replaceSpanURLs[i].getAttribute("data-href");
        replaceSpanURLs[i].setAttribute("data-href", url.replace('[current-url]', encodeURIComponent(targetCurrentUrl)));
	}

	gnavdl.options = gnavdl.options || {}
	if(gnavdl.options.gotoAfterSignin){
		var gotoAfterSignin = gnavdl.options.gotoAfterSignin == 'self' ? location.href : gnavdl.options.gotoAfterSignin
		var signinLinks = document.querySelectorAll('.gnav20 a.gnav20-dropdown-list-item[href$=".verizon.com/signin"]')
		for (i = 0; i < signinLinks.length; i++){
		signinLinks[i].href += '?goto=' + encodeURIComponent(gotoAfterSignin)
		}
	}

	// defeat the header logo link if defined in gnavdl
	if(gnavdl.options.defeatLogoLink) {
		var logos = document.querySelectorAll('.gnav20 .gnav20-logoWhiteBg, .gnav20 .gnav20-logoHeaderVBG')
		for(i=0; i < logos.length; i++){
			logos[i].removeAttribute('href')
			logos[i].removeAttribute('title')
		}
		var footerLogos = document.querySelectorAll('.gnav20 .gnav20-logoFooterVBG')
		for(i=0; i < footerLogos.length; i++){
			footerLogos[i].setAttribute('target', '_blank')
		}
	}

  if(gnavdl.options.sticky && document.getElementById("vz-gh20")){
  	// add sticky class if sticky is in gnavdl
  	if(document.getElementById("vz-gh20").querySelector(".gnav20")){
  		document.getElementById("vz-gh20").querySelector(".gnav20").classList.add("gnav20-sticky")
  	}

  	/* adjust sticky spacer if promo ribbon wraps to more than one line
		gnav20.stickyHeader = document.querySelector('.gnav20-sticky-header');
		gnav20.stickyContent = document.querySelector('.gnav20-sticky-content');
		gnav20.setSpacer = null;
		if(gnav20.stickyContent && gnav20.stickyHeader){
			if(gnav20.stickyHeader.classList.contains('gnav20-with-promo')){
				gnav20.adjustSticky = function(){
					clearTimeout(gnav20.setSpacer)
					gnav20.setSpacer = setTimeout("gnav20.stickyHeader.style.height = gnav20.stickyContent.offsetHeight + 'px'",300)
				}
				window.addEventListener('resize', gnav20.adjustSticky)
				gnav20.adjustSticky()
			}else{
				gnav20.stickyHeader.style.height = gnav20.stickyContent.offsetHeight + 'px'
				setTimeout("gnav20.stickyHeader.style.height = gnav20.stickyContent.offsetHeight + 'px'",300)
			}
		}*/
	}

	// move mobile selected LOB in DOM for a11y
	var selectedLOB = document.querySelector('.gnav20-mobile .gnav20-main-header.gnav20-selected'),
			selectedLOBWrapper = document.getElementById('gnav20-ulwrapper')
	if(selectedLOB){
		selectedLOBWrapper.insertBefore(selectedLOB, selectedLOBWrapper.firstChild)
		//if(/smb/.test(gnavdl.bu) && document.querySelector('.gnav20-mobile .gnav20-navigation-placeholder')){
		//	document.querySelector('.gnav20-mobile .gnav20-navigation-placeholder').append(document.querySelector('.gnav20-mobile .gnav20-eyebrow-link-list'))
		//}
		var switchTo = selectedLOBWrapper.parentElement.querySelector('.gnav20-main-header[data-stext]:not(.gnav20-selected)')
		if(switchTo){
			switchTo.setAttribute('aria-label',switchTo.getAttribute('data-stext') + ' ' + switchTo.getAttribute('aria-label'))
		}
	}


	// checks for escape key and closes open menu
	gnav20.mainContainer = document.querySelector('.gnav20')
	if(gnav20.mainContainer){
		gnav20.mainContainer.addEventListener('keydown',gnav20.checkEscapeKey)
	}

	// temporary code to add data-label attr
	var desktopUtils = document.querySelectorAll('.gnav20 .gnav20-desktop .gnav20-row-one .gnav20-utility a')
	for(i=0; i < desktopUtils.length; i++) {
		desktopUtils[i].setAttribute('data-label',desktopUtils[i].innerText)
	}

	// add new-design class to sticky-header spacer element
	var nd = document.querySelector('.gnav20 .gnav20-new-design')
	if(nd){
		var sh = document.querySelector('.gnav20 .gnav20-sticky-header')
		if(sh){
			sh.classList.add('gnav20-new-design')
		}
	}

	// Temporary code to remove the svgs from the icons for the new design which will use background image svgs
	var svgs = document.querySelectorAll('.gnav20 .gnav20-width-wrapper.gnav20-new-design .gnav20-utility svg, .gnav20 .gnav20-width-wrapper.gnav20-new-design .gnav20-nav-utility svg')
	for(i=0;i<svgs.length;i++){
		if(!svgs[i].closest('.gnav20-language-link')){
			svgs[i].parentNode.removeChild(svgs[i]);
		}
	}

	// add appid class to width wrapper for appid specific css
	gnav20.wrapper = document.querySelector('.gnav20 .gnav20-width-wrapper');
	if (gnav20.wrapper && gnav20.state && gnav20.state != 'prospect' && gnav20.appid == 'vpd') {
		gnav20.wrapper.classList.add('gnav20-'+gnavdl.appid)
  	}

	// add lang attribute to language toggles
	if(/espanol/.test(location.host) || /es-/.test(location.host)){
		var lang = 'en'
		var alabel = 'Switch to English language website'
	}else{
		var lang = 'es'
		var alabel = 'Cámbiate al sitio web en español'
	}
	var links = document.querySelectorAll('.gnav20-lang-link');
	for(i=0;i<links.length;i++){
		links[i].setAttribute('lang',lang);
		links[i].setAttribute('aria-label',alabel);
	}

 try {
  // add class to width wrapper for featured or not featured UX
  if (gnav20.wrapper){
  	var featClass = gnav20.wrapper.querySelector('.gnav20-primary-menu.gnav20-featured-card') ? 'gnav20-featured' : 'gnav20-not-featured'
  	gnav20.wrapper.classList.add(featClass)
  }
 } catch (err) {

 }
	// remove the temp styles defined in the header HTML
	//document.getElementById('gnav20-preload') && document.getElementById('gnav20-preload').remove()

  // check to see if we have header or banner then add if absent for a11y
  document.querySelectorAll('header,[role=banner]').length || (document.querySelector('div.gnav20') && document.querySelector('div.gnav20').setAttribute('role','banner'))

	// any team can define this func on their page to have it called after gnav is initialized. It can only be defined once on a page.
  window.gnav20Ready && window.gnav20Ready();

  // tell the world gnav20 is ready. This event will broadcast to the page and can be used by multiple teams to interact with the gnav after initialization
	window.GNAV_IS_READY = true;
	var evnt = new Event('gnavReady');
	document.dispatchEvent(evnt);
	var evntHeader = new Event('gnavHeaderReady');
    document.dispatchEvent(evntHeader);
}

window.gnavdl = window.gnavdl || {};

if(!gnavdl.bu){
	gnav20.initGnav();
	gnav20.initGnavFooter();
	console.log('init BEFORE fetching header from init')
}

gnav20.loadHeader = function(context) {
	if (document.getElementById("vz-gh20")) {
		var xhttp = new XMLHttpRequest();
		var url = gnav20.getScriptOrigin() + "/one-digital/gnav/header/" + context + ".external.html";
		if (gnav20.getCookie("wcmmode")) {
			url = gnav20.getScriptOrigin() + "/content/wcms/one-digital/gnav/header/" + context + ".external.html" + "?wcmmode=disabled";
		}
		xhttp.onreadystatechange = function () {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("vz-gh20").innerHTML = this.responseText;
				if(document.location.hash.length <= 1) {
					document.body.scrollTop = 0; // For Safari
					document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera				
				}
				gnav20.initGnav();
				console.log('init AFTER fetching header')
				
			}
		};
		xhttp.open("GET", url, true);
		xhttp.send();
	}
};

gnav20.loadFooter = function(context) {
	if (document.getElementById("vz-gf20")) {
		var xhttp = new XMLHttpRequest();
		var url = gnav20.getScriptOrigin() + "/one-digital/gnav/footer/" + context + ".external.html";
		if (gnav20.getCookie("wcmmode")) {
			url = gnav20.getScriptOrigin() + "/content/wcms/one-digital/gnav/footer/" + context + ".external.html" + "?wcmmode=disabled";
		}
		xhttp.onreadystatechange = function () {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("vz-gf20").innerHTML = this.responseText;
				gnav20.initGnavFooter();
			}
		};
		xhttp.open("GET", url, true);
		xhttp.send();
	}
};
gnav20.loadPromoBanner = function() {
     document.querySelector("#gnav20-promo-placeholder .gnav20-promo .gnav20-promotext").classList.add("opacityOne");
     gnav20.initPromo();
};
/****************************************************/
//****  Finding user using Mouse VS Keyboard ********//
document.body.addEventListener('mousemove', function () {
	if(!document.body.classList.contains('gnav20-using-mouse')){
		document.body.classList.add('gnav20-using-mouse');
	}
});
document.body.addEventListener('keydown', function (event) {
	if((event.target || this).tagName != 'INPUT'){
		document.body.classList.remove('gnav20-using-mouse');
	}
});
/****************************************************/

gnav20.updateTFNContent = function(newText) {
    var tfnContent = document.querySelector(".gnav20-tfn-content");
	if (newText && newText.length > 0 && tfnContent) {
		tfnContent.innerText = newText;
	}
};

!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):(t=t||self).uuidv4=e()}(this,(function(){"use strict";var t="undefined"!=typeof crypto&&crypto.getRandomValues&&crypto.getRandomValues.bind(crypto)||"undefined"!=typeof msCrypto&&"function"==typeof msCrypto.getRandomValues&&msCrypto.getRandomValues.bind(msCrypto),e=new Uint8Array(16);function n(){if(!t)throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");return t(e)}for(var o=[],r=0;r<256;++r)o.push((r+256).toString(16).substr(1));return function(t,e,r){"string"==typeof t&&(e="binary"===t?new Uint8Array(16):null,t=null);var u=(t=t||{}).random||(t.rng||n)();if(u[6]=15&u[6]|64,u[8]=63&u[8]|128,e){for(var i=r||0,d=0;d<16;++d)e[i+d]=u[d];return e}return function(t,e){var n=e||0,r=o;return(r[t[n+0]]+r[t[n+1]]+r[t[n+2]]+r[t[n+3]]+"-"+r[t[n+4]]+r[t[n+5]]+"-"+r[t[n+6]]+r[t[n+7]]+"-"+r[t[n+8]]+r[t[n+9]]+"-"+r[t[n+10]]+r[t[n+11]]+r[t[n+12]]+r[t[n+13]]+r[t[n+14]]+r[t[n+15]]).toLowerCase()}(u)}}));

/*gnav20.throttle = document.querySelector('.gnav20 .gnav20-desktop .gnav20-navigation a[href*=throttletest]')// need to make sure it works for sign in page
gnav20.throttleCookie = gnav20.getCookie('gnvtst')
gnav20.throttleGroup = 'bau'

if(gnav20.throttle){
	gnav20.throttleArray = gnav20.throttle.href.split('/')
	gnav20.throttlePerc = parseInt(gnav20.throttleArray.pop())
	gnav20.throttleName = gnav20.throttleArray.pop()
	
	if(!gnav20.throttleCookie){
		gnav20.throttleGroup = Date.now() % 100 < gnav20.throttlePerc ? 'test' : 'bau'
		var throttleCookieString = gnav20.throttleName + '|' + gnav20.throttlePerc +'|'+ gnav20.throttleGroup		
		gnav20.setCookie('gnvtst',throttleCookieString,90)
		gnav20.throttleCookie = gnav20.getCookie('gnvtst')
		console.log('throttleLogic')
	}else if(!gnav20.throttlePerc){// this kills it	
		gnav20.throttleName = null
		gnav20.deleteCookie('gnvtst')
		gnav20.throttleCookie = null
		console.log('throttleLogic killswitch')
	}
} 

if(gnav20.throttleCookie){
	gnav20.throttleArray = gnav20.throttleCookie.split('|')
	
	console.log('throttleCookie')
	
	if(gnav20.throttlePerc != 'undefined' && gnav20.throttleArray[1] < gnav20.throttlePerc && gnav20.throttleArray[2] == 'bau'){
		gnav20.throttleName = null
		gnav20.deleteCookie('gnvtst')
		gnav20.throttleCookie = null
	}
	
	else if(gnav20.throttlePerc != 'undefined' && gnav20.throttleArray[1] > gnav20.throttlePerc && gnav20.throttleArray[2] == 'test'){
		gnav20.throttleName = null
		gnav20.deleteCookie('gnvtst')
		gnav20.throttleCookie = null
		
	}else{
		gnav20.throttleName = gnav20.throttleArray[0]
		gnav20.throttlePerc = gnav20.throttleArray[1]
		gnav20.throttleGroup = gnav20.throttleArray[2]
	}
}
*/

gnav20.testCookieName = 'gnv195591'
gnav20.testGroup = gnav20.getCookie(gnav20.testCookieName)

function sendVersionInfo() {
    window.coreData = window.coreData || [];
    window.coreData.push({
        task : "emit",
        event : "sendData",
        params : {
            name: "gnav version",
            data: {
                utils: {
                    gnav: window.gnvTestInfo
                }
            }
        }
    });
}
if(gnav20.testGroup){
	window.gnvTestInfo = gnav20.testCookieName + '_' + gnav20.testGroup
	sendVersionInfo();
}

gnav20.bu = "personal";
gnav20.variation = "";
gnav20.appid = "";
gnav20.state = "prospect";
gnav20.impltype = "";
gnav20.personal = true;

gnav20.personalization = {vcg:true};
//var qs = window.location.search;
//var qsParams = null;
var scbreshref = '';


if (typeof (gnavdl) !== "undefined" && gnavdl) {
	if (gnavdl.appid) {
		gnav20.appid = gnavdl.appid;    
  }
    
  if (gnavdl.bu) {
      gnav20.bu = gnavdl.bu;
  }    
	
	if (gnavdl.variation && gnavdl.variation != "" && gnavdl.variation != "prospect") {
        gnav20.variation = gnavdl.variation;
    }
	
	if (gnavdl.impltype) {
        gnav20.impltype= gnavdl.impltype;
	}

    if (gnav20.getCookie("loggedIn") || gnav20.getCookie("islogin") || gnavdl.authOnly) {
		gnav20.state = "authenticated";
    }  
}

/*if (qs) {
    qsParams = gnav20.getURLParams(qs);
}

if (qsParams && qsParams.source) {
	gnav20.bu = qsParams.source;
}*/

if (gnav20.bu == 'wireless'){
	// The following function will set a cookie which is used by VZW citrix users to suppress or allow video autoplay
	(function(){//NoVideoCitrixWLS
		var citrixUser = navigator.userAgent.indexOf('NoVideoCitrixWLS') !== -1,
				showVideo = location.href.indexOf('video=y') !== -1;	
		if(citrixUser || showVideo){
			var val = showVideo ? 'n' : 'y';
			gnav20.setCookie('suppressvideo',val)
		}
	})();

	// set GLOBALID cookie if not yet set
	if(!gnav20.getCookie('GLOBALID')){
		!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):(t=t||self).uuidv4=e()}(this,(function(){"use strict";var t="undefined"!=typeof crypto&&crypto.getRandomValues&&crypto.getRandomValues.bind(crypto)||"undefined"!=typeof msCrypto&&"function"==typeof msCrypto.getRandomValues&&msCrypto.getRandomValues.bind(msCrypto),e=new Uint8Array(16);function n(){if(!t)throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");return t(e)}for(var o=[],r=0;r<256;++r)o.push((r+256).toString(16).substr(1));return function(t,e,r){"string"==typeof t&&(e="binary"===t?new Uint8Array(16):null,t=null);var u=(t=t||{}).random||(t.rng||n)();if(u[6]=15&u[6]|64,u[8]=63&u[8]|128,e){for(var i=r||0,d=0;d<16;++d)e[i+d]=u[d];return e}return function(t,e){var n=e||0,r=o;return(r[t[n+0]]+r[t[n+1]]+r[t[n+2]]+r[t[n+3]]+"-"+r[t[n+4]]+r[t[n+5]]+"-"+r[t[n+6]]+r[t[n+7]]+"-"+r[t[n+8]]+r[t[n+9]]+"-"+r[t[n+10]]+r[t[n+11]]+r[t[n+12]]+r[t[n+13]]+r[t[n+14]]+r[t[n+15]]).toLowerCase()}(u)}}));
		gnav20.newGID = uuidv4().replace(/-/g,'z')
		gnav20.setCookie('GLOBALID', gnav20.newGID, 60);
	}
}

// delete gnCartCount cookie if user is no longer logged in
if(!gnav20.getCookie("loggedIn")){
	if(gnav20.getCookie('gnCartCount') > 0){
		gnav20.setCookie('checkAuthCartCount',true,30)
	}
	gnav20.deleteCookie('gnCartCount')
	gnav20.deleteCookie('gnCartCountFetched')
}


/*
if(gnav20.bu === "wireless" && gnav20.getCookie("loggedIn") === "true" && gnav20.getCookie("role") && "guest" !== gnav20.getCookie("role") && "prepay" !== gnav20.getCookie("role")) {
		
	if (!gnav20.getCookie("OS") && !gnav20.getCookie("featurePers") && !/limitedavailability/.test(location.pathname)) {
		var domain = "";		
		if(location.host.indexOf('.verizon.com') > -1) {
			domain = "www.verizon.com";
		} else {
			var appSub = /qa/.test(location.host) ? 'vzwqa'+  location.host.substr(location.host.indexOf('qa')+2,1) : 'www';
			domain = appSub + ".verizonwireless.com";
		}
		var jsonUrl = "https://" + domain + "/discover/gn_pzn"; 
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() { // Call a function when the state changes.
			if (this.readyState === 4 && this.status === 200) {
				var jsonObj = JSON.parse(this.responseText);
				if(jsonObj && jsonObj.data) {
					var t = jsonObj.data;
					gnav20.setCookie("OS", t.OS, .04);
					gnav20.setCookie("featurePers", t.feature_links.join("|"), .04);
					t.customer_type && gnav20.setCookie("customerType", t.customer_type, .04);
					t.associationId && gnav20.setCookie("asscId", t.associationId, .04);
					if(t.oneVerizon) {
						gnav20.setCookie("oneV", t.oneVerizon, .04);	
						gnav20.state = "1vz";
						makeHeaderRequest();
					}
				}
			}
		}
		xhr.open("GET", jsonUrl, true);
		xhr.withCredentials = true;
		xhr.timeout = 2000; // Set timeout to 2 seconds for fios
        xhr.ontimeout = function () { };
		xhr.send();	
	} else {		
		if (gnav20.getCookie("oneV")) {
			gnav20.state = "1vz";			
		}
	}		
}
else */ if (gnav20.bu === "home" && gnav20.getCookie("islogin") && gnav20.getCookie("userinfo")) {
	var url = "";
    var domainName = "https://wwwawssit.ebiz.verizon.com";
    if(location.hostname  == "www.verizon.com" || location.hostname  == "tv.verizon.com" || location.hostname  == "forums.verizon.com"){
		domainName = "https://www.verizon.com";
    }
	scbreshref= window.location.href.toLowerCase();
    try{
		if(scbreshref.indexOf('tv-sit.verizon.com') > -1 || 
			scbreshref.indexOf('tv-stg.verizon.com') > -1 ||
			scbreshref.indexOf('tv-dit.verizon.com') > -1 ||
			scbreshref.indexOf('tv.verizon.com') > -1 ||
			scbreshref.indexOf('forums.verizon.com') > -1 ||
			scbreshref.indexOf('sso-np.ebiz.verizon.com') > -1) {
			var userInfoCookieValue = gnav20.getCookie('userinfo');
			url = domainName +"/content/verizon/personal/services/getgnavuserinfo.all.nocache.json?userinfo="+userInfoCookieValue;
		} else {
			url =  domainName +"/content/verizon/personal/services/getgnavuserinfo.all.nocache.json";
		}
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function () {
			if (this.readyState == 4 && this.status == 200) {
				var jsonObj = JSON.parse(this.responseText);
				if (jsonObj && jsonObj.userdetailsJSON && jsonObj.userdetailsJSON.decryptedUserInfoCookie) {
					gnav20.personalization = jsonObj.userdetailsJSON.decryptedUserInfoCookie;
					initializePersonalization();
					if(jsonObj && jsonObj.userdetailsJSON && jsonObj.userdetailsJSON.DispNameValue && jsonObj.userdetailsJSON.DispNameValue != ""){
						gnav20.greetingName = jsonObj.userdetailsJSON.DispNameValue;  					    
					}
					if(!gnav20.getCookie("wcmmode")){
						gnav20.initPersona();
					}					
				}
								
			}
		};
		xhr.open("GET", url, true);
		xhr.timeout = 1000; // Set timeout to 1 second
        xhr.ontimeout = function () { /*timeout code block*/};
		xhr.send();
		
		if (gnav20.getCookie("islogin") && -1 < gnav20.getCookie("islogin").indexOf("vzw")) {
			gnav20.state = "1vz";		
		}
		scbSessionTO();
    } catch (e) {
		console.log("E in gnavservice call", e);
   	}    
}
else if (gnav20.bu === "wireless" && gnav20.getCookie("islogin") && gnav20.getCookie("userinfo")) {
	gnav20.bu = "home";	
	var url = "";
    var domainName = "https://wwwawssit.ebiz.verizon.com";
    if(location.hostname  == "www.verizon.com" || location.hostname  == "tv.verizon.com" || location.hostname  == "forums.verizon.com"){
		domainName = "https://www.verizon.com";
    }
	scbreshref= window.location.href.toLowerCase();
    try{
		if(scbreshref.indexOf('tv-sit.verizon.com') > -1 || 
			scbreshref.indexOf('tv-stg.verizon.com') > -1 ||
			scbreshref.indexOf('tv-dit.verizon.com') > -1 ||
			scbreshref.indexOf('tv.verizon.com') > -1 ||
			scbreshref.indexOf('forums.verizon.com') > -1 ||
			scbreshref.indexOf('sso-np.ebiz.verizon.com') > -1) {
			var userInfoCookieValue = gnav20.getCookie('userinfo');
			url = domainName +"/content/verizon/personal/services/getgnavuserinfo.all.nocache.json?userinfo="+userInfoCookieValue;
		} else {
			url =  domainName +"/content/verizon/personal/services/getgnavuserinfo.all.nocache.json";
		}
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function () {
			if (this.readyState == 4 && this.status == 200) {
				var jsonObj = JSON.parse(this.responseText);
				if (jsonObj && jsonObj.userdetailsJSON && jsonObj.userdetailsJSON.decryptedUserInfoCookie) {
					gnav20.personalization = jsonObj.userdetailsJSON.decryptedUserInfoCookie;
					initializePersonalization();
					if(jsonObj && jsonObj.userdetailsJSON && jsonObj.userdetailsJSON.DispNameValue && jsonObj.userdetailsJSON.DispNameValue != ""){
						gnav20.greetingName = jsonObj.userdetailsJSON.DispNameValue;  					    
					}
					if(!gnav20.getCookie("wcmmode")){
						gnav20.initPersona();
					}					
				}
								
			}
		};
		xhr.open("GET", url, true);
		xhr.timeout = 1000; // Set timeout to 1 second
        xhr.ontimeout = function () { /*timeout code block*/};
		xhr.send();
		
		if (gnav20.getCookie("islogin") && -1 < gnav20.getCookie("islogin").indexOf("vzw")) {
			gnav20.state = "1vz";			
		}
		scbSessionTO();
    } catch (e) {
		console.log("E in gnavservice call", e);
   	}    
}
else /* if(gnav20.bu === "home" && gnav20.getCookie("loggedIn") === "true" && gnav20.getCookie("role") && "guest" !== gnav20.getCookie("role") && "prepay" !== gnav20.getCookie("role")) {
	gnav20.bu = "wireless";	
	
	if (!gnav20.getCookie("OS") && !gnav20.getCookie("featurePers") && !/limitedavailability/.test(location.pathname)) {
		var domain = "";		
		if(location.host.indexOf('.verizon.com') > -1) {
			domain = "www.verizon.com";
		} else {
			var appSub = /qa/.test(location.host) ? 'vzwqa'+  location.host.substr(location.host.indexOf('qa')+2,1) : 'www';
			domain = appSub + ".verizonwireless.com";
		}
		var jsonUrl = "https://" + domain + "/discover/gn_pzn"; 
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if (this.readyState === 4 && this.status === 200) {
				var jsonObj = JSON.parse(this.responseText);
				if(jsonObj && jsonObj.data) {
					var t = jsonObj.data;
					gnav20.setCookie("OS", t.OS, .04);
					gnav20.setCookie("featurePers", t.feature_links.join("|"), .04);
					t.customer_type && gnav20.setCookie("customerType", t.customer_type, .04);
					if(t.oneVerizon) {
						gnav20.setCookie("oneV", t.oneVerizon, .04);	
						gnav20.state = "1vz";
						makeHeaderRequest();
					}
				}
			}
		}
		xhr.open("GET", jsonUrl, true);
		xhr.withCredentials = true;
		xhr.timeout = 2000; // Set timeout to 2 seconds for fios
        xhr.ontimeout = function () {};
		xhr.send();	
	} else {		
		if (gnav20.getCookie("oneV")) {			
			gnav20.state = "1vz";			
		}
	}		
}
else */ if(gnav20.getCookie("loggedIn") === "true" && gnav20.getCookie("role") &&  "prepay" === gnav20.getCookie("role")) {
	gnav20.bu = "wireless";
	if(gnav20.appid == "myverizon-prepay") {
		gnav20.state = "myvprepay"
	} else {
		gnav20.state = "prepay";
	}
}

// new condition for 1vz since new sign in provides this 3/3/23
if(gnavdl.oneV || /vzw/.test(gnav20.getCookie("islogin"))) {
	gnav20.setCookie("oneV", "true", .04);	
	gnav20.state = "1vz";			
}

if(gnav20.getCookie('loggedIn') && gnav20.state != '1vz'){gnav20.bu = 'wireless'}

gnav20.parseCartToaster = function(data) {
    try {
        var recentlyViewed = JSON.parse(data);
        if(recentlyViewed?.data?.getRecommendation?.recommendationInsightInformation?.lines?.deviceList?.length > 0) {
            var listParam = "";
            var deviceItemHtml = "<p class='gnav20-cart-content-title'>Continue shopping for:</p>";
            deviceItemHtml += "<div class='gnav20-cart-toast'>";
            recentlyViewed.data.getRecommendation.recommendationInsightInformation.lines.deviceList.forEach(function(device, index) {
                if(index < 3) {
                    deviceItemHtml += "<a tabindex='0' role='button' class='gnav20-cart-toast-item' data-track='{" +
                     '"type": "impression", "name": "l0|p' + (index + 1) + '|cart menu|||||gnav ribbon_recentItems_' +
                     device?.brandName + ' ' + device?.productDisplayName + "|" + device?.brandName + ' ' + device?.productDisplayName +
                     '"}' + "' href='" + gnav20.getScriptOrigin() + '/' + device?.seo?.canonicalUrl +"'>";
                    deviceItemHtml += "<img alt='recommended device' area-hidden='true' src='" +
                                       device?.defaultSKUObj?.imageUrlMap?.defaultImage + "?$pngalpha$&wid=50&hei=60'>";
                    deviceItemHtml += "<h2 area-hidden='false'>" + device?.brandName + ' ' + device?.productDisplayName + "</h2>";
                    deviceItemHtml += "</a>";
                    listParam += "l0|p" + (index + 1) + "|cart menu|||||gnav ribbon_recentItems_" + device?.brandName + ' ' + device?.productDisplayName +
                            (index < recentlyViewed.data.getRecommendation.recommendationInsightInformation.lines.deviceList.length ? "^" : "");
                }
            });
            deviceItemHtml += "</div>";

            var unifiedCartToast = document.querySelectorAll(".gnav20-unified-cart");
            for (var i = 0; i < unifiedCartToast.length; i++) {
                let newDiv = document.createElement('div');
                newDiv.innerHTML = deviceItemHtml;
                unifiedCartToast[i].prepend(newDiv);
            }

            window.coreData = window.coreData || [];
            window.coreData.push({
                task: "emit",
                event: "impression",
                params: {
                    list: listParam
                }
            });
        }
    } catch (error) {
        console.log(error);
    }
}

gnav20.loadCartToaster = function() {
    var wirelessAuth = gnav20.getCookie('loggedIn');
	var cartCountCookieName = wirelessAuth ? "gnCartCount" : "prospectCartCount",
		cartCount = parseInt(gnav20.getCookie(cartCountCookieName));
	var wirelessAuthAAL = gnav20.getCookie('intendType');
		if(wirelessAuth && wirelessAuthAAL == "AAL"){
			wirelessAuthAAL = true;
		}else{
			wirelessAuthAAL = false;
		}
	var cartCountFlyoutCookieName = wirelessAuthAAL ? "gnCartCount" : "prospectCartCount",
		cartCountFlyout = parseInt(gnav20.getCookie(cartCountFlyoutCookieName));

    if(document.querySelector(".gnav20-unifiedcart") && gnav20.getCookie('s_ecid') && (isNaN(cartCount) || cartCount === 0)) {
        let cartToaster = sessionStorage.getItem('cartToaster');
        if(cartToaster) {
            gnav20.parseCartToaster(cartToaster);
        } else {
            var xhttp = new XMLHttpRequest();
            var url = gnav20.getScriptOrigin() + "/soe/digital/prospect/browseservice/nse/recommendationInsight";
            var data = JSON.stringify({ "data": {
                  "ecId": gnav20.getCookie('s_ecid')?.split("|").length>1 ? gnav20.getCookie('s_ecid')?.split("|")[1] : '',
                  "pageContext": 'personal-home',
                  "promoFlow": "NSE",
                  "recommendationInsight": "RecentlyViewed",
                  "salesFlow": true,
                  "url": location?.href,
                  "userAgent": navigator?.userAgent
                }});
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    try {
                        sessionStorage.setItem('cartToaster', this.responseText);
                        gnav20.parseCartToaster(this.responseText);
                        var recentlyViewed = JSON.parse(this.responseText);
                        if(recentlyViewed?.data?.getRecommendation?.recommendationInsightInformation?.lines?.deviceList?.length > 0) {
                            var unifiedCartIcons = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart');
                            for (var i = 0; i < unifiedCartIcons.length; i++) {
                                if(unifiedCartIcons[i].checkVisibility()) {
                                    //unifiedCartIcons[i].click();
                                    unifiedCartIcons[i].closest(".gnav20-unifiedcart").querySelector('.gnav20-unified-cart').classList.remove("gnav20-hide");
                                    unifiedCartIcons[i].setAttribute('aria-expanded','true');
                                    if(unifiedCartIcons[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-vzmoverlay")) {
                                        unifiedCartIcons[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-vzmoverlay").classList.add('gnav20-menuop');
                                    }
                                    var isMobile = unifiedCartIcons[i].closest('.gnav20-mobile');
                                    gnav20.activeCloseButton = unifiedCartIcons[i].closest(".gnav20-unifiedcart").querySelector('.gnav20-unified-cart').querySelector('.gnav20-closex')
                                    if(isMobile){
                                    	document.body.classList.add('gnav20-modal-menu-open')
                                    	gnav20.closeElementQuery = '#gnav20-my-side-nav-mobile'
                                    	toggleAriaHiddenGnav20("cart", !0);
                                    	setTimeout(function(){
                                            var movers = document.querySelector('.gnav20-mobile .gnav20-unifiedcart .gnav20-unified-cart .gnav20-closex');
                                            var parentEle = movers.parentElement;
                                            movers.remove();
                                            parentEle.prepend(movers);
                                            gnav20.setFocusTrap(parentEle);
                                            movers.focus();
                                        },100);

                                    }else{
                                        gnav20.closeElementQuery = '#gnav20-my-side-nav';
                                        unifiedCartIcons[i].focus();
                                    }

                                    setTimeout("document.body.addEventListener('click', gnav20.clickOutsideClose)",1);

                                    window.coreData = window.coreData || [];
                                    window.coreData.push({
                                        task : "emit",
                                        event : "openView",
                                        params : {
                                            selector : ".gnav20-unified-cart",
                                            name : "global nav:cart menu"
                                        }
                                    });

                                }
                            }
                        }
                    } catch (error) {
                        console.log(error);
                    }
                }
            };
            xhttp.open("POST", url, true);
            xhttp.timeout = 2000;
            xhttp.setRequestHeader("channelId", "VZW-DOTCOM");
            xhttp.setRequestHeader("Content-Type", "application/json");
            xhttp.send(data);
        }
    }else if(document.querySelector(".gnav20-unifiedcart .gnav20-flyout-cart-enabled") && gnav20.getCookie('s_ecid') && (cartCountFlyout > 0) && gnav20.getCookie('NGD') && 	window.gnavdl.options.flyout == true){
		var unifiedCartFlyout = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart');
			for (var i = 0; i < unifiedCartFlyout.length; i++) {
				if(unifiedCartFlyout[i].checkVisibility()) {
					if(unifiedCartFlyout[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart").classList.contains('gnav20-cart-icon-flyout')){
						unifiedCartFlyout[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart").classList.remove("gnav20-cart-icon-flyout");
					}
					unifiedCartFlyout[i].closest('.gnav20-unifiedcart').querySelector('.gnav20-unified-cart').classList.add("gnav20-unified-flyout-success");
					unifiedCartFlyout[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart-content-title").setAttribute("id","gnav20-cart-content-title-flyout");
					unifiedCartFlyout[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-content-lists").remove();
				}
			}
		}

}

gnav20.flyoutCartGnav = function() {
	var unifiedCartGnavIcons = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart');
	 for (var i = 0; i < unifiedCartGnavIcons.length; i++) {
        if(unifiedCartGnavIcons[i].checkVisibility()) {
			var flyoutFrame = document.createElement("iframe");
				flyoutFrame.setAttribute("class", "gnav20-cart-flyout");
				flyoutFrame.setAttribute("src", "/nextgendigital/sales/browse/flyoutcart/gnav");
				unifiedCartGnavIcons[i].closest('.gnav20-unifiedcart').querySelector('.gnav20-unified-cart').append(flyoutFrame);
			var loader = document.createElement("div");
				loader.setAttribute("class", "flyout-overlay");
			var loaderPos = unifiedCartGnavIcons[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-flyout-cart-enabled");
				loaderPos.insertBefore(loader,loaderPos.children[2]);
				unifiedCartGnavIcons[i].closest('.gnav20-unifiedcart').querySelector(".flyout-overlay").innerHTML = "<div id='load-indicator'></div>";
				gnav20.removeLoader();
		}
	 }
}

gnav20.flyoutCartPdp = function() {
	var unifiedCartPdpIcons = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart');
	 for (var i = 0; i < unifiedCartPdpIcons.length; i++) {
        if(unifiedCartPdpIcons[i].checkVisibility()) {
			unifiedCartPdpIcons[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart").classList.add("gnav20-cart-icon-flyout");
			unifiedCartPdpIcons[i].closest('.gnav20-unifiedcart').querySelector(".gnav20-cart").click();
		}
	 }
		window.coreData = window.coreData || [];
			window.coreData.push({
				task : "emit",
				event : "openView",
					params : {
						selector : ".gnav20-unified-cart",
						name : "global nav:Flyout cart menu PDP"
					}
			});
}

gnav20.removeLoader = function() {
setTimeout(function(){
	var unifiedCartLoader = document.querySelectorAll('.gnav20-unifiedcart .gnav20-cart');
	 for (var i = 0; i < unifiedCartLoader.length; i++) {
        if(unifiedCartLoader[i].checkVisibility()) {
            unifiedCartLoader[i].closest('.gnav20-unifiedcart').querySelector(".flyout-overlay").remove();
		}
	 }
	}, 5000);
}

document.addEventListener("gnavHeaderReady", gnav20.loadCartToaster);


makeHeaderRequest();

function initializePersonalization() {
    if (typeof (gnavdl) !== "undefined" && gnavdl && gnavdl.appid) {
    			gnav20.personalization['appid'] = gnavdl.appid;
     }
	if (gnav20.getCookie("loggedIn") && gnav20.getCookie("role")) {
		gnav20.personalization['loggedIn'] = gnav20.getCookie("loggedIn");
		gnav20.personalization['role'] = gnav20.getCookie("role");
		
		if (gnav20.getCookie("OS")) {
			gnav20.personalization['OS'] = gnav20.getCookie("OS");
		}		
		if (gnav20.getCookie("featurePers")) {
			gnav20.personalization['featurePers'] = gnav20.getCookie("featurePers");
		}
		if (gnav20.getCookie("customerType")) {
			gnav20.personalization['customerType'] = gnav20.getCookie("customerType");
		}
		if (gnav20.getCookie("oneV")) {
			gnav20.personalization['oneV'] = gnav20.getCookie("oneV");			
		}
		if (gnav20.getCookie("asscId")) {
			gnav20.personalization['asscId'] = gnav20.getCookie("asscId");			
		}
	}
	if( "zk" === gnav20.getCookie("authType") &&
		"vzw|vzt" === gnav20.getCookie("zkServices") &&
		"limited" != gnav20.variation){
			gnav20.personalization.authType = "zk";
			gnav20.variation = "";
			gnav20.state = "1vz";
     }
}

function makeHeaderRequest() {
	initializePersonalization();
	gnav20.context = gnav20.bu + gnav20.variation + gnav20.state;
  if(((gnav20.impltype == 'ssi' && gnav20.state == 'prospect') || 
		(gnav20.impltype == 'ssiauth' && gnav20.state == 'authenticated' && ((gnavdl && gnavdl.bu == gnav20.bu) || !gnavdl)) ||
		gnav20.impltype == 'ssi-nooverride') && document.getElementById("vz-gh20") && document.getElementById("vz-gh20").firstElementChild
		&& gnav20.testGroup != 'test') { 
		document.getElementById("vz-gh20").firstElementChild.removeAttribute('style');
		if(!gnav20.getCookie("wcmmode")){
			gnav20.initPersona();
		}
		if(window.gnavdl && gnavdl.variation != "limited" && gnavdl.options && gnavdl.options.sticky && (gnavdl.options.sticky == "true" || gnavdl.options.sticky == true)) {
			if(document.getElementById("vz-gh20").querySelector(".gnav20")) {
				document.getElementById("vz-gh20").querySelector(".gnav20").classList.add("gnav20-sticky");
			}
		}		
		gnav20.initGnav();
		gnav20.initGnavFooter();
		console.log('init BEFORE fetching header from personal 2')
	} else {
		if(gnav20.testGroup == 'test' && gnavdl.variation !== 'limited' && gnavdl.appid !== 'vpd'){
			gnav20.context += '-more'
		}
		gnav20.loadHeader(gnav20.context);
		gnav20.loadFooter(gnav20.context);	
	}
}

function refreshGnav(variation) {
	gnav20.context = gnav20.bu + (variation ? variation : gnav20.variation) + gnav20.state;
	if(gnav20.testGroup === 'test' && variation !== 'limited' && gnavdl.appid !== 'vpd'){
		gnav20.context += '-more'
	}
  gnav20.loadHeader(gnav20.context);
	gnav20.loadFooter(gnav20.context);		
}

if(!gnav20.getCookie("loggedIn") || (gnav20.getCookie("loggedIn") && gnav20.getCookie("loggedIn") !== "true")) {
	gnav20.deleteCookie("OS");
	gnav20.deleteCookie("featurePers");
	gnav20.deleteCookie("customerType");
	gnav20.deleteCookie("oneV");
}

function removeHttps(strUrl){
	try{
		var tmpStrUrl = strUrl.replace('https://','');
		tmpStrUrl = tmpStrUrl.replace("http://","");
		return tmpStrUrl;
	} catch(err) {
		console.log('E - removeHttps::'+err);
	}
}

function scbSignOut(){
	try{
	   var scbSignOutRetURL = '';
       var vzSignOut = document.getElementById("vzSignOut") ? document.getElementById("vzSignOut").value : 'ssoauth.verizon.com';
	   var strThisHrefNoCaseChange = (window.location.href).substring(0,((window.location.href).search(/goto=/)>-1)?(window.location.href).search(/goto=/):999);
	        if (scbreshref.indexOf('.verizon.com/watch') > -1) {
	            scbSignOutRetURL = 'https://' + document.domain + '/watch';
	        } else {
	            scbSignOutRetURL = strThisHrefNoCaseChange;
	        }
	    
	    window.location.href = "https://" + vzSignOut + '/sso/logout/logout.jsp?target=' + scbSignOutRetURL;
	} catch(err) {
		console.log('E - scbSignOut::'+err);
	}
}

function scbSessionTO() {
	try{
		var scbArSTO = new Array('verizon.com/consumer/myverizon/', 'verizon.com/foryourhome', 'verizon.com/whatsnext', removeHttps('http://perks.verizon.com'), removeHttps('http://surround.verizon.com'), removeHttps('http://media.verizon.com/media'),
		        removeHttps('http://my.verizon.com'), removeHttps('https://ssoauth.verizon.com'), 'essentialsandextras.verizon.com', 'verizon.com/mybill/', 'verizon.com/autopay/', 'verizon.com/payment/', 'verizon.com/paymentmethods/',
		        'verizon.com/comparebill/', 'verizon.com/billhistory/', 'verizon.com/billdetails/', 'verizon.com/paperfreebilling/', 'verizon.com/disputebill/', 'verizon.com/downloadbill/', 'verizon.com/adjustments/',
		        'verizon.com/refunds/', 'verizon.com/pmthistory/', 'verizon.com/paymentarrangement/', '/personal/urc.html', 'verizon.com/home/');
		    var scbSTO = false;
		    for (var i = 0; i < scbArSTO.length; i++) {
		        if (scbreshref.indexOf(scbArSTO[i]) > -1) { scbSTO = true; break; }
		    }
		    // NO SSO sessionAlert.js FOR THIS
		    if (scbreshref.indexOf('/foryourhome/vzrepair/vziha/servicecad.aspx') > -1 ||
		        scbreshref.indexOf('/foryourhome/equickpay/myvzhome/express') > -1) { scbSTO = false; }

        	var gnavVOLRM = gnav20.getCookie('VOLRememberMe');
        	if(gnavVOLRM==null){gnavVOLRM='';}
			if(gnavVOLRM==''){
                gnavVOLRM=gnav20.getCookie('isKMSI');
            	if(gnavVOLRM==null){
                    gnavVOLRM='';
                }
            }
		    if (typeof (gnavVOLRM) != 'undefined' && gnavVOLRM == '' && scbSTO) {
		    	var ssoDomainName = '';
		    	if(scbreshref.indexOf('wwwawssit.ebiz.verizon.com') > -1 || 
		    	   scbreshref.indexOf('sso-np.ebiz.verizon.com') > -1){
		    		ssoDomainName = "sit-ssoauth.verizon.com";
		    	}else{
		    		ssoDomainName = "scache-ws.vzw.com";
		    	}
		    	if(document.getElementById("ssoDomainName")){
		    		ssoDomainName = document.getElementById("ssoDomainName").value;
		    	}
		        scbLoadJS( ssoDomainName + "/vzstatic/sso/resources/js/sessionAlert.js");
		    }
	} catch(err) {
		console.log('E - scbSessionTO::'+err);
	}
}

function scbLoadJS(scbURL) {
	try{
		var scbHead = document.getElementsByTagName('head')[0];
	    var scbScript = document.createElement('script');
	    scbScript.language = 'javascript';
	    scbScript.type = 'text/javascript';
	    scbScript.src = "https://" +scbURL;
	    scbHead.appendChild(scbScript);
	} catch(err) {
		console.log('E - scbLoadJS::'+err);
	}
}

gnav20.fetchAuthCartCount = function(){
	var params = {"serviceHeader":{"clientId":"VZW-ECOM","serviceName":"GetCases"},"serviceBody":{"serviceRequest":{"context":{"customerInfo":{"accountNumber":""},"contextInfo":{"callReason":"SalesOrderPurchase"}}}}}
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() { 
		if (this.readyState === 4 && this.status === 200) {
			var jsonObj = JSON.parse(this.responseText);
			if(jsonObj && jsonObj.itemCount.length && jsonObj.itemCount[0]){
					gnav20.setCookie('gnCartCount',jsonObj.itemCount[0])
					gnav20.setIconCounts()
			}	
			gnav20.deleteCookie('checkAuthCartCount')
			gnav20.setCookie('gnCartCountFetched',true)
		}
	}
	xhr.open("POST", '/soe/digital/auth/casemanagementservice/cases/getCaseCartCount', true);
	xhr.setRequestHeader('channelId', 'VZW-DOTCOM');
	xhr.setRequestHeader('Content-type', 'application/json');
	xhr.send(JSON.stringify(params));	
}
if(gnav20.getCookie('loggedIn') && gnav20.getCookie('checkAuthCartCount') && !gnav20.getCookie('gnCartCountFetched') && !gnav20.getCookie('gnCartCount')){
	gnav20.fetchAuthCartCount()
} 

gnav20.displaybannerIE = function(){
	bannerIEHTML = '<div style="max-width:1272px; padding:20px 20px 20px 56px; margin:0 auto; font-size:16px;position:relative;line-height:20px;letter-spacing: .5px;">'
	+ '<svg style="position:absolute;left:20px;" aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" focusable="false"><g><circle vector-effect="non-scaling-stroke" stroke="#ffffff" stroke-width="2" fill="none" cx="12" cy="12" r="10"></circle><rect stroke="none" fill="#ffffff" x="10.99" y="9.98" width="2.02" height="8"></rect><rect stroke="none" fill="#ffffff" x="10.98" y="6" width="2" height="2"></rect></g></svg>'
	+ '<span style="font-weight:bold">We no longer support Internet Explorer</span><br />For the best browsing experience, please update your browser. '
	+ '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a style="text-decoration:underline !important" href="https://www.google.com/chrome/" target="_blank">Chrome</a>'
	+ '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a style="text-decoration:underline !important" href="https://www.mozilla.org/" target="_blank">Firefox</a> '
	+ '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a style="text-decoration:underline !important" href="https://www.microsoft.com/en-us/edge" target="_blank">Edge</a> '
	+ '<button style="top:20px;right:20px;width:20px;height:20px;position:absolute;background-image:url(\'data:image/svg+xml;charset=utf-8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxzdHlsZT4uc3Qxe2ZpbGw6bm9uZTtzdHJva2U6I0ZGRkZGRjtzdHJva2Utd2lkdGg6MjtzdHJva2UtbWl0ZXJsaW1pdDoxMDt9PC9zdHlsZT48cmVjdCBmaWxsPSJub25lIiB3aWR0aD0iMjQiIGhlaWdodD0iMjQiLz48bGluZSBjbGFzcz0ic3QxIiB4MT0iMiIgeTE9IjIiIHgyPSIyMiIgeTI9IjIyIi8+PGxpbmUgY2xhc3M9InN0MSIgeDE9IjIiIHkxPSIyMiIgeDI9IjIyIiB5Mj0iMiIvPjwvc3ZnPgo=\') !important;" aria-label="Close this information banner"></button></div>'
	gnav20.bannerIEDiv = document.createElement('div')
	gnav20.bannerIEDiv.setAttribute('style','background:#0077B4')
	gnav20.bannerIEDiv.innerHTML = bannerIEHTML
	document.querySelector('#vz-gh20 .gnav20-width-wrapper').append(gnav20.bannerIEDiv)
	bannerIEClose = gnav20.bannerIEDiv.querySelector('button')
	bannerIEClose.addEventListener('click',function(){
		gnav20.bannerIEDiv.parentElement.removeChild(gnav20.bannerIEDiv)
		gnav20.setCookie('bannerIEClosed',true,30)
		if(gnav20.adjustSticky){
			gnav20.adjustSticky()
		}
	})
}



